#include <ncurses.h>
#include "color.h"

static char rcsid [] = "$Header: /usr/users/miguel/c/CVS/nc/color.c,v 1.1.1.1 1994/05/06 19:14:28 miguel Exp $";

/* To avoid excesive calls to ncurses' has_colors () */
int   hascolors = 0;

int sel_mark_color [4];

void init_colors ()
{
    hascolors = has_colors ();
    if (hascolors){
	start_color ();
	init_pair (1, COLOR_WHITE, COLOR_BLUE);	  /* normal */
	init_pair (2, COLOR_BLACK, COLOR_CYAN);   /* selected */
	init_pair (3, COLOR_YELLOW, COLOR_BLUE);  /* marked */
	init_pair (4, COLOR_YELLOW, COLOR_CYAN);  /* marked/selected */
	init_pair (5, COLOR_WHITE, COLOR_RED);	  /* errors */
	init_pair (6, COLOR_WHITE, COLOR_CYAN);	  /* menu entry */
	init_pair (7, COLOR_BLACK, COLOR_WHITE);  /* reverse b&w */
    }
    sel_mark_color [0] = NORMAL_COLOR;
    sel_mark_color [1] = SELECTED_COLOR;
    sel_mark_color [2] = MARKED_COLOR;
    sel_mark_color [3] = MARKED_SELECTED_COLOR;
}

