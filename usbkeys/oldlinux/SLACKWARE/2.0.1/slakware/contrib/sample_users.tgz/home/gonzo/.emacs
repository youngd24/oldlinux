(setq text-mode-hook 'turn-on-auto-fill)
(setq make-backup-files nil)
(put 'eval-expression 'disabled nil)
(setq auto-mode-alist (mapcar 'purecopy
                              '(("\\.c$" . c-mode)
                                ("\\.h$" . c-mode)
                                ("\\.tex$" . TeX-mode)
                                ("\\.txi$" . Texinfo-mode)
                                ("\\.el$" . emacs-lisp-mode)
                                ("\\.a$" . c-mode))))
 
(defvar cursor-map-2 (make-keymap)
"for ESC-[")
(fset 'Cursor-Map-2 cursor-map-2)
(define-key esc-map "[" 'Cursor-Map-2)
 
(define-key esc-map "[A" 'previous-line)
(define-key esc-map "[B" 'next-line)
(define-key esc-map "[C" 'forward-char)
(define-key esc-map "[D" 'backward-char)
(define-key esc-map "[H" 'beginning-of-line)
(define-key esc-map "[Y" 'end-of-line)
(define-key esc-map "[5^" 'scroll-down)
(define-key esc-map "[6^" 'scroll-up)
(define-key esc-map "[[A" 'help-for-help)
(define-key esc-map "[[B" 'byte-compile-file)
(define-key esc-map "[[C" 'isearch-forward)
(define-key esc-map "[[D" 'query-replace-regexp)
(define-key esc-map "[[E" 'eval-defun)
(define-key esc-map "[[F" 'eval-current-buffer)
(define-key esc-map "[[G" 'buffer-menu)
(define-key esc-map "[[H" 'global-set-key)
(define-key esc-map "[[I" 'save-buffer)
(define-key esc-map "[[J" 'save-buffers-kill-emacs)
(define-key esc-map "[2^" 'set-mark-command)
(define-key esc-map "[3^" 'delete-char)
 
(setq load-path (cons (expand-file-name "PATH_FOR_AUC-TEX") load-path))
(autoload 'tex-mode "auc-tex" "Automatic select TeX or LaTeX mode" t)
(autoload 'plain-tex-mode "auc-tex" "Mode for Plain TeX" t)
(autoload 'latex-mode "auc-tex" "Mode for LaTeX" t)
(autoload 'LaTeX-math-mode    "tex-math"      "Math mode for TeX." t)
(autoload 'outline-minor-mode "outline-m" "Minor Outline Mode." t)
 
(defun Ctl-C-prefix ()
  Ctl-C-keymap)
(setq Ctl-C-keymap (make-keymap))
(global-set-key "\C-c" (Ctl-C-prefix))
 
(define-key Ctl-C-keymap "m" 'LaTeX-math-mode)
(define-key Ctl-C-keymap "o" 'outline-minor-mode)
 
(make-variable-buffer-local 'outline-prefix-char)
(setq-default outline-prefix-char "\C-l")
(make-variable-buffer-local 'outline-regexp)
(setq-default outline-regexp "[*\l]+")
(make-variable-buffer-local 'outline-level-function)
(setq-default outline-level-function 'outline-level-default)
(autoload 'ispell-word "ispell"
  "Check the spelling of word in buffer." t)
(global-set-key "\e$" 'ispell-word)
(autoload 'ispell-region "ispell"
  "Check the spelling of region." t)
(autoload 'ispell-buffer "ispell"
  "Check the spelling of buffer." t)
(autoload 'ispell-complete-word "ispell"
  "Look up current word in dictionary and try to complete it." t)
(autoload 'ispell-change-dictionary "ispell"
  "Change ispell dictionary." t)

(setq auto-mode-alist
   (append  '(("\\.st$" . smalltalk-mode))
       auto-mode-alist))

(autoload 'smalltalk-mode "/usr/emacs/lisp/st.el" "" t)
