exit
ls -al
term
00
ls -al
cp /.kermrc 
cp /.kermrc .
ls -la
cd .term/
ls
ls -al
cp /.term/termrc ,
mv , termrc
ls -al
less termrc 
exit
