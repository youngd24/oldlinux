chmod 755 clisp
exit
trsh
cd
cd
exit
w
exit
