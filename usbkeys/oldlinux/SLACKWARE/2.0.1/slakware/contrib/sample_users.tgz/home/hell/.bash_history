ls -al
cp /.kermrc .
term
00
ls -la
cd .term/
ls
cp /.term/termrc .
ls -al
cd ..
ls
ls -al
exit
