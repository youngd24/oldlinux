echo "gonzo::418:100::/home/gonzo:/bin/bash" >> etc/passwd
echo "satan::419:100::/home/hell:/bin/bash" >> etc/passwd
echo "snake::420:100::/home/pit:/bin/bash" >> etc/passwd
chown --recursive gonzo.users home/gonzo
chown --recursive satan.users home/hell
chown --recursive snake.users home/pit
chown gonzo.mail var/spool/mail/gonzo
chown snake.mail var/spool/mail/snake
chown satan.mail var/spool/mail/satan
touch var/spool/mail/root
chown root.mail var/spool/mail/root
chmod 660 var/spool/mail/*
chgrp mail var/spool/mail/*
