/* Tiny GCC Library
 * stdlib.h
 * J�rg H�hle, 29-Nov-92
 */

#ifndef _STDLIB_H_
#define _STDLIB_H_

volatile void exit (int);

#endif /* _STDLIB_H_ */
