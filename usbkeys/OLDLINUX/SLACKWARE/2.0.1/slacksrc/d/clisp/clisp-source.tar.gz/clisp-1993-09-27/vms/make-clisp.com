$!
$!    Command file to build CLISP on VMS
$!    Run this as     @MAKE-CLISP
$!
$!    Written by Bruno Haible with the help of David Link 4.3.1993
$!
$! Set the default directory to proper place for use in batch.
$! Works for interactive too.
$ flnm = f$enviroment("PROCEDURE")     ! get current procedure name
$ set default 'f$parse(flnm,,,"DEVICE")''f$parse(flnm,,,"DIRECTORY")'
$ set default [.-]
$!
$! 
$!                      Character set conversions
$!
$! Not done here. We assume the sources were already converted by
$! "all-to-ascii" on a Unix machine and then transferred to VMS using
$! FTP in ASCII mode.
$!
$! set default [.unix]
$! cc /optimize cv-to-ascii.c
$! link cv-to-ascii
$! set default [.-]
$! convert ANNOUNCE, COPYRIGHT, GNU-GPL, INSTALL, SUMMARY,
$!         src/*.*, utils/*.*, unix/*.*, doc/*.*
$!
$!
$ create /directory [.build]
$ set default [.build]
$!
$!
$!                      Target "make init"
$!
$! Build ccpaux.exe
$ copy [.-.utils]ccpaux.c ccpaux.c
$ cc /optimize ccpaux.c
$ link ccpaux
$!delete ccpaux.c;*
$ delete ccpaux.obj;*
$!
$! Build comment5.exe
$ define sys$input [.-.utils]comment5.c
$ define sys$output comment5.c
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ cc /optimize comment5.c
$ link comment5
$!delete comment5.c;*
$ delete comment5.obj;*
$!
$! Build deerror.exe
$ copy [.-.utils]deerror.c deerror.c
$ cc /optimize deerror.c
$ link deerror
$!delete deerror.c;*
$ delete deerror.obj;*
$!
$! Build unixconf.h
$ copy [.-.vms]unixconf.h unixconf.h
$!
$! Build machine.exe
$ copy [.-.src]machine.d machine.d
$ mc []comment5 machine
$ cc /optimize machine.c
$ link machine
$ delete machine.d;*
$!delete machine.c;*
$ delete machine.obj;*
$!
$! Build machine.h
$ define sys$output machine.h
$ run machine
$ deassign sys$output
$!
$! Build traddecl.exe
$ copy [.-.utils]traddecl.d traddecl.d
$ mc []comment5 traddecl
$ cc /optimize /define=("CUT_U_AND_L") traddecl.c
$ link traddecl
$ delete traddecl.d;*
$!delete traddecl.c;*
$ delete traddecl.obj;*
$!
$! Build mergestrings.exe
$ copy [.-.utils]mergestrings.d mergestrings.d
$ mc []comment5 mergestrings
$ define sys$input mergestrings.c
$ define sys$output mergestrings.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input mergestrings.c1
$ define sys$output mergestrings.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ cc /optimize /define=("BREAK_LINES=100") mergestrings.c
$ link mergestrings
$ delete mergestrings.d;*
$ delete mergestrings.c1;*
$!delete mergestrings.c;*
$ delete mergestrings.obj;*
$!
$! Build txt2c.exe
$ copy [.-.utils]txt2c.c txt2c.c
$ cc /optimize txt2c.c
$ link txt2c
$!delete txt2c.c;*
$ delete txt2c.obj;*
$!
$! Build generrors.exe
$ copy [.-.utils]generrors.c generrors.c
$ define sys$input generrors.c
$ define sys$output generrors.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input generrors.c1
$ define sys$output generrors.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ cc /optimize generrors.c
$ link generrors
$ delete generrors.c1;*
$!delete generrors.c;*
$ delete generrors.obj;*
$!
$! Build errors.c
$ define sys$output errors.c
$ run generrors
$ deassign sys$output
$!
$!
$!                      Target "make allc"
$!
$! Build spvw.c
$ copy [.-.src]spvw.d spvw.d
$ mc []comment5 spvw
$ delete spvw.d;*
$ define sys$input spvw.c
$ define sys$output spvw.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvw.c1
$ define sys$output spvw.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvw.c2
$ define sys$output spvw.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete spvw.c1;*
$ delete spvw.c2;*
$!
$! Build spvwtabf.c
$ copy [.-.src]spvwtabf.d spvwtabf.d
$ mc []comment5 spvwtabf
$ delete spvwtabf.d;*
$ define sys$input spvwtabf.c
$ define sys$output spvwtabf.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvwtabf.c1
$ define sys$output spvwtabf.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvwtabf.c2
$ define sys$output spvwtabf.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete spvwtabf.c1;*
$ delete spvwtabf.c2;*
$!
$! Build spvwtabs.c
$ copy [.-.src]spvwtabs.d spvwtabs.d
$ mc []comment5 spvwtabs
$ delete spvwtabs.d;*
$ define sys$input spvwtabs.c
$ define sys$output spvwtabs.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvwtabs.c1
$ define sys$output spvwtabs.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvwtabs.c2
$ define sys$output spvwtabs.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete spvwtabs.c1;*
$ delete spvwtabs.c2;*
$!
$! Build spvwtabo.c
$ copy [.-.src]spvwtabo.d spvwtabo.d
$ mc []comment5 spvwtabo
$ delete spvwtabo.d;*
$ define sys$input spvwtabo.c
$ define sys$output spvwtabo.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvwtabo.c1
$ define sys$output spvwtabo.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input spvwtabo.c2
$ define sys$output spvwtabo.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete spvwtabo.c1;*
$ delete spvwtabo.c2;*
$!
$! Build eval.c
$ copy [.-.src]eval.d eval.d
$ mc []comment5 eval
$ delete eval.d;*
$ define sys$input eval.c
$ define sys$output eval.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input eval.c1
$ define sys$output eval.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input eval.c2
$ define sys$output eval.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete eval.c1;*
$ delete eval.c2;*
$!
$! Build control.c
$ copy [.-.src]control.d control.d
$ mc []comment5 control
$ delete control.d;*
$ define sys$input control.c
$ define sys$output control.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input control.c1
$ define sys$output control.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input control.c2
$ define sys$output control.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete control.c1;*
$ delete control.c2;*
$!
$! Build pathname.c
$ copy [.-.src]pathname.d pathname.d
$ mc []comment5 pathname
$ delete pathname.d;*
$ define sys$input pathname.c
$ define sys$output pathname.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input pathname.c1
$ define sys$output pathname.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input pathname.c2
$ define sys$output pathname.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete pathname.c1;*
$ delete pathname.c2;*
$!
$! Build stream.c
$ copy [.-.src]stream.d stream.d
$ mc []comment5 stream
$ delete stream.d;*
$ define sys$input stream.c
$ define sys$output stream.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input stream.c1
$ define sys$output stream.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input stream.c2
$ define sys$output stream.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete stream.c1;*
$ delete stream.c2;*
$!
$! Build socket.c
$ copy [.-.src]socket.d socket.d
$ mc []comment5 socket
$ delete socket.d;*
$ define sys$input socket.c
$ define sys$output socket.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input socket.c1
$ define sys$output socket.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input socket.c2
$ define sys$output socket.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete socket.c1;*
$ delete socket.c2;*
$!
$! Build io.c
$ copy [.-.src]io.d io.d
$ mc []comment5 io
$ delete io.d;*
$ define sys$input io.c
$ define sys$output io.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input io.c1
$ define sys$output io.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input io.c2
$ define sys$output io.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete io.c1;*
$ delete io.c2;*
$!
$! Build array.c
$ copy [.-.src]array.d array.d
$ mc []comment5 array
$ delete array.d;*
$ define sys$input array.c
$ define sys$output array.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input array.c1
$ define sys$output array.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input array.c2
$ define sys$output array.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete array.c1;*
$ delete array.c2;*
$!
$! Build hashtabl.c
$ copy [.-.src]hashtabl.d hashtabl.d
$ mc []comment5 hashtabl
$ delete hashtabl.d;*
$ define sys$input hashtabl.c
$ define sys$output hashtabl.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input hashtabl.c1
$ define sys$output hashtabl.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input hashtabl.c2
$ define sys$output hashtabl.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete hashtabl.c1;*
$ delete hashtabl.c2;*
$!
$! Build list.c
$ copy [.-.src]list.d list.d
$ mc []comment5 list
$ delete list.d;*
$ define sys$input list.c
$ define sys$output list.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input list.c1
$ define sys$output list.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input list.c2
$ define sys$output list.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete list.c1;*
$ delete list.c2;*
$!
$! Build package.c
$ copy [.-.src]package.d package.d
$ mc []comment5 package
$ delete package.d;*
$ define sys$input package.c
$ define sys$output package.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input package.c1
$ define sys$output package.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input package.c2
$ define sys$output package.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete package.c1;*
$ delete package.c2;*
$!
$! Build record.c
$ copy [.-.src]record.d record.d
$ mc []comment5 record
$ delete record.d;*
$ define sys$input record.c
$ define sys$output record.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input record.c1
$ define sys$output record.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input record.c2
$ define sys$output record.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete record.c1;*
$ delete record.c2;*
$!
$! Build sequence.c
$ copy [.-.src]sequence.d sequence.d
$ mc []comment5 sequence
$ delete sequence.d;*
$ define sys$input sequence.c
$ define sys$output sequence.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input sequence.c1
$ define sys$output sequence.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input sequence.c2
$ define sys$output sequence.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete sequence.c1;*
$ delete sequence.c2;*
$!
$! Build charstrg.c
$ copy [.-.src]charstrg.d charstrg.d
$ mc []comment5 charstrg
$ delete charstrg.d;*
$ define sys$input charstrg.c
$ define sys$output charstrg.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input charstrg.c1
$ define sys$output charstrg.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input charstrg.c2
$ define sys$output charstrg.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete charstrg.c1;*
$ delete charstrg.c2;*
$!
$! Build debug.c
$ copy [.-.src]debug.d debug.d
$ mc []comment5 debug
$ delete debug.d;*
$ define sys$input debug.c
$ define sys$output debug.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input debug.c1
$ define sys$output debug.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input debug.c2
$ define sys$output debug.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete debug.c1;*
$ delete debug.c2;*
$!
$! Build misc.c
$ copy [.-.src]misc.d misc.d
$ mc []comment5 misc
$ delete misc.d;*
$ define sys$input misc.c
$ define sys$output misc.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input misc.c1
$ define sys$output misc.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input misc.c2
$ define sys$output misc.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete misc.c1;*
$ delete misc.c2;*
$!
$! Build predtype.c
$ copy [.-.src]predtype.d predtype.d
$ mc []comment5 predtype
$ delete predtype.d;*
$ define sys$input predtype.c
$ define sys$output predtype.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input predtype.c1
$ define sys$output predtype.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input predtype.c2
$ define sys$output predtype.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete predtype.c1;*
$ delete predtype.c2;*
$!
$! Build symbol.c
$ copy [.-.src]symbol.d symbol.d
$ mc []comment5 symbol
$ delete symbol.d;*
$ define sys$input symbol.c
$ define sys$output symbol.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input symbol.c1
$ define sys$output symbol.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input symbol.c2
$ define sys$output symbol.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete symbol.c1;*
$ delete symbol.c2;*
$!
$! Build lisparit.c
$ copy [.-.src]lisparit.d lisparit.d
$ mc []comment5 lisparit
$ delete lisparit.d;*
$ define sys$input lisparit.c
$ define sys$output lisparit.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input lisparit.c1
$ define sys$output lisparit.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input lisparit.c2
$ define sys$output lisparit.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete lisparit.c1;*
$ delete lisparit.c2;*
$!
$! Build vmsaux.c
$ copy [.-.src]vmsaux.d vmsaux.d
$ mc []comment5 vmsaux
$ delete vmsaux.d;*
$ define sys$input vmsaux.c
$ define sys$output vmsaux.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input vmsaux.c1
$ define sys$output vmsaux.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input vmsaux.c2
$ define sys$output vmsaux.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete vmsaux.c1;*
$ delete vmsaux.c2;*
$!
$! Build lispbibl.c
$ copy [.-.src]lispbibl.d lispbibl.d
$ mc []comment5 lispbibl
$ delete lispbibl.d;*
$ define sys$input lispbibl.c
$ define sys$output lispbibl.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input lispbibl.c1
$ define sys$output lispbibl.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input lispbibl.c2
$ define sys$output lispbibl.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete lispbibl.c1;*
$ delete lispbibl.c2;*
$!
$! Build fsubr.c
$ copy [.-.src]fsubr.d fsubr.d
$ mc []comment5 fsubr
$ delete fsubr.d;*
$ define sys$input fsubr.c
$ define sys$output fsubr.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input fsubr.c1
$ define sys$output fsubr.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input fsubr.c2
$ define sys$output fsubr.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete fsubr.c1;*
$ delete fsubr.c2;*
$!
$! Build subr.c
$ copy [.-.src]subr.d subr.d
$ mc []comment5 subr
$ delete subr.d;*
$ define sys$input subr.c
$ define sys$output subr.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input subr.c1
$ define sys$output subr.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input subr.c2
$ define sys$output subr.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete subr.c1;*
$ delete subr.c2;*
$!
$! Build pseudofun.c
$ copy [.-.src]pseudofun.d pseudofun.d
$ mc []comment5 pseudofun
$ delete pseudofun.d;*
$ define sys$input pseudofun.c
$ define sys$output pseudofun.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input pseudofun.c1
$ define sys$output pseudofun.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input pseudofun.c2
$ define sys$output pseudofun.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete pseudofun.c1;*
$ delete pseudofun.c2;*
$!
$! Build constsym.c
$ copy [.-.src]constsym.d constsym.d
$ mc []comment5 constsym
$ delete constsym.d;*
$ define sys$input constsym.c
$ define sys$output constsym.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input constsym.c1
$ define sys$output constsym.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input constsym.c2
$ define sys$output constsym.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete constsym.c1;*
$ delete constsym.c2;*
$!
$! Build constobj.c
$ copy [.-.src]constobj.d constobj.d
$ mc []comment5 constobj
$ delete constobj.d;*
$ define sys$input constobj.c
$ define sys$output constobj.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input constobj.c1
$ define sys$output constobj.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input constobj.c2
$ define sys$output constobj.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete constobj.c1;*
$ delete constobj.c2;*
$!
$! Build vms.c
$ copy [.-.src]vms.d vms.d
$ mc []comment5 vms
$ delete vms.d;*
$ define sys$input vms.c
$ define sys$output vms.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input vms.c1
$ define sys$output vms.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input vms.c2
$ define sys$output vms.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete vms.c1;*
$ delete vms.c2;*
$!
$! Build avl.c
$ copy [.-.src]avl.d avl.d
$ mc []comment5 avl
$ delete avl.d;*
$ define sys$input avl.c
$ define sys$output avl.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input avl.c1
$ define sys$output avl.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input avl.c2
$ define sys$output avl.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete avl.c1;*
$ delete avl.c2;*
$!
$! Build sort.c
$ copy [.-.src]sort.d sort.d
$ mc []comment5 sort
$ delete sort.d;*
$ define sys$input sort.c
$ define sys$output sort.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input sort.c1
$ define sys$output sort.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input sort.c2
$ define sys$output sort.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete sort.c1;*
$ delete sort.c2;*
$!
$! Build aridecl.c
$ copy [.-.src]aridecl.d aridecl.d
$ mc []comment5 aridecl
$ delete aridecl.d;*
$ define sys$input aridecl.c
$ define sys$output aridecl.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input aridecl.c1
$ define sys$output aridecl.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input aridecl.c2
$ define sys$output aridecl.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete aridecl.c1;*
$ delete aridecl.c2;*
$!
$! Build arilev0.c
$ copy [.-.src]arilev0.d arilev0.d
$ mc []comment5 arilev0
$ delete arilev0.d;*
$ define sys$input arilev0.c
$ define sys$output arilev0.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev0.c1
$ define sys$output arilev0.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev0.c2
$ define sys$output arilev0.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete arilev0.c1;*
$ delete arilev0.c2;*
$!
$! Build arilev1.c
$ copy [.-.src]arilev1.d arilev1.d
$ mc []comment5 arilev1
$ delete arilev1.d;*
$ define sys$input arilev1.c
$ define sys$output arilev1.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1.c1
$ define sys$output arilev1.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1.c2
$ define sys$output arilev1.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete arilev1.c1;*
$ delete arilev1.c2;*
$!
$! Build arilev1c.c
$ copy [.-.src]arilev1c.d arilev1c.d
$ mc []comment5 arilev1c
$ delete arilev1c.d;*
$ define sys$input arilev1c.c
$ define sys$output arilev1c.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1c.c1
$ define sys$output arilev1c.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1c.c2
$ define sys$output arilev1c.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete arilev1c.c1;*
$ delete arilev1c.c2;*
$!
$! Build arilev1e.c
$ copy [.-.src]arilev1e.d arilev1e.d
$ mc []comment5 arilev1e
$ delete arilev1e.d;*
$ define sys$input arilev1e.c
$ define sys$output arilev1e.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1e.c1
$ define sys$output arilev1e.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1e.c2
$ define sys$output arilev1e.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete arilev1e.c1;*
$ delete arilev1e.c2;*
$!
$! Build arilev1i.c
$ copy [.-.src]arilev1i.d arilev1i.d
$ mc []comment5 arilev1i
$ delete arilev1i.d;*
$ define sys$input arilev1i.c
$ define sys$output arilev1i.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1i.c1
$ define sys$output arilev1i.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input arilev1i.c2
$ define sys$output arilev1i.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete arilev1i.c1;*
$ delete arilev1i.c2;*
$!
$! Build intelem.c
$ copy [.-.src]intelem.d intelem.d
$ mc []comment5 intelem
$ delete intelem.d;*
$ define sys$input intelem.c
$ define sys$output intelem.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intelem.c1
$ define sys$output intelem.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intelem.c2
$ define sys$output intelem.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intelem.c1;*
$ delete intelem.c2;*
$!
$! Build intlog.c
$ copy [.-.src]intlog.d intlog.d
$ mc []comment5 intlog
$ delete intlog.d;*
$ define sys$input intlog.c
$ define sys$output intlog.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intlog.c1
$ define sys$output intlog.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intlog.c2
$ define sys$output intlog.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intlog.c1;*
$ delete intlog.c2;*
$!
$! Build intplus.c
$ copy [.-.src]intplus.d intplus.d
$ mc []comment5 intplus
$ delete intplus.d;*
$ define sys$input intplus.c
$ define sys$output intplus.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intplus.c1
$ define sys$output intplus.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intplus.c2
$ define sys$output intplus.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intplus.c1;*
$ delete intplus.c2;*
$!
$! Build intcomp.c
$ copy [.-.src]intcomp.d intcomp.d
$ mc []comment5 intcomp
$ delete intcomp.d;*
$ define sys$input intcomp.c
$ define sys$output intcomp.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intcomp.c1
$ define sys$output intcomp.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intcomp.c2
$ define sys$output intcomp.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intcomp.c1;*
$ delete intcomp.c2;*
$!
$! Build intbyte.c
$ copy [.-.src]intbyte.d intbyte.d
$ mc []comment5 intbyte
$ delete intbyte.d;*
$ define sys$input intbyte.c
$ define sys$output intbyte.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intbyte.c1
$ define sys$output intbyte.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intbyte.c2
$ define sys$output intbyte.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intbyte.c1;*
$ delete intbyte.c2;*
$!
$! Build intmal.c
$ copy [.-.src]intmal.d intmal.d
$ mc []comment5 intmal
$ delete intmal.d;*
$ define sys$input intmal.c
$ define sys$output intmal.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intmal.c1
$ define sys$output intmal.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intmal.c2
$ define sys$output intmal.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intmal.c1;*
$ delete intmal.c2;*
$!
$! Build intdiv.c
$ copy [.-.src]intdiv.d intdiv.d
$ mc []comment5 intdiv
$ delete intdiv.d;*
$ define sys$input intdiv.c
$ define sys$output intdiv.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intdiv.c1
$ define sys$output intdiv.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intdiv.c2
$ define sys$output intdiv.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intdiv.c1;*
$ delete intdiv.c2;*
$!
$! Build intgcd.c
$ copy [.-.src]intgcd.d intgcd.d
$ mc []comment5 intgcd
$ delete intgcd.d;*
$ define sys$input intgcd.c
$ define sys$output intgcd.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intgcd.c1
$ define sys$output intgcd.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intgcd.c2
$ define sys$output intgcd.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intgcd.c1;*
$ delete intgcd.c2;*
$!
$! Build int2adic.c
$ copy [.-.src]int2adic.d int2adic.d
$ mc []comment5 int2adic
$ delete int2adic.d;*
$ define sys$input int2adic.c
$ define sys$output int2adic.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input int2adic.c1
$ define sys$output int2adic.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input int2adic.c2
$ define sys$output int2adic.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete int2adic.c1;*
$ delete int2adic.c2;*
$!
$! Build intsqrt.c
$ copy [.-.src]intsqrt.d intsqrt.d
$ mc []comment5 intsqrt
$ delete intsqrt.d;*
$ define sys$input intsqrt.c
$ define sys$output intsqrt.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intsqrt.c1
$ define sys$output intsqrt.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intsqrt.c2
$ define sys$output intsqrt.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intsqrt.c1;*
$ delete intsqrt.c2;*
$!
$! Build intprint.c
$ copy [.-.src]intprint.d intprint.d
$ mc []comment5 intprint
$ delete intprint.d;*
$ define sys$input intprint.c
$ define sys$output intprint.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intprint.c1
$ define sys$output intprint.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intprint.c2
$ define sys$output intprint.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intprint.c1;*
$ delete intprint.c2;*
$!
$! Build intread.c
$ copy [.-.src]intread.d intread.d
$ mc []comment5 intread
$ delete intread.d;*
$ define sys$input intread.c
$ define sys$output intread.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input intread.c1
$ define sys$output intread.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input intread.c2
$ define sys$output intread.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete intread.c1;*
$ delete intread.c2;*
$!
$! Build rational.c
$ copy [.-.src]rational.d rational.d
$ mc []comment5 rational
$ delete rational.d;*
$ define sys$input rational.c
$ define sys$output rational.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input rational.c1
$ define sys$output rational.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input rational.c2
$ define sys$output rational.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete rational.c1;*
$ delete rational.c2;*
$!
$! Build sfloat.c
$ copy [.-.src]sfloat.d sfloat.d
$ mc []comment5 sfloat
$ delete sfloat.d;*
$ define sys$input sfloat.c
$ define sys$output sfloat.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input sfloat.c1
$ define sys$output sfloat.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input sfloat.c2
$ define sys$output sfloat.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete sfloat.c1;*
$ delete sfloat.c2;*
$!
$! Build ffloat.c
$ copy [.-.src]ffloat.d ffloat.d
$ mc []comment5 ffloat
$ delete ffloat.d;*
$ define sys$input ffloat.c
$ define sys$output ffloat.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input ffloat.c1
$ define sys$output ffloat.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input ffloat.c2
$ define sys$output ffloat.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete ffloat.c1;*
$ delete ffloat.c2;*
$!
$! Build dfloat.c
$ copy [.-.src]dfloat.d dfloat.d
$ mc []comment5 dfloat
$ delete dfloat.d;*
$ define sys$input dfloat.c
$ define sys$output dfloat.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input dfloat.c1
$ define sys$output dfloat.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input dfloat.c2
$ define sys$output dfloat.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete dfloat.c1;*
$ delete dfloat.c2;*
$!
$! Build lfloat.c
$ copy [.-.src]lfloat.d lfloat.d
$ mc []comment5 lfloat
$ delete lfloat.d;*
$ define sys$input lfloat.c
$ define sys$output lfloat.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input lfloat.c1
$ define sys$output lfloat.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input lfloat.c2
$ define sys$output lfloat.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete lfloat.c1;*
$ delete lfloat.c2;*
$!
$! Build flo_konv.c
$ copy [.-.src]flo_konv.d flo_konv.d
$ mc []comment5 flo_konv
$ delete flo_konv.d;*
$ define sys$input flo_konv.c
$ define sys$output flo_konv.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input flo_konv.c1
$ define sys$output flo_konv.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input flo_konv.c2
$ define sys$output flo_konv.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete flo_konv.c1;*
$ delete flo_konv.c2;*
$!
$! Build flo_rest.c
$ copy [.-.src]flo_rest.d flo_rest.d
$ mc []comment5 flo_rest
$ delete flo_rest.d;*
$ define sys$input flo_rest.c
$ define sys$output flo_rest.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input flo_rest.c1
$ define sys$output flo_rest.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input flo_rest.c2
$ define sys$output flo_rest.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete flo_rest.c1;*
$ delete flo_rest.c2;*
$!
$! Build realelem.c
$ copy [.-.src]realelem.d realelem.d
$ mc []comment5 realelem
$ delete realelem.d;*
$ define sys$input realelem.c
$ define sys$output realelem.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input realelem.c1
$ define sys$output realelem.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input realelem.c2
$ define sys$output realelem.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete realelem.c1;*
$ delete realelem.c2;*
$!
$! Build realrand.c
$ copy [.-.src]realrand.d realrand.d
$ mc []comment5 realrand
$ delete realrand.d;*
$ define sys$input realrand.c
$ define sys$output realrand.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input realrand.c1
$ define sys$output realrand.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input realrand.c2
$ define sys$output realrand.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete realrand.c1;*
$ delete realrand.c2;*
$!
$! Build realtran.c
$ copy [.-.src]realtran.d realtran.d
$ mc []comment5 realtran
$ delete realtran.d;*
$ define sys$input realtran.c
$ define sys$output realtran.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input realtran.c1
$ define sys$output realtran.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input realtran.c2
$ define sys$output realtran.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete realtran.c1;*
$ delete realtran.c2;*
$!
$! Build compelem.c
$ copy [.-.src]compelem.d compelem.d
$ mc []comment5 compelem
$ delete compelem.d;*
$ define sys$input compelem.c
$ define sys$output compelem.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input compelem.c1
$ define sys$output compelem.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input compelem.c2
$ define sys$output compelem.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete compelem.c1;*
$ delete compelem.c2;*
$!
$! Build comptran.c
$ copy [.-.src]comptran.d comptran.d
$ mc []comment5 comptran
$ delete comptran.d;*
$ define sys$input comptran.c
$ define sys$output comptran.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input comptran.c1
$ define sys$output comptran.c2
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ define sys$input comptran.c2
$ define sys$output comptran.c
$ run traddecl
$ deassign sys$output
$ deassign sys$input
$ delete comptran.c1;*
$ delete comptran.c2;*
$!
$! Build arivaxvms.c
$ copy [.-.src]arivaxvms.d arivaxvms.d
$ mc []comment5 arivaxvms
$ delete arivaxvms.d;*
$ define sys$input arivaxvms.c
$ define sys$output arivaxvms.c1
$ run ccpaux
$ deassign sys$output
$ deassign sys$input
$ define sys$input arivaxvms.c1
$ define sys$output arivaxvms.c
$ run deerror
$ deassign sys$output
$ deassign sys$input
$ delete arivaxvms.c1;*
$!
$!
$!                      Target "make allo"
$!
$! Build spvw.i
$ cc /include_directory=([.include]) /preprocess_only=spvw.i1 spvw.c
$ define sys$input spvw.i1
$ define sys$output spvw.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete spvw.i1;*
$!
$! Build spvwtabf.i
$ cc /include_directory=([.include]) /preprocess_only=spvwtabf.i1 spvwtabf.c
$ define sys$input spvwtabf.i1
$ define sys$output spvwtabf.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete spvwtabf.i1;*
$!
$! Build spvwtabs.i
$ cc /include_directory=([.include]) /preprocess_only=spvwtabs.i1 spvwtabs.c
$ define sys$input spvwtabs.i1
$ define sys$output spvwtabs.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete spvwtabs.i1;*
$!
$! Build spvwtabo.i
$ cc /include_directory=([.include]) /preprocess_only=spvwtabo.i1 spvwtabo.c
$ define sys$input spvwtabo.i1
$ define sys$output spvwtabo.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete spvwtabo.i1;*
$!
$! Build eval.i
$ cc /include_directory=([.include]) /preprocess_only=eval.i1 eval.c
$ define sys$input eval.i1
$ define sys$output eval.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete eval.i1;*
$!
$! Build control.i
$ cc /include_directory=([.include]) /preprocess_only=control.i1 control.c
$ define sys$input control.i1
$ define sys$output control.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete control.i1;*
$!
$! Build pathname.i
$ cc /include_directory=([.include]) /preprocess_only=pathname.i1 pathname.c
$ define sys$input pathname.i1
$ define sys$output pathname.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete pathname.i1;*
$!
$! Build stream.i
$ cc /include_directory=([.include]) /preprocess_only=stream.i1 stream.c
$ define sys$input stream.i1
$ define sys$output stream.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete stream.i1;*
$!
$! Build socket.i
$ cc /include_directory=([.include]) /preprocess_only=socket.i1 socket.c
$ define sys$input socket.i1
$ define sys$output socket.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete socket.i1;*
$!
$! Build io.i
$ cc /include_directory=([.include]) /preprocess_only=io.i1 io.c
$ define sys$input io.i1
$ define sys$output io.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete io.i1;*
$!
$! Build array.i
$ cc /include_directory=([.include]) /preprocess_only=array.i1 array.c
$ define sys$input array.i1
$ define sys$output array.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete array.i1;*
$!
$! Build hashtabl.i
$ cc /include_directory=([.include]) /preprocess_only=hashtabl.i1 hashtabl.c
$ define sys$input hashtabl.i1
$ define sys$output hashtabl.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete hashtabl.i1;*
$!
$! Build list.i
$ cc /include_directory=([.include]) /preprocess_only=list.i1 list.c
$ define sys$input list.i1
$ define sys$output list.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete list.i1;*
$!
$! Build package.i
$ cc /include_directory=([.include]) /preprocess_only=package.i1 package.c
$ define sys$input package.i1
$ define sys$output package.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete package.i1;*
$!
$! Build record.i
$ cc /include_directory=([.include]) /preprocess_only=record.i1 record.c
$ define sys$input record.i1
$ define sys$output record.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete record.i1;*
$!
$! Build sequence.i
$ cc /include_directory=([.include]) /preprocess_only=sequence.i1 sequence.c
$ define sys$input sequence.i1
$ define sys$output sequence.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete sequence.i1;*
$!
$! Build charstrg.i
$ cc /include_directory=([.include]) /preprocess_only=charstrg.i1 charstrg.c
$ define sys$input charstrg.i1
$ define sys$output charstrg.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete charstrg.i1;*
$!
$! Build debug.i
$ cc /include_directory=([.include]) /preprocess_only=debug.i1 debug.c
$ define sys$input debug.i1
$ define sys$output debug.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete debug.i1;*
$!
$! Build misc.i
$ cc /include_directory=([.include]) /preprocess_only=misc.i1 misc.c
$ define sys$input misc.i1
$ define sys$output misc.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete misc.i1;*
$!
$! Build predtype.i
$ cc /include_directory=([.include]) /preprocess_only=predtype.i1 predtype.c
$ define sys$input predtype.i1
$ define sys$output predtype.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete predtype.i1;*
$!
$! Build symbol.i
$ cc /include_directory=([.include]) /preprocess_only=symbol.i1 symbol.c
$ define sys$input symbol.i1
$ define sys$output symbol.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete symbol.i1;*
$!
$! Build lisparit.i
$ cc /include_directory=([.include]) /preprocess_only=lisparit.i1 lisparit.c
$ define sys$input lisparit.i1
$ define sys$output lisparit.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete lisparit.i1;*
$!
$! Build vmsaux.i
$ cc /include_directory=([.include]) /preprocess_only=vmsaux.i1 vmsaux.c
$ define sys$input vmsaux.i1
$ define sys$output vmsaux.i
$ run mergestrings
$ deassign sys$output
$ deassign sys$input
$ delete vmsaux.i1;*
$!
$! Build spvw.obj
$ cc /optimize spvw.i
$!
$! Build spvwtabf.obj
$ cc /optimize spvwtabf.i
$!
$! Build spvwtabs.obj
$ cc /optimize spvwtabs.i
$!
$! Build spvwtabo.obj
$ cc /optimize spvwtabo.i
$!
$! Build eval.obj
$ cc /optimize eval.i
$!
$! Build control.obj
$ cc /optimize control.i
$!
$! Build pathname.obj
$ cc /optimize pathname.i
$!
$! Build stream.obj
$ cc /optimize stream.i
$!
$! Build socket.obj
$ cc /optimize socket.i
$!
$! Build io.obj
$ cc /optimize io.i
$!
$! Build array.obj
$ cc /optimize array.i
$!
$! Build hashtabl.obj
$ cc /optimize hashtabl.i
$!
$! Build list.obj
$ cc /optimize list.i
$!
$! Build package.obj
$ cc /optimize package.i
$!
$! Build record.obj
$ cc /optimize record.i
$!
$! Build sequence.obj
$ cc /optimize sequence.i
$!
$! Build charstrg.obj
$ cc /optimize charstrg.i
$!
$! Build debug.obj
$ cc /optimize debug.i
$!
$! Build misc.obj
$ cc /optimize misc.i
$!
$! Build predtype.obj
$ cc /optimize predtype.i
$!
$! Build symbol.obj
$ cc /optimize symbol.i
$!
$! Build lisparit.obj
$ cc /optimize lisparit.i
$!
$! Build vmsaux.obj
$ cc /optimize vmsaux.i
$!
$! Build arivaxvms.s
$ cc /preprocess_only=arivaxvms.s arivaxvms.c
$!
$! Build arivaxvms.obj
$ macro arivaxvms.s
$!
$!
$!                      Target "make lisp.exe"
$!
$! ??
$ link /executable=lisp.exe -
$_spvw.obj,spvwtabf.obj,spvwtabs.obj,spvwtabo.obj,-
$_eval.obj,control.obj,pathname.obj,stream.obj,socket.obj,io.obj,-
$_array.obj,hashtabl.obj,list.obj,package.obj,record.obj,sequence.obj,-
$_charstrg.obj,debug.obj,misc.obj,predtype.obj,symbol.obj,-
$_lisparit.obj,vmsaux.obj,arivaxvms.obj
$!
$!
$!                      Target "make alllsp"
$!
$! Build init.lsp
$ copy [.-.src]init.lsp init.lsp
$!
$! Build defseq.lsp
$ copy [.-.src]defseq.lsp defseq.lsp
$!
$! Build backquot.lsp
$ copy [.-.src]backquot.lsp backquot.lsp
$!
$! Build defmacro.lsp
$ copy [.-.src]defmacro.lsp defmacro.lsp
$!
$! Build macros1.lsp
$ copy [.-.src]macros1.lsp macros1.lsp
$!
$! Build macros2.lsp
$ copy [.-.src]macros2.lsp macros2.lsp
$!
$! Build defs1.lsp
$ copy [.-.src]defs1.lsp defs1.lsp
$!
$! Build places.lsp
$ copy [.-.src]places.lsp places.lsp
$!
$! Build floatpri.lsp
$ copy [.-.src]floatpri.lsp floatpri.lsp
$!
$! Build type.lsp
$ copy [.-.src]type.lsp type.lsp
$!
$! Build defstruc.lsp
$ copy [.-.src]defstruc.lsp defstruc.lsp
$!
$! Build format.lsp
$ copy [.-.src]format.lsp format.lsp
$!
$! Build user1.lsp
$ copy [.-.src]user1.lsp user1.lsp
$!
$! Build user2.lsp
$ copy [.-.src]user2.lsp user2.lsp
$!
$! Build trace.lsp
$ copy [.-.src]trace.lsp trace.lsp
$!
$! Build macros3.lsp
$ copy [.-.src]macros3.lsp macros3.lsp
$!
$! Build config.lsp
$ copy [.-.src]cfgvms.lsp config.lsp
$!
$! Build compiler.lsp
$ copy [.-.src]compiler.lsp compiler.lsp
$!
$! Build defs2.lsp
$ copy [.-.src]defs2.lsp defs2.lsp
$!
$! Build screen.lsp
$ copy [.-.src]screen.lsp screen.lsp
$!
$! Build rexx.lsp
$ copy [.-.src]rexx.lsp rexx.lsp
$!
$! Build editor.lsp
$ copy [.-.src]editor.lsp editor.lsp
$!
$!
$!                      Target "make interpreted.mem"
$!
$! Build interpreted.mem
$ define sys$input [.-.vms]interpreted.in
$ define sys$output lisp.out
$ run lisp.exe
$ deassign sys$output
$ deassign sys$input
$ rename lispinit.mem interpreted.mem
$!delete lisp.out;*
$!
$!
$!                      Target "make compiled.mem"
$!
$! Build init.fas
$ mc []lisp.exe -M interpreted.mem -q -c init.lsp
$!
$! Build defseq.fas
$ mc []lisp.exe -M interpreted.mem -q -c defseq.lsp
$!
$! Build backquot.fas
$ mc []lisp.exe -M interpreted.mem -q -c backquot.lsp
$!
$! Build defmacro.fas
$ mc []lisp.exe -M interpreted.mem -q -c defmacro.lsp
$!
$! Build macros1.fas
$ mc []lisp.exe -M interpreted.mem -q -c macros1.lsp
$!
$! Build macros2.fas
$ mc []lisp.exe -M interpreted.mem -q -c macros2.lsp
$!
$! Build defs1.fas
$ mc []lisp.exe -M interpreted.mem -q -c defs1.lsp
$!
$! Build places.fas
$ mc []lisp.exe -M interpreted.mem -q -c places.lsp
$!
$! Build floatpri.fas
$ mc []lisp.exe -M interpreted.mem -q -c floatpri.lsp
$!
$! Build type.fas
$ mc []lisp.exe -M interpreted.mem -q -c type.lsp
$!
$! Build defstruc.fas
$ mc []lisp.exe -M interpreted.mem -q -c defstruc.lsp
$!
$! Build format.fas
$ mc []lisp.exe -M interpreted.mem -q -c format.lsp
$!
$! Build user1.fas
$ mc []lisp.exe -M interpreted.mem -q -c user1.lsp
$!
$! Build user2.fas
$ mc []lisp.exe -M interpreted.mem -q -c user2.lsp
$!
$! Build trace.fas
$ mc []lisp.exe -M interpreted.mem -q -c trace.lsp
$!
$! Build macros3.fas
$ mc []lisp.exe -M interpreted.mem -q -c macros3.lsp
$!
$! Build config.fas
$ mc []lisp.exe -M interpreted.mem -q -c config.lsp
$!
$! Build compiler.fas
$ mc []lisp.exe -M interpreted.mem -q -c compiler.lsp
$!
$! Build defs2.fas
$ mc []lisp.exe -M interpreted.mem -q -c defs2.lsp
$!
$! Build screen.fas
$ mc []lisp.exe -M interpreted.mem -q -c screen.lsp
$!
$! Build rexx.fas
$ mc []lisp.exe -M interpreted.mem -q -c rexx.lsp
$!
$! Build editor.fas
$ mc []lisp.exe -M interpreted.mem -q -c editor.lsp
$!
$! Build compiled.mem
$ define sys$input [.-.vms]compiled.in
$ define sys$output lisp.out
$ run lisp.exe
$ deassign sys$output
$ deassign sys$input
$ rename lispinit.mem compiled.mem
$!delete lisp.out;*
$!
$!
$!                      Target "make manual"
$!
$! Build ANNOUNCE
$ copy [.-]ANNOUNCE ANNOUNCE
$!
$! Build COPYRIGHT
$ copy [.-]COPYRIGHT COPYRIGHT
$!
$! Build GNU-GPL
$ copy [.-]GNU-GPL GNU-GPL
$!
$! Build SUMMARY
$ copy [.-]SUMMARY SUMMARY
$!
$! Build README
$ define sys$input [.-.src]_README
$ define sys$output txt.c
$ run txt2c
$ deassign sys$output
$ deassign sys$input
$ cc /include_directory=([.include]) txt.c
$ link txt
$ define sys$output README
$ run txt
$ deassign sys$output
$ delete txt.*;*
$!
$! Build impnotes.txt
$ define sys$input [.-.src]_impnotes.txt
$ define sys$output txt.c
$ run txt2c
$ deassign sys$output
$ deassign sys$input
$ cc /include_directory=([.include]) txt.c
$ link txt
$ define sys$output impnotes.txt
$ run txt
$ deassign sys$output
$ delete txt.*;*
$!
$! Build clisp.1
$ define sys$input [.-.src]_clisp.1
$ define sys$output txt.c
$ run txt2c
$ deassign sys$output
$ deassign sys$input
$ cc /include_directory=([.include]) txt.c
$ link txt
$ define sys$output clisp.1
$ run txt
$ deassign sys$output
$! delete empty lines from clisp.1. How??
$ delete txt.*;*
$!
#! Build clisp.man
$ define sys$input clisp.1
$ define sys$output clisp.man
$ #! nroff! How??
$ deassign sys$output
$ deassign sys$input
$!
$!
$!                      Target "make test"
$!
$ create /directory [.stage]
$ copy init.lsp [.stage]init.lsp
$ copy defseq.lsp [.stage]defseq.lsp
$ copy backquot.lsp [.stage]backquot.lsp
$ copy defmacro.lsp [.stage]defmacro.lsp
$ copy macros1.lsp [.stage]macros1.lsp
$ copy macros2.lsp [.stage]macros2.lsp
$ copy defs1.lsp [.stage]defs1.lsp
$ copy places.lsp [.stage]places.lsp
$ copy floatpri.lsp [.stage]floatpri.lsp
$ copy type.lsp [.stage]type.lsp
$ copy defstruc.lsp [.stage]defstruc.lsp
$ copy format.lsp [.stage]format.lsp
$ copy user1.lsp [.stage]user1.lsp
$ copy user2.lsp [.stage]user2.lsp
$ copy trace.lsp [.stage]trace.lsp
$ copy macros3.lsp [.stage]macros3.lsp
$ copy config.lsp [.stage]config.lsp
$ copy compiler.lsp [.stage]compiler.lsp
$ copy defs2.lsp [.stage]defs2.lsp
$ copy screen.lsp [.stage]screen.lsp
$ copy rexx.lsp [.stage]rexx.lsp
$ copy editor.lsp [.stage]editor.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]init.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]defseq.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]backquot.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]defmacro.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]macros1.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]macros2.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]defs1.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]places.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]floatpri.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]type.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]defstruc.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]format.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]user1.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]user2.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]trace.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]macros3.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]config.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]compiler.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]defs2.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]screen.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]rexx.lsp
$ mc []lisp.exe -M compiled.mem -q -c [.stage]editor.lsp
$! How to compare files??
$ compare init.fas [.stage]init.fas
$ compare defseq.fas [.stage]defseq.fas
$ compare backquot.fas [.stage]backquot.fas
$ compare defmacro.fas [.stage]defmacro.fas
$ compare macros1.fas [.stage]macros1.fas
$ compare macros2.fas [.stage]macros2.fas
$ compare defs1.fas [.stage]defs1.fas
$ compare places.fas [.stage]places.fas
$ compare floatpri.fas [.stage]floatpri.fas
$ compare type.fas [.stage]type.fas
$ compare defstruc.fas [.stage]defstruc.fas
$ compare format.fas [.stage]format.fas
$ compare user1.fas [.stage]user1.fas
$ compare user2.fas [.stage]user2.fas
$ compare trace.fas [.stage]trace.fas
$ compare macros3.fas [.stage]macros3.fas
$ compare config.fas [.stage]config.fas
$ compare compiler.fas [.stage]compiler.fas
$ compare defs2.fas [.stage]defs2.fas
$ compare screen.fas [.stage]screen.fas
$ compare rexx.fas [.stage]rexx.fas
$!
$!
$!                      Target "make testsuite"
$!
$ create /directory [.suite]
$ copy [.-.tests]*.lsp [.suite]
$ copy [.-.tests]*.tst [.suite]
$ set default [.suite]
$ run [.-]lisp.exe -M [.-]compiled.mem -i tests.lsp -x "(run-all-tests)"
$! The test passed if no .erg files were created.
$ set default [.-]
$!
$!
$!                      That's it.
