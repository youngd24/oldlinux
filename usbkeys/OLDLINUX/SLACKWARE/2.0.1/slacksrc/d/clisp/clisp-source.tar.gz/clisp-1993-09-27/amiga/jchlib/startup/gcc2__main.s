#APP
| GCC2 Library
| J�rg H�hle, 6-Mar-93
| GCC2 calls ___main() in _main()!

.text
	.even
.globl ___main
___main:
	rts
