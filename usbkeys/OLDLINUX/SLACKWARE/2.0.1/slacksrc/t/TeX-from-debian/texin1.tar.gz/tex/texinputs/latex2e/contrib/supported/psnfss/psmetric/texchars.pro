%%BeginDocument: texchars.pro
%%
%% create a small new font with some extra characters
%% S Rahtz December 1990; stolen from Amanda Walker's font for TeX
%%
/TeXZZencoding 256 array def
0 1 255  { TeXZZencoding exch /.notdef put } for
TeXZZencoding dup 0 /ff put dup 1
 /ffi put dup 2 /ffl put dup 3 /dotlessj put pop
/MakeTeXChars {
20 dict begin
        /FontType 3 def
        /FontMatrix [.001 0 0 .001 0 0] def
        /FontBBox [0 0 1000 1000] def
	/FontName exch def
	/BFont exch def
        /BaseFonts [ BFont findfont 1000 scalefont ] def
        /Encoding TeXZZencoding def
        /String 1 string def
        /CharProcs 5 dict def
        CharProcs begin
                /.notdef { } def
                /ff {
                        (ff) stringwidth exch 50 sub exch
                        0 0 moveto (ff) false charpath flattenpath pathbbox
                        exch 50 sub exch
                        6 copy setcachedevice
                        0 0 moveto (f) show -50 0 rmoveto (f) show
                } def
                /ffi {
                        (f\256) stringwidth exch 50 sub exch
                        0 0 moveto (f\256) false charpath flattenpath pathbbox
                        exch 50 sub exch
                        6 copy setcachedevice
                        0 0 moveto (f) show -50 0 rmoveto (\256) show
                } def
                /ffl {
                        (f\257) stringwidth exch 50 sub exch
                        0 0 moveto (f\257) false charpath flattenpath pathbbox
                        exch 50 sub exch
                        6 copy setcachedevice
                        0 0 moveto (f) show -50 0 rmoveto (\257) show
                } def
                /dotlessj {
                        (j) stringwidth
                        0 0 moveto (j) false charpath flattenpath pathbbox
                        6 copy setcachedevice newpath
                        0 0 moveto (\365) false charpath flattenpath pathbbox
                        newpath -1000 -1000 moveto
                        dup -1000 exch lineto
                        1000 exch lineto
                        1000 -1000 lineto
                        closepath clip
                        pop pop pop
                        0 0 moveto (j) show
                } def
        end
        /BuildChar {
                exch begin
                BaseFonts 0 get  setfont
                dup Encoding exch get
                dup CharProcs exch known
                        { CharProcs exch get exch pop exec }
                        { pop String exch 0 exch put
                          String stringwidth
                          newpath 0 0 moveto String false charpath
                          flattenpath pathbbox
                          setcachedevice
                          0 0 moveto
                          String show
                        } ifelse
                end
        } def
        currentdict
end
dup /FontName get exch definefont pop
} def
%%EndDocument
