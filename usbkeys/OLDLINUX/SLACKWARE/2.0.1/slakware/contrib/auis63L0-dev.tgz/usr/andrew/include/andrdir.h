/* ********************************************************************** *
 *         Copyright IBM Corporation 1988,1989 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE    *
* ********************************************************************** */

#define QUOTED_DEFAULT_XBASEDIR_ENV ""
 
#define QUOTED_DEFAULT_ANDREWDIR_ENV "/usr/andrew"
#define QUOTED_DEFAULT_LOCALDIR_ENV "/usr/local"
#define QUOTED_DEFAULT_ANDREWDIR_ANDREWSETUP "/usr/andrew/etc/AndrewSetup"
 
