/* TPG Local Overrides */

#undef DEFAULT_ANDREWDIR_ENV
#define DEFAULT_ANDREWDIR_ENV /usr/andrew

/* Turn on these flags so everything will be made - a full ATK */
#define	MK_BASIC_UTILS	1	/* = console + ezprint + preview + launchapp */
#define	MK_AUTHORING	1	/* = controllers + music + ness + createinset + layout */
#define	MK_AUX_UTILS	1	/* = datacat + toez + prefed */
#define	CONTRIB_ENV	1	/* Controls the construction of the contributed software */
#define	METAMAIL_ENV	1	/* We will use Metamail */
#define	RTF_ENV	1	/* Build rtf2 2rtf and scribetext */
#define	POSIX_ENV	1	/* Causes code mostly conformant to POSIX to be used where available */
#define	AMS_ENV	1	/* Andrew Message Delivery System is to be built */
#define	BUILDANDREWINSTALL_ENV 1	/* Use AUIS installer  - will strip */
#undef		ANDREW_MALLOC_ENV	/* Do not use this */

/*	Printing on a typical Linux installation */
#define print_FORMATCOMMAND "/usr/andrew/etc/atkprint /tmp/%s.n |"
#define print_PRINTCOMMAND " lpr -P$PRINTER"
#define print_PREVIEWCOMMAND " /usr/andrew/etc/atkpreview /tmp/%s.n"
#define print_PSCPRINTCOMMAND " lpr -P$PRINTER"

/*	Add these so we have "everything" (like Rochesters ATK) */
#define	MK_BASIC_UTILS    1
#define	MK_AUTHORING	    1
#define	MK_AUX_UTILS	    1
#define	MK_AUX_INSETS	    1
#define	MK_EXAMPLES	    1
#define	MK_CALC	    1
#define	MK_CHAMP	    1

/* Do not make some things cause of legal issues  (GPL copyright) */
#undef MK_GESTURES

/* Do not make some things cause they are just stupid or do not work */
#undef MK_CONSOLE
#undef MK_MUSIC
#undef MK_ZIP
