#!/bin/sh
#
#

DIR=@DIR@
AWK=@AWK@
SED=@SED@

FILE=$1
ROOT=`echo $1 | sed -e s/.ct$//`
BASE=`basename $ROOT`
TMP=ct$$.c

${SED} -f ${DIR}/ct_c.sed  ${FILE} \
	| ${AWK} -f ${DIR}/ct_c.awk rootname=${ROOT} outfile=${TMP} -

if grep "^#__ERROR_IN_FILE" ${TMP} > /dev/null; then
	rm ${TMP}
	exit 1
else
	mv ${TMP} ${BASE}.c
	exit 0
fi
