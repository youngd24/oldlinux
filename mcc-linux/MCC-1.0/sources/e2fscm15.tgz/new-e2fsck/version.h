/*
 * version.h --- controls the version number printed by the e2fs
 * programs.
 *
 * Copyright 1994, Theodore Ts'o.  This file may be redistributed
 * under the GNU Public License.
 */

#define E2FSPROGS_VERSION "0.5 ALPHA"
#define E2FSPROGS_DATE "15-Mar-94"
