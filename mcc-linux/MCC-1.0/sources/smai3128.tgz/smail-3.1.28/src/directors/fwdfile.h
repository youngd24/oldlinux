/* @(#)src/directors/fwdfile.h	1.3 7/11/92 11:48:35 */

/*
 *    Copyright (C) 1987, 1988 Ronald S. Karr and Landon Curt Noll
 *    Copyright (C) 1992  Ronald S. Karr
 * 
 * See the file COPYING, distributed with smail, for restriction
 * and warranty information.
 *
 * namei master id: @(#)src/directors/fwdfile.h	1.3 7/11/92 11:48:35
 */

/*
 * forward.h:
 *	interface file for forward file driver.
 */

/* boolean attributes for director.flags field */
#define FWD_CHECKOWNER	0x00010000
#define FWD_FORWARDTO	0x00020000

/* private information from director file entry */
struct forwardfile_private {
    char *file;				/* template for forward file */
    int modemask;			/* allowed mode bits ala umask(2) */
    char *caution;			/* users and directories not secure */
    char *unsecure;			/* unsecure users and directories */
    char *owners;			/* ownership restrictions */
    char *owngroups;			/* group ownership restrictions */
    char *prefix;			/* prefix required for a match */
    char *suffix;			/* suffix required for a match */
};
