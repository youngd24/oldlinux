export PATH=$PATH:. \
	DISPLAY=:0
if [ -f ~/.bashrc ]
then source ~/.bashrc
fi
