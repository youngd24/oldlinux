export PATH=$PATH:/sbin:/usr/sbin
if [ -f ~/.bashrc ]
then source ~/.bashrc
fi
