	.text
	.globl	__entry
__entry:
	.space	32
	jmp	_shared_loader
