The main Makefile is set up so that you can type any of these commands:

     make
     make install
     make clean

To make only, for example, telnet, give the command

     make dirs=telnet
