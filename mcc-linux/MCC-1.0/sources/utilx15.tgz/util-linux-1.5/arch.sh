#!/bin/sh
uname -m
