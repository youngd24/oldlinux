# needs NDMAKE (tested with version 4.31), Turbo C 2.0, Turbo Assembler
# (tested with version 1.0).  Can be easily modified to use Micoroft
# assembler instead.  Will work with Borland's make program (tested 
# with version 2.0) if you comment out the .SUFFIXES line.

CC = tcc
CFLAGS = -c -DTURBOC -DLINT -DNDEBUG
LD = tcc
LDFLAGS = -eBRIK
AS = tasm
ASFLAGS = -mx

# To use Borland's make program, comment out the following line
.SUFFIXES : .exe .obj .asm .c

.asm.obj :
	$(AS) $(ASFLAGS) $*.asm

.c.obj :
	$(CC) $(CFLAGS) $*.c

OBJS = brik.obj initcrc.obj getopt.obj turboc.obj addbfcrc.obj

brik.exe: $(OBJS)
	$(LD) $(LDFLAGS) $(OBJS)

brik.obj: brik.c brik.h assert.h

addbfcrc.obj: addbfcrc.asm
