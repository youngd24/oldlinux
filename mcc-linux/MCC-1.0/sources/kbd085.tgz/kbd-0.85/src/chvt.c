/*
 * chvt.c - aeb - 940227 - Change virtual terminal
 */
#include <sys/types.h>
#include <linux/vt.h>
#include <stdio.h>

main(int argc, char *argv[]) {
    int fd, num;

    if (argc != 2) {
	fprintf(stderr, "usage: chvt N\n");
	exit(1);
    }
    if ((fd = open("/dev/console", 0)) < 0)
      fd = 0;
    num = atoi(argv[1]);
    if (ioctl(fd,VT_ACTIVATE,num)) {
	perror("VT_ACTIVATE");
	exit(1);
    }
    exit(0);
}
