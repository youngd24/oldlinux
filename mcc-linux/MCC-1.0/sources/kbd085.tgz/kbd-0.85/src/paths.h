/*
 * All data is in subdirectories of DATADIR, by default /usr/lib/kbd
 * The following three subdirectories are defined:
 */
#define KEYMAPDIR "keytables"
#define FONTDIR "consolefonts"
#define TRANSDIR "consoletrans"

/*
 * Default keymap, and where the kernel copy of it lives.
 */
#define DEFMAP "defkeymap.map"
#define KERNDIR "/usr/src/linux/drivers/char"
