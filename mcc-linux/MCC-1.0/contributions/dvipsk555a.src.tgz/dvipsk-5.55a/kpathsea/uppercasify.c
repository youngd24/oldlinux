/* uppercasify.c: change all lowercase letters to uppercase.

Copyright (C) 1993 Karl Berry.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#include <kpathsea/config.h>

#include <kpathsea/c-ctype.h>


string
uppercasify P1C(const_string, s)
{
  string target;
  string ret = xstrdup (s);
  
  for (target = ret; *target; target++)
    {
      *target = TOUPPER (*target);
    }
  
  return ret;
}
