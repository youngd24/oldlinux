#! /bin/sh
tput clear
