#! /bin/sh

echo "Address  Symbol   	Defined by"
if [ $# -eq 1 ]
then
	if [ A$1 = A-a ]
	then
		cat /proc/ksyms
	fi
else
	cat /proc/ksyms | grep ']$'
fi
