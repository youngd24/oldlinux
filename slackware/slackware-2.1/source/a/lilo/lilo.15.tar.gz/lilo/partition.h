/* partition.h  -  Partition table handling */

/* Copyright 1992-1994 Werner Almesberger. See file COPYING for details. */


#ifndef _PARTITION_H_
#define _PARTITION_H_

void part_verify(int dev_nr);

/* Verify the partition table of the disk of which dev_nr is a partition. May
   also try to "fix" a partition table. */

#endif
