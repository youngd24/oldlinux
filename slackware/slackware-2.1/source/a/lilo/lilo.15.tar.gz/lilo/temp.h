/* temp.h  -  Temporary file registry */

/* Copyright 1992-1994 Werner Almesberger. See file COPYING for details. */


#ifndef _TEMP_H_
#define _TEMP_H_


void temp_register(char *name);

/* Registers a file for removal at exit. */

void temp_unregister(char *name);

/* Removes the specified file from the temporary file list. */

void temp_remove(void);

/* Removes all temporary files. */

#endif
