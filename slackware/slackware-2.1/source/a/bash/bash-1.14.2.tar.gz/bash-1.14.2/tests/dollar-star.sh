recho "$*"
