/*
	common.h
*/

#define max(x,y)	((x) > (y) ? (x) : (y))
#define strncopy(x,y)	strncpy (x, y, sizeof(x))

void errorf (char *fmt, ...);
char *leafname (char *path);
void stty_initstore (void);
int  stty_raw (int fd);
void stty_orig (void);
