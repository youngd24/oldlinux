/*
	config.h
	
	edit this to suit your own taste
*/

#define	TERM_CHAR	31			/* ctrl + '-' */
#define TC_STRING	"Ctrl+'-'"

#define SNOOPTAB	"/etc/snooptab"
