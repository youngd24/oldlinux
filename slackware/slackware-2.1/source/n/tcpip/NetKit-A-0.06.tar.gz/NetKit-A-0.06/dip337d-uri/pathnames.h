/*
 * pathnames	This file contains the definitions of the path names used
 *		by the NET base distribution.  Do not change the values!
 *
 * Version:	@(#)pathnames.h	1.30	09/06/93
 *
 * Author:	Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
 */

#define _PATH_BIN_IFCONFIG	"/sbin/ifconfig"
#define _PATH_BIN_ROUTE		"/sbin/route"

#define _PATH_ETC_DIPHOSTS	"/etc/diphosts"
#define _PATH_DIP_PID		"/var/run/dip.pid"

#define _PATH_LOCKD		"/var/lock"	/* lock files	*/

#define _UID_UUCP		"uucp"			/* owns locks	*/

/* End of pathnames.h */
