###############################################################################
##
##  defs.sls - note that some of these packages aren't in the latest
##			sls I've seen (v1.02) but you'll get the idea
##
## (this is a semi-traditional /usr/local/bin and /usr/local/lib/* setup)
##
###############################################################################
#
# for elm
#
s:NEWSPAK_ELM_BIN_DIR:/usr/local/bin:
s:NEWSPAK_ELM_LIB_DIR:/usr/local/lib/elm:
s:NEWSPAK_ELM_MAN_DIR:/usr/man:
#
# for metamail
#
s:NEWSPAK_METAMAIL_BIN_DIR:/usr/local/bin:
#
# for mthreads (trn's threader) 
#
s:NEWSPAK_MTHREADS_LIB_DIR:/usr/local/lib/mthreads:
s:NEWSPAK_MTHREADS_MAN_DIR:/usr/man:
#
# for Cnews or INN
#
s:NEWSPAK_NEWS_BIN_DIR:/usr/local/lib/news/bin:
s:NEWSPAK_NEWS_ETC_DIR:/usr/local/lib/news/etc:
s:NEWSPAK_NEWS_LIB_DIR:/usr/local/lib/news:
s:NEWSPAK_NEWS_INND_DIR:/usr/local/lib/news/innd:
s:NEWSPAK_NEWS_MAN_DIR:/usr/man:
#
# for nn
#
s:NEWSPAK_NN_BIN_DIR:/usr/local/bin:
s:NEWSPAK_NN_LIB_DIR:/usr/local/lib/nn:
s:NEWSPAK_NN_MAN_DIR:/usr/man:
#
# for the articles themselves
#
s:NEWSPAK_SPOOL_DIR:/usr/spool/news:
#
# for tin 
#
s:NEWSPAK_TIN_BIN_DIR:/usr/local/bin:
s:NEWSPAK_TIN_MAN_DIR:/usr/man/man:
#
# for trn
#
s:NEWSPAK_TRN_BIN_DIR:/usr/local/bin:
s:NEWSPAK_TRN_LIB_DIR:/usr/local/lib/trn:
s:NEWSPAK_TRN_MAN_DIR:/usr/man:
#
# for taylor uucp 
#	Warning - messing with locations of
#	of uucp software that usually goes in
#	/usr/bin can cause lots of pain with
#	the mail side of things...
#
s:NEWSPAK_UUCPPUBLIC_DIR:/usr/spool/uucppublic:
s:NEWSPAK_UUCP_SPOOL_DIR:/usr/spool/uucp:
s:NEWSPAK_UUCP_LIB_DIR:/usr/lib/uucp:
#
###############################################################################
