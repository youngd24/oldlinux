dnl #--------------------------------------------------------------------
dnl # This file is an m4 specification for generating sendmail config
dnl # files.
dnl #
dnl # Note that one way to create m4 comments which are not reflected in
dnl # the m4 output files is to use dnl - d(elete to) n(ew) l(ine).
dnl #
dnl # 'LIBDIR' is built into the binary as /usr/local/lib/mail
dnl # but you can override it below with:
dnl #                 define(LIBDIR,/put/your/path/here)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # define the local mailer we use here
dnl #
define(LOCAL_MAILER_DEF, mailers.linux)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # the postmaster gets copies of all bounced mail for debugging
dnl #
dnl # next one gives an error from SLS m4 but I don't know why
define(POSTMASTERBOUNCE)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # define bogus domains so we don't do name server lookups on them
dnl #
define(PSEUDODOMAINS, BITNET UUCP)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # addresses we say 'is us' that we accept mail addressed to
dnl #
define(PSEUDONYMS, sample.primary.domain sample.another.domain.we.are.in sample.UUCP)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # address we want our mail to appear to come from
dnl # 
define(DEFAULT_HOST, sample.primary.domain)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # our uucp name
dnl #
define(UUCPNAME, sample)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # how to get a list of systems we talk uucp directly with
dnl #
define(UUCPNODES, |uuname|sort|uniq)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl #     make sure that 'bang' addresses are treated as uucp
dnl #
dnl next two give errors from SLS's m4 but I don't know why
define(BANGIMPLIESUUCP)dnl
define(BANGONLYUUCP)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # Our smart relay system and which mailer we use to get to them
dnl #
define(RELAY_HOST, my_uucp_neighbor)dnl
dnl #
dnl # We are uucp only, but domainized headers (therefore UUCP-A mailer)
dnl #
define(RELAY_MAILER, UUCP-A)dnl
dnl #
dnl #--------------------------------------------------------------------
dnl #
dnl # the various dbm lookup tables
dnl #
define(ALIASES, LIBDIR/aliases)dnl               ### system aliases
define(DOMAINTABLE, LIBDIR/domaintable)dnl       ### domainize hosts
dnl # define(PATHTABLE, LIBDIR/pathtable)dnl     ### paths database
dnl # define(GENERICFROM, LIBDIR/generics)dnl    ### generic from addresses
define(MAILERTABLE, LIBDIR/mailertable)dnl       ### define mailers per host or domain
define(UUCPXTABLE, LIBDIR/uucpxtable)dnl         ### paths to hosts we feed
dnl # define(UUCPRELAYS, LIBDIR/uucprelays)dnl   ### short-circuit paths
dnl #
dnl #--------------------------------------------------------------------
dnl #
include(Sendmail.mc)dnl                         ### REQUIRED ENTRY !!!
dnl #
dnl #--------------------------------------------------------------------
dnl #
