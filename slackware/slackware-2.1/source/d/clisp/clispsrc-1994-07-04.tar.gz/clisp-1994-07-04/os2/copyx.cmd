REM copies some OS/2 specific files into SRC
copy os2\forall.cmd src
copy dos\*.in src
copy dos\makefile src
copy dos\makefile.rl src\readline\makefile
copy dos\makefile.rle src\readline\examples\makefile
