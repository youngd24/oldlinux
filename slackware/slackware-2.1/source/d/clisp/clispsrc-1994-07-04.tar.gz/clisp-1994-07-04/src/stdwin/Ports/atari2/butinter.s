*
*	Interrupt routine that tells us exactly what the buttons
*	are doing. This is needed because evnt_multy cannot tell us.
*
	xref	ButState
	xref	OldInter
	xdef	ButInter
*
ButInter:
	move.w	d0,ButState
	move.l	OldInter,-(sp)
	rts
