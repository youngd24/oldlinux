
#include "window.h"

void
wsetdefwinsize(width, height)
int width;
int height;
{
	register int a;
/*
	Pop the whole stack of sizes and positions of closed windows.
*/
	num_w_pile = 0;

	if ( width < MIN_WIDTH ) width = MIN_WIDTH;
	if ( width > ( a = scr_width - w_l_border - w_r_border ) ) width = a;

	if ( height < w_min_height ) height = w_min_height;
	a = scr_height - (BAR_HEIGHT + w_min_v_pos + w_t_border + w_b_border);
	if ( height > a ) height = a;

	w_def = width + w_l_border + w_r_border;
	h_def = height + w_t_border + w_b_border;

	if ( max_width < ( a = w_def - w_l_border - w_r_border ) ) max_width = a;
	if ( max_height < ( a = h_def - w_t_border - w_b_border ) ) max_height = a;
}

