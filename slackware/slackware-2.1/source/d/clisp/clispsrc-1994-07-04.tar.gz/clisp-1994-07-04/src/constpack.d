# Liste aller zus�tzlichen dem C-Programm bekannten Packages
# Bruno Haible 30.8.1993

# Der Macro LISPPACK deklariert eine LISP-Package.
# LISPPACK(abbrev,packname)
# > abbrev: K�rzel, mit dem in constsym.d auf diese Package verwiesen wird
# > packname: C-Name der Package

# Expander f�r die Aufz�hlung:
  #define LISPPACK_A(abbrev,packname)  \
    enum_##abbrev##_index,

# Expander f�r die Konstruktion der Liste O(all_packages):
  #define LISPPACK_B(abbrev,packname)  \
    make_package(make_imm_array(asciz_to_string(packname)),NIL);

# Welcher Expander benutzt wird, mu� vom Hauptfile aus eingestellt werden.


LISPPACK(clos,"CLOS")
#ifdef WINDOWS
LISPPACK(screen,"SCREEN")
#endif
#ifdef STDWIN
LISPPACK(stdwin,"STDWIN")
#endif

