;; STDWIN-Paket
;; Bruno Haible 29.8.1993

(in-package "STDWIN" :use '("LISP"))

(defmacro drawing (window &body body)
  (let ((w (gensym)))
    `(LET ((,w ,window))
       (BEGIN-DRAWING ,w)
       (UNWIND-PROTECT (PROGN ,@body)
         (END-DRAWING ,w)
     ) )
) )

