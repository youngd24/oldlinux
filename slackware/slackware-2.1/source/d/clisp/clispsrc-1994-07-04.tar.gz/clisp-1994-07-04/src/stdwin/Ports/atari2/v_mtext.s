	xref	_GemParB,_VdiCtrl
	xdef	v_mtext
v_mtext:
	lea	_GemParB,a1
	move.w	d1,$1B6(a1)
	move.w	d2,$1B8(a1)
	move.w	#1,2(a1)
	move.w	4(sp),d2
	move.w	d2,6(a1)
	lea	$B6(a1),a1
	moveq	#0,d1
l1:	move.b	(a0)+,d1
	move.w	d1,(a1)+
	dbra	d2,l1
	lea	_GemParB,a0
	moveq	#8,d1
	bra	_VdiCtrl
