*
*	Gets the pointer to an array with three addresses.
*	The addresses are the tables with the key transformations.
*	Each table has 128 characters.
*
*	char **Keytbl(void *,void *,void *);
*
	xdef	Keytbl
*
Keytbl:	move.l	a2,-(sp)
	move.l	8(sp),-(sp)
	move.l	a1,-(sp)
	move.l	a0,-(sp)
	move.w	#16,-(sp)
	trap	#14
	lea	14(sp),sp
	move.l	(sp)+,a2
	move.l	d0,a0
	rts
