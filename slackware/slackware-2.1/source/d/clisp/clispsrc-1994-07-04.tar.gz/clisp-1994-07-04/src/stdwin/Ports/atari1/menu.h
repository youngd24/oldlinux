struct m_item {
        int     id ;
        char    *line ;
        char    *ittext ;
        char    *sctext ;
        int     enabled ;
        int     checked ;
} ;

struct menu {
        int     id ;
        char    *title ;
        bool    local ;
        bool    dirty ;
        int     maxlen ;
        int     nritems ;
        struct m_item   **itemlist ;
} ;

struct menubar {
        int     nrmenus ;
        MENU    **menulist ;
} ;

struct ln {
        int     m ;
        int     it ;
} ;

#define BAR     0x0110f0L
#define BOX     0x0ff10f0L
/*      (-1 << 16 | BLACK << 12 | WHITE << 8 | 1 << 7 | 7 << 4 | WHITE)       */
