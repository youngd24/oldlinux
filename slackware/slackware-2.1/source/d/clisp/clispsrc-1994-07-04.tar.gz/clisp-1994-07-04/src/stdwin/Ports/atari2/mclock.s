*
*	The Atari specific clock gives the number of ticks
*	since startup. It is a 200Hz clock, so multiplication
*	by 5 gives msecs. No wrapping is tested.
*	Wrap around after 2^32 msec ~ 50 days.
*
*	LONG mclock(VOID);
*
	xdef	mclock
*
mclock:	clr.l	-(sp)
	move.w	#$20,-(sp)
	trap	#1
	addq.l	#6,sp
	move.l	$4BA,d2
	move.l	d0,-(sp)
	move.w	#$20,-(sp)
	trap	#1
	addq.l	#6,sp
	move.l	d2,d0
	lsl.l	#2,d0
	add.l	d2,d0
	rts
