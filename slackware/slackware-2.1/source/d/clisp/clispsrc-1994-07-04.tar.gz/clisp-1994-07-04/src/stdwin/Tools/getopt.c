#include "stdwdefi.h"

#ifndef HAVE_GETOPT

#if defined(unix) || defined(__unix)
#define NULL    0
#define EOF     (-1)
#define ERR(s, c)  \
    if(opterr){\
        extern int strlen(), write();     \
        char errbuf[2];                   \
        errbuf[0] = c; errbuf[1] = '\n';  \
        write(2,argv[0],strlen(argv[0])); \
        write(2,s,strlen(s));             \
        write(2,errbuf,2);                \
    }
#else
/* Not unix -- assume <stdio.h> works, don't expect write(2). */
#include <stdio.h>
#define ERR(str, chr)  \
    if(opterr){\
        fprintf(stderr, "%s%s%c\n", argv[0], str, chr); \
    }
#endif

extern int strcmp();
extern char *strchr();

int     opterr = 1;
int     optind = 1;
int     optopt;
char    *optarg;

int
getopt(argc, argv, opts)
int     argc;
char    **argv, *opts;
{
        static int sp = 1;
        register int c;
        register char *cp;

        if(sp == 1)
                if(optind >= argc ||
                   argv[optind][0] != '-' || argv[optind][1] == '\0')
                        return(EOF);
                else if(strcmp(argv[optind], "--") == NULL) {
                        optind++;
                        return(EOF);
                }
        optopt = c = argv[optind][sp];
        if(c == ':' || (cp=strchr(opts, c)) == NULL) {
                ERR(": illegal option -- ", c);
                if(argv[optind][++sp] == '\0') {
                        optind++;
                        sp = 1;
                }
                return('?');
        }
        if(*++cp == ':') {
                if(argv[optind][sp+1] != '\0')
                        optarg = &argv[optind++][sp+1];
                else if(++optind >= argc) {
                        ERR(": option requires an argument -- ", c);
                        sp = 1;
                        return('?');
                } else
                        optarg = argv[optind++];
                sp = 1;
        } else {
                if(argv[optind][++sp] == '\0') {
                        sp = 1;
                        optind++;
                }
                optarg = NULL;
        }
        return(c);
}

#endif

