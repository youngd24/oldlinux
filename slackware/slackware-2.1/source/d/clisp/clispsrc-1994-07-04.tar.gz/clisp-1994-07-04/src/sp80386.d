# Kleine Routine, die den Wert des Maschinenstacks zur�ckliefert.

  #ifdef UNDERSCORE /* defined(__EMX__) || defined(__GO32__) || defined(linux) || defined(__386BSD__) || defined(__NetBSD__) || ... */
    #ifdef __STDC__
      #define C(entrypoint) _##entrypoint
    #else
      #define C(entrypoint) _/**/entrypoint
    #endif
  #else /* defined(sun) || defined(COHERENT) || ... */
    #define C(entrypoint) entrypoint
  #endif

        .text
        .align 2

        .globl C(getSP)

#    extern void* getSP (void);
C(getSP:)
        leal    4(%esp),%eax    # aktueller Wert von ESP + 4 wegen Unterprogrammaufruf
        ret

