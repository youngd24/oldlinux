*
*	Routine to pick up the address of the workstation parameters
*
*	typedef struct workparm {
*		struct workparm *next;
*		FONT font;
*	} *WORKPARM;
*
*	WORKPARM getaparm();
*
	xdef	getaparm
getaparm:
	move.l	a2,-(sp)
	dc.w	$A000
	lea	-$1D0(a0),a0
	move.l	(sp)+,a2
	rts
