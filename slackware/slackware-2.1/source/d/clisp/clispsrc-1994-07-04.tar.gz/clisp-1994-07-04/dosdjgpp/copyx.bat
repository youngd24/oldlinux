REM copies some DOS or DJGPP specific files into SRC
copy dos\forall.bat src
copy dos\*.in src
copy dosdjgpp\makefile src
copy dos\makefile.rl src\readline\makefile
copy dosdjgpp\makefile.rle src\readline\examples\makefile
