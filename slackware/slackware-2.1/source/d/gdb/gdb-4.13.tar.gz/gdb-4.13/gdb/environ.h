/* Header for environment manipulation library.
   Copyright 1989, 1992 Free Software Foundation.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#if !defined (ENVIRON_H)
#define ENVIRON_H 1

/* We manipulate environments represented as these structures.  */

struct environ
{
  /* Number of usable slots allocated in VECTOR.
     VECTOR always has one slot not counted here,
     to hold the terminating zero.  */
  int allocated;
  /* A vector of slots, ALLOCATED + 1 of them.
     The first few slots contain strings "VAR=VALUE"
     and the next one contains zero.
     Then come some unused slots.  */
  char **vector;
};

extern struct environ *
make_environ PARAMS ((void));

extern void
free_environ PARAMS ((struct environ *));

extern void
init_environ PARAMS ((struct environ *));

extern char *
get_in_environ PARAMS ((const struct environ *, const char *));

extern void
set_in_environ PARAMS ((struct environ *, const char *,
			const char *));

extern void
unset_in_environ PARAMS ((struct environ *, char *));

extern char **
environ_vector PARAMS ((struct environ *));

#endif	/* defined (ENVIRON_H) */
