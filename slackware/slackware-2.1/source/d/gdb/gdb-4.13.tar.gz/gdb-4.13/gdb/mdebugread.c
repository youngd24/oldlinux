/* Read a symbol table in ECOFF format (Third-Eye).
   Copyright 1986, 1987, 1989, 1990, 1991, 1992, 1993, 1994
   Free Software Foundation, Inc.
   Original version contributed by Alessandro Forin (af@cs.cmu.edu) at
   CMU.  Major work by Per Bothner, John Gilmore and Ian Lance Taylor
   at Cygnus Support.

This file is part of GDB.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* This module provides the function mdebug_build_psymtabs.  It reads
   ECOFF debugging information into partial symbol tables.  The
   debugging information is read from two structures.  A struct
   ecoff_debug_swap includes the sizes of each ECOFF structure and
   swapping routines; these are fixed for a particular target.  A
   struct ecoff_debug_info points to the debugging information for a
   particular object file.

   ECOFF symbol tables are mostly written in the byte order of the
   target machine.  However, one section of the table (the auxiliary
   symbol information) is written in the host byte order.  There is a
   bit in the other symbol info which describes which host byte order
   was used.  ECOFF thereby takes the trophy from Intel `b.out' for
   the most brain-dead adaptation of a file format to byte order.

   This module can read all four of the known byte-order combinations,
   on any type of host.  */

#include "defs.h"
#include "symtab.h"
#include "gdbtypes.h"
#include "gdbcore.h"
#include "symfile.h"
#include "objfiles.h"
#include "obstack.h"
#include "buildsym.h"
#include "stabsread.h"
#include "complaints.h"

#if !defined (SEEK_SET)
#define SEEK_SET 0
#define SEEK_CUR 1
#endif

/* These are needed if the tm.h file does not contain the necessary
   mips specific definitions.  */

#ifndef MIPS_EFI_SYMBOL_NAME
#define MIPS_EFI_SYMBOL_NAME "__GDB_EFI_INFO__"
#include "coff/sym.h"
#include "coff/symconst.h"
typedef struct mips_extra_func_info {
        long    numargs;
        PDR     pdr;
} *mips_extra_func_info_t;
#ifndef RA_REGNUM
#define RA_REGNUM 0
#endif
#endif

#ifdef USG
#include <sys/types.h>
#endif

#include <sys/param.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <string.h>

#include "gdb-stabs.h"

#include "bfd.h"

#include "coff/ecoff.h"		/* COFF-like aspects of ecoff files */

#include "libaout.h"		/* Private BFD a.out information.  */
#include "aout/aout64.h"
#include "aout/stab_gnu.h"	/* STABS information */

#include "expression.h"
#include "language.h"		/* Needed inside partial-stab.h */

/* Provide a default mapping from a ecoff register number to a gdb REGNUM.  */
#ifndef ECOFF_REG_TO_REGNUM
#define ECOFF_REG_TO_REGNUM(num) (num)
#endif

/* Each partial symbol table entry contains a pointer to private data
   for the read_symtab() function to use when expanding a partial
   symbol table entry to a full symbol table entry.

   For mdebugread this structure contains the index of the FDR that this
   psymtab represents and a pointer to the BFD that the psymtab was
   created from.  */

#define PST_PRIVATE(p) ((struct symloc *)(p)->read_symtab_private)
#define FDR_IDX(p) (PST_PRIVATE(p)->fdr_idx)
#define CUR_BFD(p) (PST_PRIVATE(p)->cur_bfd)
#define DEBUG_SWAP(p) (PST_PRIVATE(p)->debug_swap)
#define DEBUG_INFO(p) (PST_PRIVATE(p)->debug_info)
#define PENDING_LIST(p) (PST_PRIVATE(p)->pending_list)

struct symloc
{
  int fdr_idx;
  bfd *cur_bfd;
  const struct ecoff_debug_swap *debug_swap;
  struct ecoff_debug_info *debug_info;
  struct mdebug_pending **pending_list;
  EXTR *extern_tab;		/* Pointer to external symbols for this file. */
  int extern_count;		/* Size of extern_tab. */
  enum language pst_language;
};

/* Things we import explicitly from other modules */

extern int info_verbose;

/* Various complaints about symbol reading that don't abort the process */

static struct complaint bad_file_number_complaint =
{"bad file number %d", 0, 0};

static struct complaint index_complaint =
{"bad aux index at symbol %s", 0, 0};

static struct complaint aux_index_complaint =
{"bad proc end in aux found from symbol %s", 0, 0};

static struct complaint block_index_complaint =
{"bad aux index at block symbol %s", 0, 0};

static struct complaint unknown_ext_complaint =
{"unknown external symbol %s", 0, 0};

static struct complaint unknown_sym_complaint =
{"unknown local symbol %s", 0, 0};

static struct complaint unknown_st_complaint =
{"with type %d", 0, 0};

static struct complaint block_overflow_complaint =
{"block containing %s overfilled", 0, 0};

static struct complaint basic_type_complaint =
{"cannot map ECOFF basic type 0x%x for %s", 0, 0};

static struct complaint unknown_type_qual_complaint =
{"unknown type qualifier 0x%x", 0, 0};

static struct complaint array_index_type_complaint =
{"illegal array index type for %s, assuming int", 0, 0};

static struct complaint bad_tag_guess_complaint =
{"guessed tag type of %s incorrectly", 0, 0};

static struct complaint block_member_complaint =
{"declaration block contains unhandled symbol type %d", 0, 0};

static struct complaint stEnd_complaint =
{"stEnd with storage class %d not handled", 0, 0};

static struct complaint unknown_mdebug_symtype_complaint =
{"unknown symbol type 0x%x", 0, 0};

static struct complaint stab_unknown_complaint =
{"unknown stabs symbol %s", 0, 0};

static struct complaint pdr_for_nonsymbol_complaint =
{"PDR for %s, but no symbol", 0, 0};

static struct complaint pdr_static_symbol_complaint =
{"can't handle PDR for static proc at 0x%lx", 0, 0};

static struct complaint bad_setjmp_pdr_complaint =
{"fixing bad setjmp PDR from libc", 0, 0};

static struct complaint bad_fbitfield_complaint =
{"can't handle TIR fBitfield for %s", 0, 0};

static struct complaint bad_continued_complaint =
{"illegal TIR continued for %s", 0, 0};

static struct complaint bad_rfd_entry_complaint =
{"bad rfd entry for %s: file %d, index %d", 0, 0};

static struct complaint unexpected_type_code_complaint =
{"unexpected type code for %s", 0, 0};

static struct complaint unable_to_cross_ref_complaint =
{"unable to cross ref btTypedef for %s", 0, 0};

static struct complaint illegal_forward_tq0_complaint =
{"illegal tq0 in forward typedef for %s", 0, 0};

static struct complaint illegal_forward_bt_complaint =
{"illegal bt %d in forward typedef for %s", 0, 0};

static struct complaint bad_linetable_guess_complaint =
{"guessed size of linetable for %s incorrectly", 0, 0};

static struct complaint bad_ext_ifd_complaint =
{"bad ifd for external symbol: %d (max %d)", 0, 0};

static struct complaint bad_ext_iss_complaint =
{"bad iss for external symbol: %ld (max %ld)", 0, 0};

/* Macros and extra defs */

/* Puns: hard to find whether -g was used and how */

#define MIN_GLEVEL GLEVEL_0
#define compare_glevel(a,b)					\
	(((a) == GLEVEL_3) ? ((b) < GLEVEL_3) :			\
	 ((b) == GLEVEL_3) ? -1 : (int)((b) - (a)))

/* Things that really are local to this module */

/* Remember what we deduced to be the source language of this psymtab. */

static enum language psymtab_language = language_unknown;

/* Current BFD.  */

static bfd *cur_bfd;

/* How to parse debugging information for CUR_BFD.  */

static const struct ecoff_debug_swap *debug_swap;

/* Pointers to debugging information for CUR_BFD.  */

static struct ecoff_debug_info *debug_info;

/* Pointer to current file decriptor record, and its index */

static FDR *cur_fdr;
static int cur_fd;

/* Index of current symbol */

static int cur_sdx;

/* Note how much "debuggable" this image is.  We would like
   to see at least one FDR with full symbols */

static max_gdbinfo;
static max_glevel;

/* When examining .o files, report on undefined symbols */

static int n_undef_symbols, n_undef_labels, n_undef_vars, n_undef_procs;

/* Pseudo symbol to use when putting stabs into the symbol table.  */

static char stabs_symbol[] = STABS_SYMBOL;

/* Types corresponding to btComplex, btDComplex, etc.  These are here
   rather than in gdbtypes.c or some such, because the meaning of codes
   like btComplex is specific to the mdebug debug format.  FIXME:  We should
   be using our own types thoughout this file, instead of sometimes using
   builtin_type_*.  */

static struct type *mdebug_type_complex;
static struct type *mdebug_type_double_complex;
static struct type *mdebug_type_fixed_dec;
static struct type *mdebug_type_float_dec;
static struct type *mdebug_type_string;

/* Forward declarations */

static int
upgrade_type PARAMS ((int, struct type **, int, union aux_ext *, int, char *));

static void
parse_partial_symbols PARAMS ((struct objfile *,
			       struct section_offsets *));

static FDR
*get_rfd PARAMS ((int, int));

static int
has_opaque_xref PARAMS ((FDR *, SYMR *));

static int
cross_ref PARAMS ((int, union aux_ext *, struct type **, enum type_code,
		   char **, int, char *));

static struct symbol *
new_symbol PARAMS ((char *));

static struct type *
new_type PARAMS ((char *));

static struct block *
new_block PARAMS ((int));

static struct symtab *
new_symtab PARAMS ((char *, int, int, struct objfile *));

static struct linetable *
new_linetable PARAMS ((int));

static struct blockvector *
new_bvect PARAMS ((int));

static int
parse_symbol PARAMS ((SYMR *, union aux_ext *, char *, int, struct section_offsets *));

static struct type *
parse_type PARAMS ((int, union aux_ext *, unsigned int, int *, int, char *));

static struct symbol *
mylookup_symbol PARAMS ((char *, struct block *, enum namespace,
			 enum address_class));

static struct block *
shrink_block PARAMS ((struct block *, struct symtab *));

static PTR
xzalloc PARAMS ((unsigned int));

static void
sort_blocks PARAMS ((struct symtab *));

static int
compare_blocks PARAMS ((const void *, const void *));

static struct partial_symtab *
new_psymtab PARAMS ((char *, struct objfile *, struct section_offsets *));

static void
psymtab_to_symtab_1 PARAMS ((struct partial_symtab *, char *));

static void
add_block PARAMS ((struct block *, struct symtab *));

static void
add_symbol PARAMS ((struct symbol *, struct block *));

static int
add_line PARAMS ((struct linetable *, int, CORE_ADDR, int));

static struct linetable *
shrink_linetable PARAMS ((struct linetable *));

static void
handle_psymbol_enumerators PARAMS ((struct objfile *, FDR *, int));

static char *
mdebug_next_symbol_text PARAMS ((void));

/* Address bounds for the signal trampoline in inferior, if any */

CORE_ADDR sigtramp_address, sigtramp_end;

/* Allocate zeroed memory */

static PTR
xzalloc (size)
     unsigned int size;
{
  PTR p = xmalloc (size);

  memset (p, 0, size);
  return p;
}

/* Exported procedure: Builds a symtab from the PST partial one.
   Restores the environment in effect when PST was created, delegates
   most of the work to an ancillary procedure, and sorts
   and reorders the symtab list at the end */

static void
mdebug_psymtab_to_symtab (pst)
     struct partial_symtab *pst;
{

  if (!pst)
    return;

  if (info_verbose)
    {
      printf_filtered ("Reading in symbols for %s...", pst->filename);
      gdb_flush (gdb_stdout);
    }

  next_symbol_text_func = mdebug_next_symbol_text;

  psymtab_to_symtab_1 (pst, pst->filename);

  /* Match with global symbols.  This only needs to be done once,
     after all of the symtabs and dependencies have been read in.   */
  scan_file_globals (pst->objfile);

  if (info_verbose)
    printf_filtered ("done.\n");
}

/* File-level interface functions */

/* Find a file descriptor given its index RF relative to a file CF */

static FDR *
get_rfd (cf, rf)
     int cf, rf;
{
  FDR *fdrs;
  register FDR *f;
  RFDT rfd;

  fdrs = debug_info->fdr;
  f = fdrs + cf;
  /* Object files do not have the RFD table, all refs are absolute */
  if (f->rfdBase == 0)
    return fdrs + rf;
  (*debug_swap->swap_rfd_in) (cur_bfd,
			     ((char *) debug_info->external_rfd
			      + ((f->rfdBase + rf)
				 * debug_swap->external_rfd_size)),
			     &rfd);
  return fdrs + rfd;
}

/* Return a safer print NAME for a file descriptor */

static char *
fdr_name (f)
     FDR *f;
{
  if (f->rss == -1)
    return "<stripped file>";
  if (f->rss == 0)
    return "<NFY>";
  return debug_info->ss + f->issBase + f->rss;
}


/* Read in and parse the symtab of the file OBJFILE.  Symbols from
   different sections are relocated via the SECTION_OFFSETS.  */

void
mdebug_build_psymtabs (objfile, swap, info, section_offsets)
     struct objfile *objfile;
     const struct ecoff_debug_swap *swap;
     struct ecoff_debug_info *info;
     struct section_offsets *section_offsets;
{
  cur_bfd = objfile->obfd;
  debug_swap = swap;
  debug_info = info;

  /* Make sure all the FDR information is swapped in.  */
  if (info->fdr == (FDR *) NULL)
    {
      char *fdr_src;
      char *fdr_end;
      FDR *fdr_ptr;

      info->fdr = (FDR *) obstack_alloc (&objfile->psymbol_obstack,
					 (info->symbolic_header.ifdMax
					  * sizeof (FDR)));
      fdr_src = info->external_fdr;
      fdr_end = (fdr_src
		 + info->symbolic_header.ifdMax * swap->external_fdr_size);
      fdr_ptr = info->fdr;
      for (; fdr_src < fdr_end; fdr_src += swap->external_fdr_size, fdr_ptr++)
	(*swap->swap_fdr_in) (objfile->obfd, fdr_src, fdr_ptr);
    }

  parse_partial_symbols (objfile, section_offsets);

#if 0
  /* Check to make sure file was compiled with -g.  If not, warn the
     user of this limitation.  */
  if (compare_glevel (max_glevel, GLEVEL_2) < 0)
    {
      if (max_gdbinfo == 0)
	printf_unfiltered ("\n%s not compiled with -g, debugging support is limited.\n",
		 objfile->name);
      printf_unfiltered ("You should compile with -g2 or -g3 for best debugging support.\n");
      gdb_flush (gdb_stdout);
    }
#endif
}

/* Local utilities */

/* Map of FDR indexes to partial symtabs */

struct pst_map
{
  struct partial_symtab *pst;	/* the psymtab proper */
  long n_globals;		/* exported globals (external symbols) */
  long globals_offset;		/* cumulative */
};


/* Utility stack, used to nest procedures and blocks properly.
   It is a doubly linked list, to avoid too many alloc/free.
   Since we might need it quite a few times it is NOT deallocated
   after use. */

static struct parse_stack
{
  struct parse_stack *next, *prev;
  struct symtab *cur_st;	/* Current symtab. */
  struct block *cur_block;	/* Block in it. */

  /* What are we parsing.  stFile, or stBlock are for files and
     blocks.  stProc or stStaticProc means we have seen the start of a
     procedure, but not the start of the block within in.  When we see
     the start of that block, we change it to stNil, without pushing a
     new block, i.e. stNil means both a procedure and a block.  */

  int blocktype;

  int maxsyms;			/* Max symbols in this block. */
  struct type *cur_type;	/* Type we parse fields for. */
  int cur_field;		/* Field number in cur_type. */
  CORE_ADDR procadr;		/* Start addres of this procedure */
  int numargs;			/* Its argument count */
}

 *top_stack;			/* Top stack ptr */


/* Enter a new lexical context */

static void
push_parse_stack ()
{
  struct parse_stack *new;

  /* Reuse frames if possible */
  if (top_stack && top_stack->prev)
    new = top_stack->prev;
  else
    new = (struct parse_stack *) xzalloc (sizeof (struct parse_stack));
  /* Initialize new frame with previous content */
  if (top_stack)
    {
      register struct parse_stack *prev = new->prev;

      *new = *top_stack;
      top_stack->prev = new;
      new->prev = prev;
      new->next = top_stack;
    }
  top_stack = new;
}

/* Exit a lexical context */

static void
pop_parse_stack ()
{
  if (!top_stack)
    return;
  if (top_stack->next)
    top_stack = top_stack->next;
}


/* Cross-references might be to things we haven't looked at
   yet, e.g. type references.  To avoid too many type
   duplications we keep a quick fixup table, an array
   of lists of references indexed by file descriptor */

struct mdebug_pending
{
  struct mdebug_pending *next;	/* link */
  char *s;			/* the unswapped symbol */
  struct type *t;		/* its partial type descriptor */
};


/* The pending information is kept for an entire object file, and used
   to be in the sym_private field.  I took it out when I split
   mdebugread from mipsread, because this might not be the only type
   of symbols read from an object file.  Instead, we allocate the
   pending information table when we create the partial symbols, and
   we store a pointer to the single table in each psymtab.  */

static struct mdebug_pending **pending_list;

/* Check whether we already saw symbol SH in file FH */

static struct mdebug_pending *
is_pending_symbol (fh, sh)
     FDR *fh;
     char *sh;
{
  int f_idx = fh - debug_info->fdr;
  register struct mdebug_pending *p;

  /* Linear search is ok, list is typically no more than 10 deep */
  for (p = pending_list[f_idx]; p; p = p->next)
    if (p->s == sh)
      break;
  return p;
}

/* Add a new symbol SH of type T */

static void
add_pending (fh, sh, t)
     FDR *fh;
     char *sh;
     struct type *t;
{
  int f_idx = fh - debug_info->fdr;
  struct mdebug_pending *p = is_pending_symbol (fh, sh);

  /* Make sure we do not make duplicates */
  if (!p)
    {
      p = ((struct mdebug_pending *)
	   obstack_alloc (&current_objfile->psymbol_obstack,
			  sizeof (struct mdebug_pending)));
      p->s = sh;
      p->t = t;
      p->next = pending_list[f_idx];
      pending_list[f_idx] = p;
    }
}


/* Parsing Routines proper. */

/* Parse a single symbol. Mostly just make up a GDB symbol for it.
   For blocks, procedures and types we open a new lexical context.
   This is basically just a big switch on the symbol's type.  Argument
   AX is the base pointer of aux symbols for this file (fh->iauxBase).
   EXT_SH points to the unswapped symbol, which is needed for struct,
   union, etc., types; it is NULL for an EXTR.  BIGEND says whether
   aux symbols are big-endian or little-endian.  Return count of
   SYMR's handled (normally one).  */

static int
parse_symbol (sh, ax, ext_sh, bigend, section_offsets)
     SYMR *sh;
     union aux_ext *ax;
     char *ext_sh;
     int bigend;
     struct section_offsets *section_offsets;
{
  const bfd_size_type external_sym_size = debug_swap->external_sym_size;
  void (* const swap_sym_in) PARAMS ((bfd *, PTR, SYMR *)) =
    debug_swap->swap_sym_in;
  char *name;
  struct symbol *s;
  struct block *b;
  struct mdebug_pending *pend;
  struct type *t;
  struct field *f;
  int count = 1;
  enum address_class class;
  TIR tir;
  long svalue = sh->value;
  int bitsize;

  if (ext_sh == (char *) NULL)
    name = debug_info->ssext + sh->iss;
  else
    name = debug_info->ss + cur_fdr->issBase + sh->iss;

  switch (sh->sc)
    {
    case scText:
      /* The value of a stEnd symbol is the displacement from the
	 corresponding start symbol value, do not relocate it.  */
      if (sh->st != stEnd)
	sh->value += ANOFFSET (section_offsets, SECT_OFF_TEXT);
      break;
    case scData:
    case scSData:
    case scRData:
    case scPData:
    case scXData:
      sh->value += ANOFFSET (section_offsets, SECT_OFF_DATA);
      break;
    case scBss:
    case scSBss:
      sh->value += ANOFFSET (section_offsets, SECT_OFF_BSS);
      break;
    }

  switch (sh->st)
    {
    case stNil:
      break;

    case stGlobal:		/* external symbol, goes into global block */
      class = LOC_STATIC;
      b = BLOCKVECTOR_BLOCK (BLOCKVECTOR (top_stack->cur_st),
			     GLOBAL_BLOCK);
      s = new_symbol (name);
      SYMBOL_VALUE_ADDRESS (s) = (CORE_ADDR) sh->value;
      goto data;

    case stStatic:		/* static data, goes into current block. */
      class = LOC_STATIC;
      b = top_stack->cur_block;
      s = new_symbol (name);
      if (sh->sc == scCommon)
	{
	  /* It is a FORTRAN common block.  At least for SGI Fortran the
	     address is not in the symbol; we need to fix it later in
	     scan_file_globals.  */
	  int bucket = hashname (SYMBOL_NAME (s));
	  SYMBOL_VALUE_CHAIN (s) = global_sym_chain[bucket];
	  global_sym_chain[bucket] = s;
	}
      else
	SYMBOL_VALUE_ADDRESS (s) = (CORE_ADDR) sh->value;
      goto data;

    case stLocal:		/* local variable, goes into current block */
      if (sh->sc == scRegister)
	{
	  class = LOC_REGISTER;
	  svalue = ECOFF_REG_TO_REGNUM (svalue);
	}
      else
	class = LOC_LOCAL;
      b = top_stack->cur_block;
      s = new_symbol (name);
      SYMBOL_VALUE (s) = svalue;

    data:			/* Common code for symbols describing data */
      SYMBOL_NAMESPACE (s) = VAR_NAMESPACE;
      SYMBOL_CLASS (s) = class;
      add_symbol (s, b);

      /* Type could be missing in a number of cases */
      if (sh->sc == scUndefined || sh->sc == scNil)
	SYMBOL_TYPE (s) = builtin_type_int;	/* undefined? */
      else
	SYMBOL_TYPE (s) = parse_type (cur_fd, ax, sh->index, 0, bigend, name);
      /* Value of a data symbol is its memory address */
      break;

    case stParam:		/* arg to procedure, goes into current block */
      max_gdbinfo++;
      top_stack->numargs++;

      /* Special GNU C++ name.  */
      if (name[0] == CPLUS_MARKER && name[1] == 't' && name[2] == 0)
	name = "this";		/* FIXME, not alloc'd in obstack */
      s = new_symbol (name);

      SYMBOL_NAMESPACE (s) = VAR_NAMESPACE;
      switch (sh->sc)
	{
	case scRegister:
	  /* Pass by value in register.  */
	  SYMBOL_CLASS(s) = LOC_REGPARM;
	  svalue = ECOFF_REG_TO_REGNUM (svalue);
	  break;
	case scVar:
	  /* Pass by reference on stack.  */
	  SYMBOL_CLASS(s) = LOC_REF_ARG;
	  break;
	case scVarRegister:
	  /* Pass by reference in register.  */
	  SYMBOL_CLASS(s) = LOC_REGPARM_ADDR;
	  svalue = ECOFF_REG_TO_REGNUM (svalue);
	  break;
	default:
	  /* Pass by value on stack.  */
	  SYMBOL_CLASS(s) = LOC_ARG;
	  break;
	}
      SYMBOL_VALUE (s) = svalue;
      SYMBOL_TYPE (s) = parse_type (cur_fd, ax, sh->index, 0, bigend, name);
      add_symbol (s, top_stack->cur_block);
#if 0
      /* FIXME:  This has not been tested.  See dbxread.c */
      /* Add the type of this parameter to the function/procedure
		   type of this block. */
      add_param_to_type (&top_stack->cur_block->function->type, s);
#endif
      break;

    case stLabel:		/* label, goes into current block */
      s = new_symbol (name);
      SYMBOL_NAMESPACE (s) = VAR_NAMESPACE;	/* so that it can be used */
      SYMBOL_CLASS (s) = LOC_LABEL;	/* but not misused */
      SYMBOL_VALUE_ADDRESS (s) = (CORE_ADDR) sh->value;
      SYMBOL_TYPE (s) = builtin_type_int;
      add_symbol (s, top_stack->cur_block);
      break;

    case stProc:		/* Procedure, usually goes into global block */
    case stStaticProc:		/* Static procedure, goes into current block */
      s = new_symbol (name);
      SYMBOL_NAMESPACE (s) = VAR_NAMESPACE;
      SYMBOL_CLASS (s) = LOC_BLOCK;
      /* Type of the return value */
      if (sh->sc == scUndefined || sh->sc == scNil)
	t = builtin_type_int;
      else
	t = parse_type (cur_fd, ax, sh->index + 1, 0, bigend, name);
      b = top_stack->cur_block;
      if (sh->st == stProc)
	{
	  struct blockvector *bv = BLOCKVECTOR (top_stack->cur_st);
	  /* The next test should normally be true, but provides a
	     hook for nested functions (which we don't want to make
	     global). */
	  if (b == BLOCKVECTOR_BLOCK (bv, STATIC_BLOCK))
	    b = BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK);
	  /* Irix 5 sometimes has duplicate names for the same
	     function.  We want to add such names up at the global
	     level, not as a nested function.  */
	  else if (sh->value == top_stack->procadr)
	    b = BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK);
	}
      add_symbol (s, b);

      /* Make a type for the procedure itself */
#if 0
      /* FIXME:  This has not been tested yet!  See dbxread.c */
      /* Generate a template for the type of this function.  The
	 types of the arguments will be added as we read the symbol
	 table. */
      memcpy (lookup_function_type (t), SYMBOL_TYPE (s), sizeof (struct type));
#else
      SYMBOL_TYPE (s) = lookup_function_type (t);
#endif

      /* Create and enter a new lexical context */
      b = new_block (top_stack->maxsyms);
      SYMBOL_BLOCK_VALUE (s) = b;
      BLOCK_FUNCTION (b) = s;
      BLOCK_START (b) = BLOCK_END (b) = sh->value;
      BLOCK_SUPERBLOCK (b) = top_stack->cur_block;
      add_block (b, top_stack->cur_st);

      /* Not if we only have partial info */
      if (sh->sc == scUndefined || sh->sc == scNil)
	break;

      push_parse_stack ();
      top_stack->cur_block = b;
      top_stack->blocktype = sh->st;
      top_stack->cur_type = SYMBOL_TYPE (s);
      top_stack->cur_field = -1;
      top_stack->procadr = sh->value;
      top_stack->numargs = 0;
      break;

      /* Beginning of code for structure, union, and enum definitions.
	       They all share a common set of local variables, defined here.  */
      {
	enum type_code type_code;
	char *ext_tsym;
	int nfields;
	long max_value;
	struct field *f;

    case stStruct:		/* Start a block defining a struct type */
	type_code = TYPE_CODE_STRUCT;
	goto structured_common;

    case stUnion:		/* Start a block defining a union type */
	type_code = TYPE_CODE_UNION;
	goto structured_common;

    case stEnum:		/* Start a block defining an enum type */
	type_code = TYPE_CODE_ENUM;
	goto structured_common;

    case stBlock:		/* Either a lexical block, or some type */
	if (sh->sc != scInfo && sh->sc != scCommon)
	  goto case_stBlock_code;	/* Lexical block */

	type_code = TYPE_CODE_UNDEF;	/* We have a type.  */

	/* Common code for handling struct, union, enum, and/or as-yet-
	   unknown-type blocks of info about structured data.  `type_code'
	   has been set to the proper TYPE_CODE, if we know it.  */
      structured_common:
	push_parse_stack ();
	top_stack->blocktype = stBlock;

	/* First count the number of fields and the highest value. */
	nfields = 0;
	max_value = 0;
	for (ext_tsym = ext_sh + external_sym_size;
	     ;
	     ext_tsym += external_sym_size)
	  {
	    SYMR tsym;

	    (*swap_sym_in) (cur_bfd, ext_tsym, &tsym);

	    switch (tsym.st)
	      {
	      case stEnd:
		goto end_of_fields;

	      case stMember:
		if (nfields == 0 && type_code == TYPE_CODE_UNDEF)
		  /* If the type of the member is Nil (or Void),
		     without qualifiers, assume the tag is an
		     enumeration. */
		  if (tsym.index == indexNil)
		    type_code = TYPE_CODE_ENUM;
		  else
		    {
		      (*debug_swap->swap_tir_in) (bigend,
						  &ax[tsym.index].a_ti,
						  &tir);
		      if ((tir.bt == btNil || tir.bt == btVoid)
			  && tir.tq0 == tqNil)
			type_code = TYPE_CODE_ENUM;
		    }
		nfields++;
		if (tsym.value > max_value)
		  max_value = tsym.value;
		break;

	      case stBlock:
	      case stUnion:
	      case stEnum:
	      case stStruct:
		{
#if 0
		  /* This is a no-op; is it trying to tell us something
		     we should be checking?  */
		  if (tsym.sc == scVariant);	/*UNIMPLEMENTED*/
#endif
		  if (tsym.index != 0)
		    {
		      /* This is something like a struct within a
			 struct.  Skip over the fields of the inner
			 struct.  The -1 is because the for loop will
			 increment ext_tsym.  */
		      ext_tsym = ((char *) debug_info->external_sym
				  + ((cur_fdr->isymBase + tsym.index - 1)
				     * external_sym_size));
		    }
		}
		break;

	      case stTypedef:
		/* mips cc puts out a typedef for struct x if it is not yet
		   defined when it encounters
		   struct y { struct x *xp; };
		   Just ignore it. */
		break;

	      case stIndirect:
		/* Irix5 cc puts out a stIndirect for struct x if it is not
		   yet defined when it encounters
		   struct y { struct x *xp; };
		   Just ignore it. */
		break;

	      default:
		complain (&block_member_complaint, tsym.st);
	      }
	  }
      end_of_fields:;

	/* In an stBlock, there is no way to distinguish structs,
	   unions, and enums at this point.  This is a bug in the
	   original design (that has been fixed with the recent
	   addition of the stStruct, stUnion, and stEnum symbol
	   types.)  The way you can tell is if/when you see a variable
	   or field of that type.  In that case the variable's type
	   (in the AUX table) says if the type is struct, union, or
	   enum, and points back to the stBlock here.  So you can
	   patch the tag kind up later - but only if there actually is
	   a variable or field of that type.

	   So until we know for sure, we will guess at this point.
	   The heuristic is:
	   If the first member has index==indexNil or a void type,
	   assume we have an enumeration.
	   Otherwise, if there is more than one member, and all
	   the members have offset 0, assume we have a union.
	   Otherwise, assume we have a struct.

	   The heuristic could guess wrong in the case of of an
	   enumeration with no members or a union with one (or zero)
	   members, or when all except the last field of a struct have
	   width zero.  These are uncommon and/or illegal situations,
	   and in any case guessing wrong probably doesn't matter
	   much.

	   But if we later do find out we were wrong, we fixup the tag
	   kind.  Members of an enumeration must be handled
	   differently from struct/union fields, and that is harder to
	   patch up, but luckily we shouldn't need to.  (If there are
	   any enumeration members, we can tell for sure it's an enum
	   here.) */

	if (type_code == TYPE_CODE_UNDEF)
	  if (nfields > 1 && max_value == 0)
	    type_code = TYPE_CODE_UNION;
	  else
	    type_code = TYPE_CODE_STRUCT;

	/* Create a new type or use the pending type.  */
	pend = is_pending_symbol (cur_fdr, ext_sh);
	if (pend == (struct mdebug_pending *) NULL)
	  {
	    t = new_type (NULL);
	    add_pending (cur_fdr, ext_sh, t);
	  }
	else
	  t = pend->t;

	/* Do not set the tag name if it is a compiler generated tag name
	   (.Fxx or .xxfake or empty) for unnamed struct/union/enums.
	   Alpha cc puts out an sh->iss of zero for those.  */
	if (sh->iss == 0 || name[0] == '.' || name[0] == '\0')
	  TYPE_TAG_NAME (t) = NULL;
	else
	  TYPE_TAG_NAME (t) = obconcat (&current_objfile->symbol_obstack,
					"", "", name);

	TYPE_CODE (t) = type_code;
	TYPE_LENGTH (t) = sh->value;
	TYPE_NFIELDS (t) = nfields;
	TYPE_FIELDS (t) = f = ((struct field *)
			       TYPE_ALLOC (t,
					   nfields * sizeof (struct field)));

	if (type_code == TYPE_CODE_ENUM)
	  {
	    /* This is a non-empty enum. */

	    /* DEC c89 has the number of enumerators in the sh.value field,
	       not the type length, so we have to compensate for that
	       incompatibility quirk.
	       This might do the wrong thing for an enum with one or two
	       enumerators and gcc -gcoff -fshort-enums, but these cases
	       are hopefully rare enough.  */
	    if (TYPE_LENGTH (t) == TYPE_NFIELDS (t))
	      TYPE_LENGTH (t) = TARGET_INT_BIT / HOST_CHAR_BIT;
	    for (ext_tsym = ext_sh + external_sym_size;
		 ;
		 ext_tsym += external_sym_size)
	      {
		SYMR tsym;
		struct symbol *enum_sym;

		(*swap_sym_in) (cur_bfd, ext_tsym, &tsym);

		if (tsym.st != stMember)
		  break;

		f->bitpos = tsym.value;
		f->type = t;
		f->name = debug_info->ss + cur_fdr->issBase + tsym.iss;
		f->bitsize = 0;

		enum_sym = ((struct symbol *)
			    obstack_alloc (&current_objfile->symbol_obstack,
					   sizeof (struct symbol)));
		memset ((PTR) enum_sym, 0, sizeof (struct symbol));
		SYMBOL_NAME (enum_sym) = f->name;
		SYMBOL_CLASS (enum_sym) = LOC_CONST;
		SYMBOL_TYPE (enum_sym) = t;
		SYMBOL_NAMESPACE (enum_sym) = VAR_NAMESPACE;
		SYMBOL_VALUE (enum_sym) = tsym.value;
		add_symbol (enum_sym, top_stack->cur_block);

		/* Skip the stMembers that we've handled. */
		count++;
		f++;
	      }
	  }
	/* make this the current type */
	top_stack->cur_type = t;
	top_stack->cur_field = 0;

	/* Do not create a symbol for alpha cc unnamed structs.  */
	if (sh->iss == 0)
	  break;

	/* gcc puts out an empty struct for an opaque struct definitions,
	   do not create a symbol for it either.  */
	if (TYPE_NFIELDS (t) == 0)
	  {
	    TYPE_FLAGS (t) |= TYPE_FLAG_STUB;
	    break;
	  }

	s = new_symbol (name);
	SYMBOL_NAMESPACE (s) = STRUCT_NAMESPACE;
	SYMBOL_CLASS (s) = LOC_TYPEDEF;
	SYMBOL_VALUE (s) = 0;
	SYMBOL_TYPE (s) = t;
	add_symbol (s, top_stack->cur_block);
	break;

	/* End of local variables shared by struct, union, enum, and
	   block (as yet unknown struct/union/enum) processing.  */
      }

    case_stBlock_code:
      /* beginnning of (code) block. Value of symbol
	 is the displacement from procedure start */
      push_parse_stack ();

      /* Do not start a new block if this is the outermost block of a
	 procedure.  This allows the LOC_BLOCK symbol to point to the
	 block with the local variables, so funcname::var works.  */
      if (top_stack->blocktype == stProc
	  || top_stack->blocktype == stStaticProc)
	{
	  top_stack->blocktype = stNil;
	  break;
	}

      top_stack->blocktype = stBlock;
      b = new_block (top_stack->maxsyms);
      BLOCK_START (b) = sh->value + top_stack->procadr;
      BLOCK_SUPERBLOCK (b) = top_stack->cur_block;
      top_stack->cur_block = b;
      add_block (b, top_stack->cur_st);
      break;

    case stEnd:		/* end (of anything) */
      if (sh->sc == scInfo || sh->sc == scCommon)
	{
	  /* Finished with type */
	  top_stack->cur_type = 0;
	}
      else if (sh->sc == scText &&
	       (top_stack->blocktype == stProc ||
		top_stack->blocktype == stStaticProc))
	{
	  /* Finished with procedure */
	  struct blockvector *bv = BLOCKVECTOR (top_stack->cur_st);
	  struct mips_extra_func_info *e;
	  struct block *b;
	  int i;

	  BLOCK_END (top_stack->cur_block) += sh->value;	/* size */

	  /* Make up special symbol to contain procedure specific info */
	  s = new_symbol (MIPS_EFI_SYMBOL_NAME);
	  SYMBOL_NAMESPACE (s) = LABEL_NAMESPACE;
	  SYMBOL_CLASS (s) = LOC_CONST;
	  SYMBOL_TYPE (s) = builtin_type_void;
	  e = ((struct mips_extra_func_info *)
	       obstack_alloc (&current_objfile->symbol_obstack,
			      sizeof (struct mips_extra_func_info)));
	  SYMBOL_VALUE (s) = (long) e;
	  e->numargs = top_stack->numargs;
	  add_symbol (s, top_stack->cur_block);

	  /* Reallocate symbols, saving memory */
	  b = shrink_block (top_stack->cur_block, top_stack->cur_st);

	  /* f77 emits proc-level with address bounds==[0,0],
	     So look for such child blocks, and patch them.  */
	  for (i = 0; i < BLOCKVECTOR_NBLOCKS (bv); i++)
	    {
	      struct block *b_bad = BLOCKVECTOR_BLOCK (bv, i);
	      if (BLOCK_SUPERBLOCK (b_bad) == b
		  && BLOCK_START (b_bad) == top_stack->procadr
		  && BLOCK_END (b_bad) == top_stack->procadr)
		{
		  BLOCK_START (b_bad) = BLOCK_START (b);
		  BLOCK_END (b_bad) = BLOCK_END (b);
		}
	    }
	}
      else if (sh->sc == scText && top_stack->blocktype == stBlock)
	{
	  /* End of (code) block. The value of the symbol is the
	     displacement from the procedure`s start address of the
	     end of this block. */
	  BLOCK_END (top_stack->cur_block) = sh->value + top_stack->procadr;
	  shrink_block (top_stack->cur_block, top_stack->cur_st);
	}
      else if (sh->sc == scText && top_stack->blocktype == stNil)
	{
	  /* End of outermost block.  Pop parse stack and ignore.  The
	     following stEnd of stProc will take care of the block.  */
	  ;
	}
      else if (sh->sc == scText && top_stack->blocktype == stFile)
	{
	  /* End of file.  Pop parse stack and ignore.  Higher
	     level code deals with this.  */
	  ;
	}
      else
	complain (&stEnd_complaint, sh->sc);

      pop_parse_stack ();	/* restore previous lexical context */
      break;

    case stMember:		/* member of struct or union */
      f = &TYPE_FIELDS (top_stack->cur_type)[top_stack->cur_field++];
      f->name = name;
      f->bitpos = sh->value;
      bitsize = 0;
      f->type = parse_type (cur_fd, ax, sh->index, &bitsize, bigend, name);
      f->bitsize = bitsize;
      break;

    case stIndirect:		/* forward declaration on Irix5 */
      /* Forward declarations from Irix5 cc are handled by cross_ref,
	 skip them.  */
      break;

    case stTypedef:		/* type definition */
      /* Typedefs for forward declarations and opaque structs from alpha cc
	 are handled by cross_ref, skip them.  */
      if (sh->iss == 0)
	break;

      /* Parse the type or use the pending type.  */
      pend = is_pending_symbol (cur_fdr, ext_sh);
      if (pend == (struct mdebug_pending *) NULL)
	{
	  t = parse_type (cur_fd, ax, sh->index, (int *)NULL, bigend, name);
	  add_pending (cur_fdr, ext_sh, t);
	}
      else
	t = pend->t;

      /* mips cc puts out a typedef with the name of the struct for forward
	 declarations. These should not go into the symbol table and
	 TYPE_NAME should not be set for them.
	 They can't be distinguished from an intentional typedef to
	 the same name however:
	 x.h:
		struct x { int ix; int jx; };
		struct xx;
	 x.c:
		typedef struct x x;
		struct xx {int ixx; int jxx; };
	 generates a cross referencing stTypedef for x and xx.
	 The user visible effect of this is that the type of a pointer
	 to struct foo sometimes is given as `foo *' instead of `struct foo *'.
	 The problem is fixed with alpha cc and Irix5 cc.  */

      /* However if the typedef cross references to an opaque aggregate, it
	 is safe to omit it from the symbol table.  */

      if (has_opaque_xref (cur_fdr, sh))
	break;
      s = new_symbol (name);
      SYMBOL_NAMESPACE (s) = VAR_NAMESPACE;
      SYMBOL_CLASS (s) = LOC_TYPEDEF;
      SYMBOL_BLOCK_VALUE (s) = top_stack->cur_block;
      SYMBOL_TYPE (s) = t;
      add_symbol (s, top_stack->cur_block);

      /* Incomplete definitions of structs should not get a name.  */
      if (TYPE_NAME (SYMBOL_TYPE (s)) == NULL
	  && (TYPE_NFIELDS (SYMBOL_TYPE (s)) != 0
              || (TYPE_CODE (SYMBOL_TYPE (s)) != TYPE_CODE_STRUCT
		  && TYPE_CODE (SYMBOL_TYPE (s)) != TYPE_CODE_UNION)))
	{
	  if (TYPE_CODE (SYMBOL_TYPE (s)) == TYPE_CODE_PTR
	      || TYPE_CODE (SYMBOL_TYPE (s)) == TYPE_CODE_FUNC)
	    {
	      /* If we are giving a name to a type such as "pointer to
		 foo" or "function returning foo", we better not set
		 the TYPE_NAME.  If the program contains "typedef char
		 *caddr_t;", we don't want all variables of type char
		 * to print as caddr_t.  This is not just a
		 consequence of GDB's type management; CC and GCC (at
		 least through version 2.4) both output variables of
		 either type char * or caddr_t with the type
		 refering to the stTypedef symbol for caddr_t.  If a future
		 compiler cleans this up it GDB is not ready for it
		 yet, but if it becomes ready we somehow need to
		 disable this check (without breaking the PCC/GCC2.4
		 case).

		 Sigh.

		 Fortunately, this check seems not to be necessary
		 for anything except pointers or functions.  */
	    }
	  else
	    TYPE_NAME (SYMBOL_TYPE (s)) = SYMBOL_NAME (s);
	}
      break;

    case stFile:		/* file name */
      push_parse_stack ();
      top_stack->blocktype = sh->st;
      break;

      /* I`ve never seen these for C */
    case stRegReloc:
      break;			/* register relocation */
    case stForward:
      break;			/* forwarding address */
    case stConstant:
      break;			/* constant */
    default:
      complain (&unknown_mdebug_symtype_complaint, sh->st);
      break;
    }

  return count;
}

/* Parse the type information provided in the raw AX entries for
   the symbol SH. Return the bitfield size in BS, in case.
   We must byte-swap the AX entries before we use them; BIGEND says whether
   they are big-endian or little-endian (from fh->fBigendian).  */

static struct type *
parse_type (fd, ax, aux_index, bs, bigend, sym_name)
     int fd;
     union aux_ext *ax;
     unsigned int aux_index;
     int *bs;
     int bigend;
     char *sym_name;
{
  /* Null entries in this map are treated specially */
  static struct type **map_bt[] =
  {
    &builtin_type_void,		/* btNil */
    0,				/* btAdr */
    &builtin_type_char,		/* btChar */
    &builtin_type_unsigned_char,/* btUChar */
    &builtin_type_short,	/* btShort */
    &builtin_type_unsigned_short,	/* btUShort */
    &builtin_type_int,		/* btInt */
    &builtin_type_unsigned_int,	/* btUInt */
    &builtin_type_long,		/* btLong */
    &builtin_type_unsigned_long,/* btULong */
    &builtin_type_float,	/* btFloat */
    &builtin_type_double,	/* btDouble */
    0,				/* btStruct */
    0,				/* btUnion */
    0,				/* btEnum */
    0,				/* btTypedef */
    0,				/* btRange */
    0,				/* btSet */
    &mdebug_type_complex,	/* btComplex */
    &mdebug_type_double_complex,	/* btDComplex */
    0,				/* btIndirect */
    &mdebug_type_fixed_dec,	/* btFixedDec */
    &mdebug_type_float_dec,	/* btFloatDec */
    &mdebug_type_string,	/* btString */
    0,				/* btBit */
    0,				/* btPicture */
    &builtin_type_void,		/* btVoid */
    0,				/* DEC C++:  Pointer to member */
    0,				/* DEC C++:  Virtual function table */
    0,				/* DEC C++:  Class (Record) */
    &builtin_type_long,		/* btLong64  */
    &builtin_type_unsigned_long, /* btULong64 */
    &builtin_type_long_long,	/* btLongLong64  */
    &builtin_type_unsigned_long_long, /* btULongLong64 */
    &builtin_type_unsigned_long, /* btAdr64 */
    &builtin_type_long,		/* btInt64  */
    &builtin_type_unsigned_long, /* btUInt64 */
  };

  TIR t[1];
  struct type *tp = 0;
  enum type_code type_code = TYPE_CODE_UNDEF;

  /* Handle undefined types, they have indexNil. */
  if (aux_index == indexNil)
    return builtin_type_int;

  /* Handle corrupt aux indices.  */
  if (aux_index >= (debug_info->fdr + fd)->caux)
    {
      complain (&index_complaint, sym_name);
      return builtin_type_int;
    }
  ax += aux_index;

  /* Use aux as a type information record, map its basic type.  */
  (*debug_swap->swap_tir_in) (bigend, &ax->a_ti, t);
  if (t->bt >= (sizeof (map_bt) / sizeof (*map_bt)))
    {
      complain (&basic_type_complaint, t->bt, sym_name);
      return builtin_type_int;
    }
  if (map_bt[t->bt])
    {
      tp = *map_bt[t->bt];
    }
  else
    {
      tp = NULL;
      /* Cannot use builtin types -- build our own */
      switch (t->bt)
	{
	case btAdr:
	  tp = lookup_pointer_type (builtin_type_void);
	  break;
	case btStruct:
	  type_code = TYPE_CODE_STRUCT;
	  break;
	case btUnion:
	  type_code = TYPE_CODE_UNION;
	  break;
	case btEnum:
	  type_code = TYPE_CODE_ENUM;
	  break;
	case btRange:
	  type_code = TYPE_CODE_RANGE;
	  break;
	case btSet:
	  type_code = TYPE_CODE_SET;
	  break;
	case btTypedef:
	  /* alpha cc uses this for typedefs. The true type will be
	     obtained by crossreferencing below.  */
	  type_code = TYPE_CODE_ERROR;
	  break;
	default:
	  complain (&basic_type_complaint, t->bt, sym_name);
	  return builtin_type_int;
	}
    }

  /* Move on to next aux */
  ax++;

  if (t->fBitfield)
    {
      /* Inhibit core dumps with some cfront generated objects that
	 corrupt the TIR.  */
      if (bs == (int *)NULL)
	{
	  complain (&bad_fbitfield_complaint, sym_name);
	  return builtin_type_int;
	}
      *bs = AUX_GET_WIDTH (bigend, ax);
      ax++;
    }

  /* All these types really point to some (common) MIPS type
     definition, and only the type-qualifiers fully identify
     them.  We'll make the same effort at sharing. */
  if (t->bt == btStruct ||
      t->bt == btUnion ||
      t->bt == btEnum ||

      /* btSet (I think) implies that the name is a tag name, not a typedef
	 name.  This apparently is a MIPS extension for C sets.  */
      t->bt == btSet)
    {
      char *name;

      /* Try to cross reference this type, build new type on failure.  */
      ax += cross_ref (fd, ax, &tp, type_code, &name, bigend, sym_name);
      if (tp == (struct type *) NULL)
	tp = init_type (type_code, 0, 0, (char *) NULL, current_objfile);

      /* DEC c89 produces cross references to qualified aggregate types,
	 dereference them.  */
      while (TYPE_CODE (tp) == TYPE_CODE_PTR
	     || TYPE_CODE (tp) == TYPE_CODE_ARRAY)
	tp = tp->target_type;

      /* Make sure that TYPE_CODE(tp) has an expected type code.
	 Any type may be returned from cross_ref if file indirect entries
	 are corrupted.  */
      if (TYPE_CODE (tp) != TYPE_CODE_STRUCT
	  && TYPE_CODE (tp) != TYPE_CODE_UNION
	  && TYPE_CODE (tp) != TYPE_CODE_ENUM)
	{
	  complain (&unexpected_type_code_complaint, sym_name);
	}
      else
	{

	  /* Usually, TYPE_CODE(tp) is already type_code.  The main
	     exception is if we guessed wrong re struct/union/enum.
	     But for struct vs. union a wrong guess is harmless, so
	     don't complain().  */
	  if ((TYPE_CODE (tp) == TYPE_CODE_ENUM
	       && type_code != TYPE_CODE_ENUM)
	      || (TYPE_CODE (tp) != TYPE_CODE_ENUM
		  && type_code == TYPE_CODE_ENUM))
	    {
	      complain (&bad_tag_guess_complaint, sym_name);
	    }

	  if (TYPE_CODE (tp) != type_code)
	    {
	      TYPE_CODE (tp) = type_code;
	    }

	  /* Do not set the tag name if it is a compiler generated tag name
	      (.Fxx or .xxfake or empty) for unnamed struct/union/enums.  */
	  if (name[0] == '.' || name[0] == '\0')
	    TYPE_TAG_NAME (tp) = NULL;
	  else if (TYPE_TAG_NAME (tp) == NULL
		   || !STREQ (TYPE_TAG_NAME (tp), name))
	    TYPE_TAG_NAME (tp) = obsavestring (name, strlen (name),
					       &current_objfile->type_obstack);
	}
    }

  /* All these types really point to some (common) MIPS type
     definition, and only the type-qualifiers fully identify
     them.  We'll make the same effort at sharing.
     FIXME: btIndirect cannot happen here as it is handled by the
     switch t->bt above.  And we are not doing any guessing on range types.  */
  if (t->bt == btIndirect ||
      t->bt == btRange)
    {
      char *name;

      /* Try to cross reference this type, build new type on failure.  */
      ax += cross_ref (fd, ax, &tp, type_code, &name, bigend, sym_name);
      if (tp == (struct type *) NULL)
	tp = init_type (type_code, 0, 0, (char *) NULL, current_objfile);

      /* Make sure that TYPE_CODE(tp) has an expected type code.
	 Any type may be returned from cross_ref if file indirect entries
	 are corrupted.  */
      if (TYPE_CODE (tp) != TYPE_CODE_RANGE)
	{
	  complain (&unexpected_type_code_complaint, sym_name);
	}
      else
	{
	  /* Usually, TYPE_CODE(tp) is already type_code.  The main
	     exception is if we guessed wrong re struct/union/enum. */
	  if (TYPE_CODE (tp) != type_code)
	    {
	      complain (&bad_tag_guess_complaint, sym_name);
	      TYPE_CODE (tp) = type_code;
	    }
	  if (TYPE_NAME (tp) == NULL || !STREQ (TYPE_NAME (tp), name))
	    TYPE_NAME (tp) = obsavestring (name, strlen (name),
					   &current_objfile->type_obstack);
	}
    }
  if (t->bt == btTypedef)
    {
      char *name;

      /* Try to cross reference this type, it should succeed.  */
      ax += cross_ref (fd, ax, &tp, type_code, &name, bigend, sym_name);
      if (tp == (struct type *) NULL)
	{
	  complain (&unable_to_cross_ref_complaint, sym_name);
	  tp = builtin_type_int;
	}
    }

  /* Deal with range types */
  if (t->bt == btRange)
    {
      TYPE_NFIELDS (tp) = 2;
      TYPE_FIELDS (tp) = ((struct field *)
			  TYPE_ALLOC (tp, 2 * sizeof (struct field)));
      TYPE_FIELD_NAME (tp, 0) = obsavestring ("Low", strlen ("Low"),
					      &current_objfile->type_obstack);
      TYPE_FIELD_BITPOS (tp, 0) = AUX_GET_DNLOW (bigend, ax);
      ax++;
      TYPE_FIELD_NAME (tp, 1) = obsavestring ("High", strlen ("High"),
					      &current_objfile->type_obstack);
      TYPE_FIELD_BITPOS (tp, 1) = AUX_GET_DNHIGH (bigend, ax);
      ax++;
    }

  /* Parse all the type qualifiers now. If there are more
     than 6 the game will continue in the next aux */

  while (1)
    {
#define PARSE_TQ(tq) \
      if (t->tq != tqNil) \
	ax += upgrade_type(fd, &tp, t->tq, ax, bigend, sym_name); \
      else \
	break;

      PARSE_TQ (tq0);
      PARSE_TQ (tq1);
      PARSE_TQ (tq2);
      PARSE_TQ (tq3);
      PARSE_TQ (tq4);
      PARSE_TQ (tq5);
#undef	PARSE_TQ

      /* mips cc 2.x and gcc never put out continued aux entries.  */
      if (!t->continued)
	break;

      (*debug_swap->swap_tir_in) (bigend, &ax->a_ti, t);
      ax++;
    }

  /* Complain for illegal continuations due to corrupt aux entries.  */
  if (t->continued)
    complain (&bad_continued_complaint, sym_name);
 
  return tp;
}

/* Make up a complex type from a basic one.  Type is passed by
   reference in TPP and side-effected as necessary. The type
   qualifier TQ says how to handle the aux symbols at AX for
   the symbol SX we are currently analyzing.  BIGEND says whether
   aux symbols are big-endian or little-endian.
   Returns the number of aux symbols we parsed. */

static int
upgrade_type (fd, tpp, tq, ax, bigend, sym_name)
     int fd;
     struct type **tpp;
     int tq;
     union aux_ext *ax;
     int bigend;
     char *sym_name;
{
  int off;
  struct type *t;

  /* Used in array processing */
  int rf, id;
  FDR *fh;
  struct type *range;
  struct type *indx;
  int lower, upper;
  RNDXR rndx;

  switch (tq)
    {
    case tqPtr:
      t = lookup_pointer_type (*tpp);
      *tpp = t;
      return 0;

    case tqProc:
      t = lookup_function_type (*tpp);
      *tpp = t;
      return 0;

    case tqArray:
      off = 0;

      /* Determine and record the domain type (type of index) */
      (*debug_swap->swap_rndx_in) (bigend, &ax->a_rndx, &rndx);
      id = rndx.index;
      rf = rndx.rfd;
      if (rf == 0xfff)
	{
	  ax++;
	  rf = AUX_GET_ISYM (bigend, ax);
	  off++;
	}
      fh = get_rfd (fd, rf);

      indx = parse_type (fd, debug_info->external_aux + fh->iauxBase,
			 id, (int *) NULL, bigend, sym_name);

      /* The bounds type should be an integer type, but might be anything
	 else due to corrupt aux entries.  */
      if (TYPE_CODE (indx) != TYPE_CODE_INT)
	{
	  complain (&array_index_type_complaint, sym_name);
	  indx = builtin_type_int;
	}

      /* Get the bounds, and create the array type.  */
      ax++;
      lower = AUX_GET_DNLOW (bigend, ax);
      ax++;
      upper = AUX_GET_DNHIGH (bigend, ax);
      ax++;
      rf = AUX_GET_WIDTH (bigend, ax);	/* bit size of array element */

      range = create_range_type ((struct type *) NULL, indx,
				 lower, upper);

      t = create_array_type ((struct type *) NULL, *tpp, range);

      /* We used to fill in the supplied array element bitsize
	 here if the TYPE_LENGTH of the target type was zero.
	 This happens for a `pointer to an array of anonymous structs',
	 but in this case the array element bitsize is also zero,
	 so nothing is gained.
	 And we used to check the TYPE_LENGTH of the target type against
	 the supplied array element bitsize.
	 gcc causes a mismatch for `pointer to array of object',
	 since the sdb directives it uses do not have a way of
	 specifying the bitsize, but it does no harm (the
	 TYPE_LENGTH should be correct) and we should be able to
	 ignore the erroneous bitsize from the auxiliary entry safely.
	 dbx seems to ignore it too.  */

      *tpp = t;
      return 4 + off;

    case tqVol:
      /* Volatile -- currently ignored */
      return 0;

    case tqConst:
      /* Const -- currently ignored */
      return 0;

    default:
      complain (&unknown_type_qual_complaint, tq);
      return 0;
    }
}


/* Parse a procedure descriptor record PR.  Note that the procedure is
   parsed _after_ the local symbols, now we just insert the extra
   information we need into a MIPS_EFI_SYMBOL_NAME symbol that has
   already been placed in the procedure's main block.  Note also that
   images that have been partially stripped (ld -x) have been deprived
   of local symbols, and we have to cope with them here.  FIRST_OFF is
   the offset of the first procedure for this FDR; we adjust the
   address by this amount, but I don't know why.  SEARCH_SYMTAB is the symtab
   to look for the function which contains the MIPS_EFI_SYMBOL_NAME symbol
   in question, or NULL to use top_stack->cur_block.  */

static void parse_procedure PARAMS ((PDR *, struct symtab *, unsigned long,
				     struct partial_symtab *));

static void
parse_procedure (pr, search_symtab, first_off, pst)
     PDR *pr;
     struct symtab *search_symtab;
     unsigned long first_off;
     struct partial_symtab *pst;
{
  struct symbol *s, *i;
  struct block *b;
  struct mips_extra_func_info *e;
  char *sh_name;

  /* Simple rule to find files linked "-x" */
  if (cur_fdr->rss == -1)
    {
      if (pr->isym == -1)
	{
	  /* Static procedure at address pr->adr.  Sigh. */
	  /* FIXME-32x64.  assuming pr->adr fits in long.  */
	  complain (&pdr_static_symbol_complaint, (unsigned long) pr->adr);
	  return;
	}
      else
	{
	  /* external */
	  EXTR she;
	  
	  (*debug_swap->swap_ext_in) (cur_bfd,
				      ((char *) debug_info->external_ext
				       + (pr->isym
					  * debug_swap->external_ext_size)),
				      &she);
	  sh_name = debug_info->ssext + she.asym.iss;
	}
    }
  else
    {
      /* Full symbols */
      SYMR sh;

      (*debug_swap->swap_sym_in) (cur_bfd,
				  ((char *) debug_info->external_sym
				   + ((cur_fdr->isymBase + pr->isym)
				      * debug_swap->external_sym_size)),
				  &sh);
      sh_name = debug_info->ss + cur_fdr->issBase + sh.iss;
    }

  if (search_symtab != NULL)
    {
#if 0
      /* This loses both in the case mentioned (want a static, find a global),
	 but also if we are looking up a non-mangled name which happens to
	 match the name of a mangled function.  */
      /* We have to save the cur_fdr across the call to lookup_symbol.
	 If the pdr is for a static function and if a global function with
	 the same name exists, lookup_symbol will eventually read in the symtab
	 for the global function and clobber cur_fdr.  */
      FDR *save_cur_fdr = cur_fdr;
      s = lookup_symbol (sh_name, NULL, VAR_NAMESPACE, 0, NULL);
      cur_fdr = save_cur_fdr;
#else
      s = mylookup_symbol
	(sh_name,
	 BLOCKVECTOR_BLOCK (BLOCKVECTOR (search_symtab), STATIC_BLOCK),
	 VAR_NAMESPACE,
	 LOC_BLOCK);
#endif
    }
  else
    s = mylookup_symbol (sh_name, top_stack->cur_block,
			 VAR_NAMESPACE, LOC_BLOCK);

  if (s != 0)
    {
      b = SYMBOL_BLOCK_VALUE (s);
    }
  else
    {
      complain (&pdr_for_nonsymbol_complaint, sh_name);
#if 1
      return;
#else
/* FIXME -- delete.  We can't do symbol allocation now; it's all done.  */
      s = new_symbol (sh_name);
      SYMBOL_NAMESPACE (s) = VAR_NAMESPACE;
      SYMBOL_CLASS (s) = LOC_BLOCK;
      /* Donno its type, hope int is ok */
      SYMBOL_TYPE (s) = lookup_function_type (builtin_type_int);
      add_symbol (s, top_stack->cur_block);
      /* Wont have symbols for this one */
      b = new_block (2);
      SYMBOL_BLOCK_VALUE (s) = b;
      BLOCK_FUNCTION (b) = s;
      BLOCK_START (b) = pr->adr;
      /* BOUND used to be the end of procedure's text, but the
	 argument is no longer passed in.  */
      BLOCK_END (b) = bound;
      BLOCK_SUPERBLOCK (b) = top_stack->cur_block;
      add_block (b, top_stack->cur_st);
#endif
    }

  i = mylookup_symbol (MIPS_EFI_SYMBOL_NAME, b, LABEL_NAMESPACE, LOC_CONST);

  if (i)
    {
      e = (struct mips_extra_func_info *) SYMBOL_VALUE (i);
      e->pdr = *pr;
      e->pdr.isym = (long) s;
      e->pdr.adr += pst->textlow - first_off;

      /* Correct incorrect setjmp procedure descriptor from the library
	 to make backtrace through setjmp work.  */
      if (e->pdr.pcreg == 0 && STREQ (sh_name, "setjmp"))
	{
	  complain (&bad_setjmp_pdr_complaint, 0);
	  e->pdr.pcreg = RA_REGNUM;
	  e->pdr.regmask = 0x80000000;
	  e->pdr.regoffset = -4;
	}
    }
}

/* Relocate the extra function info pointed to by the symbol table.  */

void
ecoff_relocate_efi (sym, delta)
     struct symbol *sym;
     CORE_ADDR delta;
{
  struct mips_extra_func_info *e;

  e = (struct mips_extra_func_info *) SYMBOL_VALUE (sym);
  
  e->pdr.adr += delta;
}

/* Parse the external symbol ES. Just call parse_symbol() after
   making sure we know where the aux are for it.
   BIGEND says whether aux entries are big-endian or little-endian.

   This routine clobbers top_stack->cur_block and ->cur_st. */

static void parse_external PARAMS ((EXTR *, int, struct section_offsets *));

static void
parse_external (es, bigend, section_offsets)
     EXTR *es;
     int bigend;
     struct section_offsets *section_offsets;
{
  union aux_ext *ax;

  if (es->ifd != ifdNil)
    {
      cur_fd = es->ifd;
      cur_fdr = debug_info->fdr + cur_fd;
      ax = debug_info->external_aux + cur_fdr->iauxBase;
    }
  else
    {
      cur_fdr = debug_info->fdr;
      ax = 0;
    }

  /* Reading .o files */
  if (es->asym.sc == scUndefined || es->asym.sc == scNil)
    {
      char *what;
      switch (es->asym.st)
	{
	case stNil:
	  /* These are generated for static symbols in .o files,
	     ignore them.  */
	  return;
	case stStaticProc:
	case stProc:
	  what = "procedure";
	  n_undef_procs++;
	  break;
	case stGlobal:
	  what = "variable";
	  n_undef_vars++;
	  break;
	case stLabel:
	  what = "label";
	  n_undef_labels++;
	  break;
	default:
	  what = "symbol";
	  break;
	}
      n_undef_symbols++;
      /* FIXME:  Turn this into a complaint? */
      if (info_verbose)
	printf_filtered ("Warning: %s `%s' is undefined (in %s)\n",
			 what, debug_info->ssext + es->asym.iss,
			 fdr_name (cur_fdr));
      return;
    }

  switch (es->asym.st)
    {
    case stProc:
    case stStaticProc:
      /* There is no need to parse the external procedure symbols.
	 If they are from objects compiled without -g, their index will
	 be indexNil, and the symbol definition from the minimal symbol
	 is preferrable (yielding a function returning int instead of int).
	 If the index points to a local procedure symbol, the local
	 symbol already provides the correct type.
	 Note that the index of the external procedure symbol points
	 to the local procedure symbol in the local symbol table, and
	 _not_ to the auxiliary symbol info.  */
      break;
    case stGlobal:
    case stLabel:
      /* Note that the case of a symbol with indexNil must be handled
	 anyways by parse_symbol().  */
      parse_symbol (&es->asym, ax, (char *) NULL, bigend, section_offsets);
      break;
    default:
      break;
    }
}

/* Parse the line number info for file descriptor FH into
   GDB's linetable LT.  MIPS' encoding requires a little bit
   of magic to get things out.  Note also that MIPS' line
   numbers can go back and forth, apparently we can live
   with that and do not need to reorder our linetables */

static void parse_lines PARAMS ((FDR *, PDR *, struct linetable *, int,
				 struct partial_symtab *));

static void
parse_lines (fh, pr, lt, maxlines, pst)
     FDR *fh;
     PDR *pr;
     struct linetable *lt;
     int maxlines;
     struct partial_symtab *pst;
{
  unsigned char *base;
  int j, k;
  int delta, count, lineno = 0;
  unsigned long first_off = pr->adr;

  if (fh->cbLine == 0)
    return;

  /* Scan by procedure descriptors */
  k = 0;
  for (j = 0; j < fh->cpd; j++, pr++)
    {
      long l;
      unsigned long adr;
      unsigned char *halt;

      /* No code for this one */
      if (pr->iline == ilineNil ||
	  pr->lnLow == -1 || pr->lnHigh == -1)
	continue;

      /* Determine start and end address of compressed line bytes for
	 this procedure.  */
      base = debug_info->line + fh->cbLineOffset;
      if (j != (fh->cpd - 1))
 	halt = base + pr[1].cbLineOffset;
      else
 	halt = base + fh->cbLine;
      base += pr->cbLineOffset;

      adr = pst->textlow + pr->adr - first_off;

      l = adr >> 2;		/* in words */
      for (lineno = pr->lnLow; base < halt; )
	{
	  count = *base & 0x0f;
	  delta = *base++ >> 4;
	  if (delta >= 8)
	    delta -= 16;
	  if (delta == -8)
	    {
	      delta = (base[0] << 8) | base[1];
	      if (delta >= 0x8000)
		delta -= 0x10000;
	      base += 2;
	    }
	  lineno += delta;	/* first delta is 0 */

	  /* Complain if the line table overflows. Could happen
	     with corrupt binaries.  */
	  if (lt->nitems >= maxlines)
	    {
	      complain (&bad_linetable_guess_complaint, fdr_name (fh));
	      break;
	    }
	  k = add_line (lt, lineno, l, k);
	  l += count + 1;
	}
    }
}

/* Master parsing procedure for first-pass reading of file symbols
   into a partial_symtab.  */

static void
parse_partial_symbols (objfile, section_offsets)
     struct objfile *objfile;
     struct section_offsets *section_offsets;
{
  const bfd_size_type external_sym_size = debug_swap->external_sym_size;
  const bfd_size_type external_rfd_size = debug_swap->external_rfd_size;
  const bfd_size_type external_ext_size = debug_swap->external_ext_size;
  void (* const swap_ext_in) PARAMS ((bfd *, PTR, EXTR *))
    = debug_swap->swap_ext_in;
  void (* const swap_sym_in) PARAMS ((bfd *, PTR, SYMR *))
    = debug_swap->swap_sym_in;
  void (* const swap_rfd_in) PARAMS ((bfd *, PTR, RFDT *))
    = debug_swap->swap_rfd_in;
  int f_idx, s_idx;
  HDRR *hdr = &debug_info->symbolic_header;
  /* Running pointers */
  FDR *fh;
  char *ext_out;
  char *ext_out_end;
  EXTR *ext_block;
  register EXTR *ext_in;
  EXTR *ext_in_end;
  SYMR sh;
  struct partial_symtab *pst;

  int past_first_source_file = 0;

  /* List of current psymtab's include files */
  char **psymtab_include_list;
  int includes_allocated;
  int includes_used;
  EXTR *extern_tab;
  struct pst_map *fdr_to_pst;
  /* Index within current psymtab dependency list */
  struct partial_symtab **dependency_list;
  int dependencies_used, dependencies_allocated;
  struct cleanup *old_chain;
  char *name;
  enum language prev_language;
  asection *text_sect;
  int relocatable = 0;

  /* Irix 5.2 shared libraries have a fh->adr field of zero, but
     the shared libraries are prelinked at a high memory address.
     We have to adjust the start address of the object file for this case,
     by setting it to the start address of the first procedure in the file.
     But we should do no adjustments if we are debugging a .o file, where
     the text section (and fh->adr) really starts at zero.  */
  text_sect = bfd_get_section_by_name (cur_bfd, ".text");
  if (text_sect != NULL
      && (bfd_get_section_flags (cur_bfd, text_sect) & SEC_RELOC))
    relocatable = 1;

  extern_tab = (EXTR *) obstack_alloc (&objfile->psymbol_obstack,
				       sizeof (EXTR) * hdr->iextMax);

  includes_allocated = 30;
  includes_used = 0;
  psymtab_include_list = (char **) alloca (includes_allocated *
					   sizeof (char *));
  next_symbol_text_func = mdebug_next_symbol_text;

  dependencies_allocated = 30;
  dependencies_used = 0;
  dependency_list =
    (struct partial_symtab **) alloca (dependencies_allocated *
				       sizeof (struct partial_symtab *));

  last_source_file = NULL;

  /*
   * Big plan:
   *
   * Only parse the Local and External symbols, and the Relative FDR.
   * Fixup enough of the loader symtab to be able to use it.
   * Allocate space only for the file's portions we need to
   * look at. (XXX)
   */

  max_gdbinfo = 0;
  max_glevel = MIN_GLEVEL;

  /* Allocate the map FDR -> PST.
     Minor hack: -O3 images might claim some global data belongs
     to FDR -1. We`ll go along with that */
  fdr_to_pst = (struct pst_map *) xzalloc ((hdr->ifdMax + 1) * sizeof *fdr_to_pst);
  old_chain = make_cleanup (free, fdr_to_pst);
  fdr_to_pst++;
  {
    struct partial_symtab *pst = new_psymtab ("", objfile, section_offsets);
    fdr_to_pst[-1].pst = pst;
    FDR_IDX (pst) = -1;
  }

  /* Allocate the global pending list.  */
  pending_list =
    ((struct mdebug_pending **)
     obstack_alloc (&objfile->psymbol_obstack,
		    hdr->ifdMax * sizeof (struct mdebug_pending *)));
  memset ((PTR) pending_list, 0,
	  hdr->ifdMax * sizeof (struct mdebug_pending *));

  /* Pass 0 over external syms: swap them in.  */
  ext_block = (EXTR *) xmalloc (hdr->iextMax * sizeof (EXTR));
  make_cleanup (free, ext_block);

  ext_out = (char *) debug_info->external_ext;
  ext_out_end = ext_out + hdr->iextMax * external_ext_size;
  ext_in = ext_block;
  for (; ext_out < ext_out_end; ext_out += external_ext_size, ext_in++)
    (*swap_ext_in) (cur_bfd, ext_out, ext_in);

  /* Pass 1 over external syms: Presize and partition the list */
  ext_in = ext_block;
  ext_in_end = ext_in + hdr->iextMax;
  for (; ext_in < ext_in_end; ext_in++)
    {
      /* See calls to complain below.  */
      if (ext_in->ifd >= -1
	  && ext_in->ifd < hdr->ifdMax
	  && ext_in->asym.iss >= 0
	  && ext_in->asym.iss < hdr->issExtMax)
	fdr_to_pst[ext_in->ifd].n_globals++;
    }

  /* Pass 1.5 over files:  partition out global symbol space */
  s_idx = 0;
  for (f_idx = -1; f_idx < hdr->ifdMax; f_idx++)
    {
      fdr_to_pst[f_idx].globals_offset = s_idx;
      s_idx += fdr_to_pst[f_idx].n_globals;
      fdr_to_pst[f_idx].n_globals = 0;
    }

  /* Pass 2 over external syms: fill in external symbols */
  ext_in = ext_block;
  ext_in_end = ext_in + hdr->iextMax;
  for (; ext_in < ext_in_end; ext_in++)
    {
      enum minimal_symbol_type ms_type = mst_text;
      CORE_ADDR svalue = ext_in->asym.value;

      /* The Irix 5 native tools seem to sometimes generate bogus
	 external symbols.  */
      if (ext_in->ifd < -1 || ext_in->ifd >= hdr->ifdMax)
	{
	  complain (&bad_ext_ifd_complaint, ext_in->ifd, hdr->ifdMax);
	  continue;
	}
      if (ext_in->asym.iss < 0 || ext_in->asym.iss >= hdr->issExtMax)
	{
	  complain (&bad_ext_iss_complaint, ext_in->asym.iss,
		    hdr->issExtMax);
	  continue;
	}

      extern_tab[fdr_to_pst[ext_in->ifd].globals_offset
		 + fdr_to_pst[ext_in->ifd].n_globals++] = *ext_in;

      if (ext_in->asym.sc == scUndefined || ext_in->asym.sc == scNil)
	continue;

      name = debug_info->ssext + ext_in->asym.iss;
      switch (ext_in->asym.st)
	{
	case stProc:
	  svalue += ANOFFSET (section_offsets, SECT_OFF_TEXT);
	  break;
	case stStaticProc:
	  ms_type = mst_file_text;
	  svalue += ANOFFSET (section_offsets, SECT_OFF_TEXT);
	  break;
	case stGlobal:
          if (ext_in->asym.sc == scCommon)
	    {
	      /* The value of a common symbol is its size, not its address.
		 Ignore it.  */
	      continue;
	    }
          else if (ext_in->asym.sc == scData
	      || ext_in->asym.sc == scSData
	      || ext_in->asym.sc == scRData
	      || ext_in->asym.sc == scPData
	      || ext_in->asym.sc == scXData)
	    {
	      ms_type = mst_data;
	      svalue += ANOFFSET (section_offsets, SECT_OFF_DATA);
	    }
	  else
	    {
	      ms_type = mst_bss;
	      svalue += ANOFFSET (section_offsets, SECT_OFF_BSS);
	    }
	  break;
	case stLabel:
          if (ext_in->asym.sc == scAbs)
	    ms_type = mst_abs;
          else if (ext_in->asym.sc == scText
          	   || ext_in->asym.sc == scInit
          	   || ext_in->asym.sc == scFini)
	    {
	      ms_type = mst_file_text;
	      svalue += ANOFFSET (section_offsets, SECT_OFF_TEXT);
	    }
          else if (ext_in->asym.sc == scData
		   || ext_in->asym.sc == scSData
		   || ext_in->asym.sc == scRData
		   || ext_in->asym.sc == scPData
		   || ext_in->asym.sc == scXData)
	    {
	      ms_type = mst_file_data;
	      svalue += ANOFFSET (section_offsets, SECT_OFF_DATA);
	    }
	  else
	    {
	      ms_type = mst_file_bss;
	      svalue += ANOFFSET (section_offsets, SECT_OFF_BSS);
	    }
	  break;
	case stLocal:
	  /* The alpha has the section start addresses in stLocal symbols
	     whose name starts with a `.'. Skip those but complain for all
	     other stLocal symbols.  */
	  if (name[0] == '.')
	    continue;
	  /* Fall through.  */
	default:
	  ms_type = mst_unknown;
	  complain (&unknown_ext_complaint, name);
	}
      prim_record_minimal_symbol (name, svalue, ms_type, objfile);
    }

  /* Pass 3 over files, over local syms: fill in static symbols */
  for (f_idx = 0; f_idx < hdr->ifdMax; f_idx++)
    {
      struct partial_symtab *save_pst;
      EXTR *ext_ptr;
      CORE_ADDR textlow;

      cur_fdr = fh = debug_info->fdr + f_idx;

      if (fh->csym == 0)
	{
	  fdr_to_pst[f_idx].pst = NULL;
	  continue;
	}

      /* Determine the start address for this object file from the
	 file header and relocate it, except for Irix 5.2 zero fh->adr.  */
      if (fh->cpd)
	{
	  textlow = fh->adr;
	  if (relocatable || textlow != 0)
	    textlow += ANOFFSET (section_offsets, SECT_OFF_TEXT);
	}
      else
	textlow = 0;
      pst = start_psymtab_common (objfile, section_offsets,
				  fdr_name (fh),
				  textlow,
				  objfile->global_psymbols.next,
				  objfile->static_psymbols.next);
      pst->read_symtab_private = ((char *)
				  obstack_alloc (&objfile->psymbol_obstack,
						 sizeof (struct symloc)));
      memset ((PTR) pst->read_symtab_private, 0, sizeof (struct symloc));

      save_pst = pst;
      FDR_IDX (pst) = f_idx;
      CUR_BFD (pst) = cur_bfd;
      DEBUG_SWAP (pst) = debug_swap;
      DEBUG_INFO (pst) = debug_info;
      PENDING_LIST (pst) = pending_list;

      /* The way to turn this into a symtab is to call... */
      pst->read_symtab = mdebug_psymtab_to_symtab;

      /* Set up language for the pst.
         The language from the FDR is used if it is unambigious (e.g. cfront
	 with native cc and g++ will set the language to C).
	 Otherwise we have to deduce the language from the filename.
	 Native ecoff has every header file in a separate FDR, so
	 deduce_language_from_filename will return language_unknown for
	 a header file, which is not what we want.
	 But the FDRs for the header files are after the FDR for the source
	 file, so we can assign the language of the source file to the
	 following header files. Then we save the language in the private
	 pst data so that we can reuse it when building symtabs.  */
      prev_language = psymtab_language;

      switch (fh->lang)
	{
	case langCplusplusV2:
	  psymtab_language = language_cplus;
	  break;
	default:
	  psymtab_language = deduce_language_from_filename (fdr_name (fh));
	  break;
	}
      if (psymtab_language == language_unknown)
	psymtab_language = prev_language;
      PST_PRIVATE (pst)->pst_language = psymtab_language;

      pst->texthigh = pst->textlow;

      /* For stabs-in-ecoff files, the second symbol must be @stab.
	 This symbol is emitted by mips-tfile to signal that the
	 current object file uses encapsulated stabs instead of mips
	 ecoff for local symbols.  (It is the second symbol because
	 the first symbol is the stFile used to signal the start of a
	 file). */
      processing_gcc_compilation = 0;
      if (fh->csym >= 2)
	{
	  (*swap_sym_in) (cur_bfd,
			  ((char *) debug_info->external_sym
			   + (fh->isymBase + 1) * external_sym_size),
			  &sh);
	  if (STREQ (debug_info->ss + fh->issBase + sh.iss, stabs_symbol))
	    processing_gcc_compilation = 2;
	}

      if (processing_gcc_compilation != 0)
	{
	  for (cur_sdx = 2; cur_sdx < fh->csym; cur_sdx++)
	    {
	      int type_code;
	      char *namestring;

	      (*swap_sym_in) (cur_bfd,
			      (((char *) debug_info->external_sym)
			       + (fh->isymBase + cur_sdx) * external_sym_size),
			      &sh);
	      type_code = ECOFF_UNMARK_STAB (sh.index);
	      if (!ECOFF_IS_STAB (&sh))
		{
		  if (sh.st == stProc || sh.st == stStaticProc)
		    {
		      long procaddr;
		      long isym;
	
		      sh.value += ANOFFSET (section_offsets, SECT_OFF_TEXT);
		      if (sh.st == stStaticProc)
			{
			  namestring = debug_info->ss + fh->issBase + sh.iss;
			  prim_record_minimal_symbol_and_info (namestring,
							       sh.value,
							       mst_file_text,
							       NULL,
							       SECT_OFF_TEXT,
							       objfile);
			}
		      procaddr = sh.value;

		      isym = AUX_GET_ISYM (fh->fBigendian,
					   (debug_info->external_aux
					    + fh->iauxBase
					    + sh.index));
		      (*swap_sym_in) (cur_bfd,
				      ((char *) debug_info->external_sym
				       + ((fh->isymBase + isym - 1)
					  * external_sym_size)),
				      &sh);
		      if (sh.st == stEnd)
			{
			  long high = procaddr + sh.value;

	      		  /* Kludge for Irix 5.2 zero fh->adr.  */
			  if (!relocatable
			      && (pst->textlow == 0 || procaddr < pst->textlow))
			    pst->textlow = procaddr;
			  if (high > pst->texthigh)
			    pst->texthigh = high;
			}
		    }
		  else if (sh.st == stStatic)
		    {
		      switch (sh.sc)
			{
			case scUndefined:
			case scNil:
			case scAbs:
			  break;

			case scData:
			case scSData:
			case scRData:
			case scPData:
			case scXData:
			  namestring = debug_info->ss + fh->issBase + sh.iss;
		          sh.value += ANOFFSET (section_offsets, SECT_OFF_DATA);
			  prim_record_minimal_symbol_and_info (namestring,
							       sh.value,
							       mst_file_data,
							       NULL,
							       SECT_OFF_DATA,
							       objfile);
			  break;

			default:
			  namestring = debug_info->ss + fh->issBase + sh.iss;
		          sh.value += ANOFFSET (section_offsets, SECT_OFF_BSS);
			  prim_record_minimal_symbol_and_info (namestring,
							       sh.value,
							       mst_file_bss,
							       NULL,
							       SECT_OFF_BSS,
							       objfile);
			  break;
			}
		    }
		  continue;
		}
#define SET_NAMESTRING() \
  namestring = debug_info->ss + fh->issBase + sh.iss
#define CUR_SYMBOL_TYPE type_code
#define CUR_SYMBOL_VALUE sh.value
#define START_PSYMTAB(ofile,secoff,fname,low,symoff,global_syms,static_syms)\
  pst = save_pst
#define END_PSYMTAB(pst,ilist,ninc,c_off,c_text,dep_list,n_deps) (void)0
#define HANDLE_RBRAC(val) \
  if ((val) > save_pst->texthigh) save_pst->texthigh = (val);
#include "partial-stab.h"
	    }
	}
      else
	{
	  for (cur_sdx = 0; cur_sdx < fh->csym;)
	    {
	      char *name;
	      enum address_class class;

	      (*swap_sym_in) (cur_bfd,
			      ((char *) debug_info->external_sym
			       + ((fh->isymBase + cur_sdx)
				  * external_sym_size)),
			      &sh);

	      if (ECOFF_IS_STAB (&sh))
		{
		  cur_sdx++;
		  continue;
		}

	      /* Non absolute static symbols go into the minimal table.  */
	      if (sh.sc == scUndefined || sh.sc == scNil
		  || (sh.index == indexNil
		      && (sh.st != stStatic || sh.sc == scAbs)))
		{
		  /* FIXME, premature? */
		  cur_sdx++;
		  continue;
		}

	      name = debug_info->ss + fh->issBase + sh.iss;

	      switch (sh.sc)
		{
		case scText:
		  /* The value of a stEnd symbol is the displacement from the
		     corresponding start symbol value, do not relocate it.  */
		  if (sh.st != stEnd)
		    sh.value += ANOFFSET (section_offsets, SECT_OFF_TEXT);
		  break;
		case scData:
		case scSData:
		case scRData:
		case scPData:
		case scXData:
		  sh.value += ANOFFSET (section_offsets, SECT_OFF_DATA);
		  break;
		case scBss:
		case scSBss:
		  sh.value += ANOFFSET (section_offsets, SECT_OFF_BSS);
		  break;
		}

	      switch (sh.st)
		{
		  long high;
		  long procaddr;
		  int new_sdx;

		case stStaticProc:
		  prim_record_minimal_symbol_and_info (name, sh.value,
						       mst_file_text, NULL,
						       SECT_OFF_TEXT, objfile);

		  /* FALLTHROUGH */

		case stProc:
		  /* Usually there is a local and a global stProc symbol
		     for a function. This means that the function name
		     has already been entered into the mimimal symbol table
		     while processing the global symbols in pass 2 above.
		     One notable exception is the PROGRAM name from
		     f77 compiled executables, it is only put out as
		     local stProc symbol, and a global MAIN__ stProc symbol
		     points to it.  It doesn't matter though, as gdb is
		     still able to find the PROGRAM name via the partial
		     symbol table, and the MAIN__ symbol via the minimal
		     symbol table.  */
		  if (sh.st == stProc)
		    ADD_PSYMBOL_TO_LIST (name, strlen (name),
					 VAR_NAMESPACE, LOC_BLOCK,
					 objfile->global_psymbols,
					 sh.value, psymtab_language, objfile);
		  else
		    ADD_PSYMBOL_TO_LIST (name, strlen (name),
					 VAR_NAMESPACE, LOC_BLOCK,
					 objfile->static_psymbols,
					 sh.value, psymtab_language, objfile);

		  /* Skip over procedure to next one. */
		  if (sh.index >= hdr->iauxMax)
		    {
		      /* Should not happen, but does when cross-compiling
			   with the MIPS compiler.  FIXME -- pull later.  */
		      complain (&index_complaint, name);
		      new_sdx = cur_sdx + 1;	/* Don't skip at all */
		    }
		  else
		    new_sdx = AUX_GET_ISYM (fh->fBigendian,
					    (debug_info->external_aux
					     + fh->iauxBase
					     + sh.index));
		  procaddr = sh.value;

		  if (new_sdx <= cur_sdx)
		    {
		      /* This should not happen either... FIXME.  */
		      complain (&aux_index_complaint, name);
		      new_sdx = cur_sdx + 1;	/* Don't skip backward */
		    }

		  cur_sdx = new_sdx;
		  (*swap_sym_in) (cur_bfd,
				  ((char *) debug_info->external_sym
				   + ((fh->isymBase + cur_sdx - 1)
				      * external_sym_size)),
				  &sh);
		  if (sh.st != stEnd)
		    continue;

		  /* Kludge for Irix 5.2 zero fh->adr.  */
		  if (!relocatable
		      && (pst->textlow == 0 || procaddr < pst->textlow))
		    pst->textlow = procaddr;

		  high = procaddr + sh.value;
		  if (high > pst->texthigh)
		    pst->texthigh = high;
		  continue;

		case stStatic:	/* Variable */
		  if (sh.sc == scData
		      || sh.sc == scSData
		      || sh.sc == scRData
		      || sh.sc == scPData
		      || sh.sc == scXData)
		    prim_record_minimal_symbol_and_info (name, sh.value,
							 mst_file_data, NULL,
							 SECT_OFF_DATA,
							 objfile);
		  else
		    prim_record_minimal_symbol_and_info (name, sh.value,
							 mst_file_bss, NULL,
							 SECT_OFF_BSS,
							 objfile);
		  class = LOC_STATIC;
		  break;

		case stIndirect:/* Irix5 forward declaration */
		  /* Skip forward declarations from Irix5 cc */
		  goto skip;

		case stTypedef:/* Typedef */
		  /* Skip typedefs for forward declarations and opaque
		     structs from alpha and mips cc.  */
		  if (sh.iss == 0 || has_opaque_xref (fh, &sh))
		    goto skip;
		  class = LOC_TYPEDEF;
		  break;

		case stConstant:	/* Constant decl */
		  class = LOC_CONST;
		  break;

		case stUnion:
		case stStruct:
		case stEnum:
		case stBlock:	/* { }, str, un, enum*/
		  /* Do not create a partial symbol for cc unnamed aggregates
		     and gcc empty aggregates. */
		  if ((sh.sc == scInfo || sh.sc == scCommon)
		      && sh.iss != 0
		      && sh.index != cur_sdx + 2)
		    {
		      ADD_PSYMBOL_TO_LIST (name, strlen (name),
					   STRUCT_NAMESPACE, LOC_TYPEDEF,
					   objfile->static_psymbols,
					   sh.value,
					   psymtab_language, objfile);
		    }
		  handle_psymbol_enumerators (objfile, fh, sh.st);

		  /* Skip over the block */
		  new_sdx = sh.index;
		  if (new_sdx <= cur_sdx)
		    {
		      /* This happens with the Ultrix kernel. */
		      complain (&block_index_complaint, name);
		      new_sdx = cur_sdx + 1;	/* Don't skip backward */
		    }
		  cur_sdx = new_sdx;
		  continue;

		case stFile:	/* File headers */
		case stLabel:	/* Labels */
		case stEnd:	/* Ends of files */
		  goto skip;

		case stLocal:	/* Local variables */
		  /* Normally these are skipped because we skip over
		     all blocks we see.  However, these can occur
		     as visible symbols in a .h file that contains code. */
		  goto skip;

		default:
		  /* Both complaints are valid:  one gives symbol name,
		     the other the offending symbol type.  */
		  complain (&unknown_sym_complaint, name);
		  complain (&unknown_st_complaint, sh.st);
		  cur_sdx++;
		  continue;
		}
	      /* Use this gdb symbol */
	      ADD_PSYMBOL_TO_LIST (name, strlen (name),
				   VAR_NAMESPACE, class,
				   objfile->static_psymbols, sh.value,
				   psymtab_language, objfile);
	    skip:
	      cur_sdx++;	/* Go to next file symbol */
	    }

	  /* Now do enter the external symbols. */
	  ext_ptr = &extern_tab[fdr_to_pst[f_idx].globals_offset];
	  cur_sdx = fdr_to_pst[f_idx].n_globals;
	  PST_PRIVATE (save_pst)->extern_count = cur_sdx;
	  PST_PRIVATE (save_pst)->extern_tab = ext_ptr;
	  for (; --cur_sdx >= 0; ext_ptr++)
	    {
	      enum address_class class;
	      SYMR *psh;
	      char *name;
	      CORE_ADDR svalue;

	      if (ext_ptr->ifd != f_idx)
		abort ();
	      psh = &ext_ptr->asym;

	      /* Do not add undefined symbols to the partial symbol table.  */
	      if (psh->sc == scUndefined || psh->sc == scNil)
		continue;

	      svalue = psh->value;
	      switch (psh->sc)
		{
		case scText:
		  svalue += ANOFFSET (section_offsets, SECT_OFF_TEXT);
		  break;
		case scData:
		case scSData:
		case scRData:
		case scPData:
		case scXData:
		  svalue += ANOFFSET (section_offsets, SECT_OFF_DATA);
		  break;
		case scBss:
		case scSBss:
		  svalue += ANOFFSET (section_offsets, SECT_OFF_BSS);
		  break;
		}

	      switch (psh->st)
		{
		case stNil:
		  /* These are generated for static symbols in .o files,
		     ignore them.  */
		  continue;
		case stProc:
		case stStaticProc:
		  /* External procedure symbols have been entered
		     into the minimal symbol table in pass 2 above.
		     Ignore them, as parse_external will ignore them too.  */
		  continue;
		case stLabel:
		  class = LOC_LABEL;
		  break;
		default:
		  complain (&unknown_ext_complaint,
			    debug_info->ssext + psh->iss);
		  /* Fall through, pretend it's global.  */
		case stGlobal:
		  class = LOC_STATIC;
		  break;
		}
	      name = debug_info->ssext + psh->iss;
	      ADD_PSYMBOL_ADDR_TO_LIST (name, strlen (name),
				        VAR_NAMESPACE, class,
				        objfile->global_psymbols,
					svalue,
				        psymtab_language, objfile);
	    }
	}

      /* Link pst to FDR. end_psymtab returns NULL if the psymtab was
	 empty and put on the free list.  */
      fdr_to_pst[f_idx].pst = end_psymtab (save_pst,
					   psymtab_include_list, includes_used,
					   -1, save_pst->texthigh,
					   dependency_list, dependencies_used);
      if (objfile->ei.entry_point >= save_pst->textlow &&
	  objfile->ei.entry_point < save_pst->texthigh)
	{
	  objfile->ei.entry_file_lowpc = save_pst->textlow;
	  objfile->ei.entry_file_highpc = save_pst->texthigh;
	}
    }

  /* Now scan the FDRs for dependencies */
  for (f_idx = 0; f_idx < hdr->ifdMax; f_idx++)
    {
      fh = f_idx + debug_info->fdr;
      pst = fdr_to_pst[f_idx].pst;

      if (pst == (struct partial_symtab *)NULL)
	continue;

      /* This should catch stabs-in-ecoff. */
      if (fh->crfd <= 1)
	continue;

      /* Skip the first file indirect entry as it is a self dependency
	 for source files or a reverse .h -> .c dependency for header files.  */
      pst->number_of_dependencies = 0;
      pst->dependencies =
	((struct partial_symtab **)
	 obstack_alloc (&objfile->psymbol_obstack,
			((fh->crfd - 1)
			 * sizeof (struct partial_symtab *))));
      for (s_idx = 1; s_idx < fh->crfd; s_idx++)
	{
	  RFDT rh;

	  (*swap_rfd_in) (cur_bfd,
			  ((char *) debug_info->external_rfd
			   + (fh->rfdBase + s_idx) * external_rfd_size),
			  &rh);
	  if (rh < 0 || rh >= hdr->ifdMax)
	    {
	      complain (&bad_file_number_complaint, rh);
	      continue;
	    }

	  /* Skip self dependencies of header files.  */
	  if (rh == f_idx)
	    continue;

	  /* Do not add to dependeny list if psymtab was empty.  */
	  if (fdr_to_pst[rh].pst == (struct partial_symtab *)NULL)
	    continue;
	  pst->dependencies[pst->number_of_dependencies++] = fdr_to_pst[rh].pst;
	}
    }

  /* Remove the dummy psymtab created for -O3 images above, if it is
     still empty, to enable the detection of stripped executables.  */
  if (objfile->psymtabs->next == NULL
      && objfile->psymtabs->number_of_dependencies == 0
      && objfile->psymtabs->n_global_syms == 0
      && objfile->psymtabs->n_static_syms == 0)
    objfile->psymtabs = NULL;
  do_cleanups (old_chain);
}

/* If the current psymbol has an enumerated type, we need to add
   all the the enum constants to the partial symbol table.  */

static void
handle_psymbol_enumerators (objfile, fh, stype)
     struct objfile *objfile;
     FDR *fh;
     int stype;
{
  const bfd_size_type external_sym_size = debug_swap->external_sym_size;
  void (* const swap_sym_in) PARAMS ((bfd *, PTR, SYMR *))
    = debug_swap->swap_sym_in;
  char *ext_sym = ((char *) debug_info->external_sym
		  + ((fh->isymBase + cur_sdx + 1) * external_sym_size));
  SYMR sh;
  TIR tir;

  switch (stype)
    {
    case stEnum:
      break;

    case stBlock:
      /* It is an enumerated type if the next symbol entry is a stMember
	 and its auxiliary index is indexNil or its auxiliary entry
	 is a plain btNil or btVoid.  */
      (*swap_sym_in) (cur_bfd, ext_sym, &sh);
      if (sh.st != stMember)
	return;

      if (sh.index == indexNil)
	break;
      (*debug_swap->swap_tir_in) (fh->fBigendian,
				  &(debug_info->external_aux
				    + fh->iauxBase + sh.index)->a_ti,
				  &tir);
      if ((tir.bt != btNil && tir.bt != btVoid) || tir.tq0 != tqNil)
	return;
      break;

    default:
      return;
    }

  for (;;)
    {
      char *name;

      (*swap_sym_in) (cur_bfd, ext_sym, &sh);
      if (sh.st != stMember)
	break;
      name = debug_info->ss + cur_fdr->issBase + sh.iss;

      /* Note that the value doesn't matter for enum constants
	 in psymtabs, just in symtabs.  */
      ADD_PSYMBOL_TO_LIST (name, strlen (name),
			   VAR_NAMESPACE, LOC_CONST,
			   objfile->static_psymbols, 0,
			   psymtab_language, objfile);
      ext_sym += external_sym_size;
    }
}

static char *
mdebug_next_symbol_text ()
{
  SYMR sh;

  cur_sdx++;
  (*debug_swap->swap_sym_in) (cur_bfd,
			      ((char *) debug_info->external_sym
			       + ((cur_fdr->isymBase + cur_sdx)
				  * debug_swap->external_sym_size)),
			      &sh);
  return debug_info->ss + cur_fdr->issBase + sh.iss;
}

/* Ancillary function to psymtab_to_symtab().  Does all the work
   for turning the partial symtab PST into a symtab, recurring
   first on all dependent psymtabs.  The argument FILENAME is
   only passed so we can see in debug stack traces what file
   is being read.

   This function has a split personality, based on whether the
   symbol table contains ordinary ecoff symbols, or stabs-in-ecoff.
   The flow of control and even the memory allocation differs.  FIXME.  */

static void
psymtab_to_symtab_1 (pst, filename)
     struct partial_symtab *pst;
     char *filename;
{
  bfd_size_type external_sym_size;
  bfd_size_type external_pdr_size;
  void (*swap_sym_in) PARAMS ((bfd *, PTR, SYMR *));
  void (*swap_pdr_in) PARAMS ((bfd *, PTR, PDR *));
  int i;
  struct symtab *st;
  FDR *fh;
  struct linetable *lines;

  if (pst->readin)
    return;
  pst->readin = 1;

  /* Read in all partial symbtabs on which this one is dependent.
     NOTE that we do have circular dependencies, sigh.  We solved
     that by setting pst->readin before this point.  */

  for (i = 0; i < pst->number_of_dependencies; i++)
    if (!pst->dependencies[i]->readin)
      {
	/* Inform about additional files to be read in.  */
	if (info_verbose)
	  {
	    fputs_filtered (" ", gdb_stdout);
	    wrap_here ("");
	    fputs_filtered ("and ", gdb_stdout);
	    wrap_here ("");
	    printf_filtered ("%s...",
			     pst->dependencies[i]->filename);
	    wrap_here ("");	/* Flush output */
	    gdb_flush (gdb_stdout);
	  }
	/* We only pass the filename for debug purposes */
	psymtab_to_symtab_1 (pst->dependencies[i],
			     pst->dependencies[i]->filename);
      }

  /* Do nothing if this is a dummy psymtab.  */

  if (pst->n_global_syms == 0 && pst->n_static_syms == 0
      && pst->textlow == 0 && pst->texthigh == 0)
    return;

  /* Now read the symbols for this symtab */

  cur_bfd = CUR_BFD (pst);
  debug_swap = DEBUG_SWAP (pst);
  debug_info = DEBUG_INFO (pst);
  pending_list = PENDING_LIST (pst);
  external_sym_size = debug_swap->external_sym_size;
  external_pdr_size = debug_swap->external_pdr_size;
  swap_sym_in = debug_swap->swap_sym_in;
  swap_pdr_in = debug_swap->swap_pdr_in;
  current_objfile = pst->objfile;
  cur_fd = FDR_IDX (pst);
  fh = ((cur_fd == -1)
	? (FDR *) NULL
	: debug_info->fdr + cur_fd);
  cur_fdr = fh;

  /* See comment in parse_partial_symbols about the @stabs sentinel. */
  processing_gcc_compilation = 0;
  if (fh != (FDR *) NULL && fh->csym >= 2)
    {
      SYMR sh;

      (*swap_sym_in) (cur_bfd,
		      ((char *) debug_info->external_sym
		       + (fh->isymBase + 1) * external_sym_size),
		      &sh);
      if (STREQ (debug_info->ss + fh->issBase + sh.iss,
		 stabs_symbol))
	{
	  /* We indicate that this is a GCC compilation so that certain
	     features will be enabled in stabsread/dbxread.  */
	  processing_gcc_compilation = 2;
	}
    }

  if (processing_gcc_compilation != 0)
    {
      char *pdr_ptr;
      char *pdr_end;
      int first_pdr;
      unsigned long first_off = 0;

      /* This symbol table contains stabs-in-ecoff entries.  */

      /* Parse local symbols first */

      if (fh->csym <= 2)	/* FIXME, this blows psymtab->symtab ptr */
	{
	  current_objfile = NULL;
	  return;
	}
      for (cur_sdx = 2; cur_sdx < fh->csym; cur_sdx++)
	{
	  SYMR sh;
	  char *name;
	  CORE_ADDR valu;

	  (*swap_sym_in) (cur_bfd,
			  (((char *) debug_info->external_sym)
			   + (fh->isymBase + cur_sdx) * external_sym_size),
			  &sh);
	  name = debug_info->ss + fh->issBase + sh.iss;
	  valu = sh.value;
	  if (ECOFF_IS_STAB (&sh))
	    {
	      int type_code = ECOFF_UNMARK_STAB (sh.index);

	      /* We should never get non N_STAB symbols here, but they
		 should be harmless, so keep process_one_symbol from
		 complaining about them.  */
	      if (type_code & N_STAB)
		{
		  process_one_symbol (type_code, 0, valu, name,
				      pst->section_offsets, pst->objfile);
		}
	      if (type_code == N_FUN)
		{
		  /* Make up special symbol to contain
		     procedure specific info */
		  struct mips_extra_func_info *e =
		    ((struct mips_extra_func_info *)
		     obstack_alloc (&current_objfile->symbol_obstack,
				    sizeof (struct mips_extra_func_info)));
		  struct symbol *s = new_symbol (MIPS_EFI_SYMBOL_NAME);
		  SYMBOL_NAMESPACE (s) = LABEL_NAMESPACE;
		  SYMBOL_CLASS (s) = LOC_CONST;
		  SYMBOL_TYPE (s) = builtin_type_void;
		  SYMBOL_VALUE (s) = (long) e;
		  add_symbol_to_list (s, &local_symbols);
		}
	    }
	  else if (sh.st == stLabel)
	    {
	      if (sh.index == indexNil)
		{
		  /* This is what the gcc2_compiled and __gnu_compiled_*
		     show up as.  So don't complain.  */
		  ;
		}
	      else
		/* Handle encoded stab line number. */
		record_line (current_subfile, sh.index, valu);
	    }
	  else if (sh.st == stProc || sh.st == stStaticProc
		   || sh.st == stStatic || sh.st == stEnd)
	    /* These are generated by gcc-2.x, do not complain */
	    ;
	  else
	    complain (&stab_unknown_complaint, name);
	}
      st = end_symtab (pst->texthigh, 0, 0, pst->objfile, SECT_OFF_TEXT);
      end_stabs ();

      /* Sort the symbol table now, we are done adding symbols to it.
	 We must do this before parse_procedure calls lookup_symbol.  */
      sort_symtab_syms (st);

      /* There used to be a call to sort_blocks here, but this should not
	 be necessary for stabs symtabs.  And as sort_blocks modifies the
	 start address of the GLOBAL_BLOCK to the FIRST_LOCAL_BLOCK,
	 it did the wrong thing if the first procedure in a file was
	 generated via asm statements.  */

      /* Fill in procedure info next.  */
      first_pdr = 1;
      pdr_ptr = ((char *) debug_info->external_pdr
		 + fh->ipdFirst * external_pdr_size);
      pdr_end = pdr_ptr + fh->cpd * external_pdr_size;
      for (; pdr_ptr < pdr_end; pdr_ptr += external_pdr_size)
	{
	  PDR pr;

	  (*swap_pdr_in) (cur_bfd, pdr_ptr, &pr);
	  if (first_pdr)
	    {
	      first_off = pr.adr;
	      first_pdr = 0;
	    }
	  parse_procedure (&pr, st, first_off, pst);
	}
    }
  else
    {
      /* This symbol table contains ordinary ecoff entries.  */

      /* FIXME:  doesn't use pst->section_offsets.  */

      int f_max;
      int maxlines;
      EXTR *ext_ptr;

      /* How many symbols will we need */
      /* FIXME, this does not count enum values. */
      f_max = pst->n_global_syms + pst->n_static_syms;
      if (fh == 0)
	{
	  maxlines = 0;
	  st = new_symtab ("unknown", f_max, 0, pst->objfile);
	}
      else
	{
	  f_max += fh->csym + fh->cpd;
	  maxlines = 2 * fh->cline;
	  st = new_symtab (pst->filename, 2 * f_max, maxlines, pst->objfile);

	  /* The proper language was already determined when building
	     the psymtab, use it.  */
	  st->language = PST_PRIVATE (pst)->pst_language;
	}

      psymtab_language = st->language;

      lines = LINETABLE (st);

      /* Get a new lexical context */

      push_parse_stack ();
      top_stack->cur_st = st;
      top_stack->cur_block = BLOCKVECTOR_BLOCK (BLOCKVECTOR (st),
						STATIC_BLOCK);
      BLOCK_START (top_stack->cur_block) = pst->textlow;
      BLOCK_END (top_stack->cur_block) = 0;
      top_stack->blocktype = stFile;
      top_stack->maxsyms = 2 * f_max;
      top_stack->cur_type = 0;
      top_stack->procadr = 0;
      top_stack->numargs = 0;

      if (fh)
	{
	  char *sym_ptr;
	  char *sym_end;

	  /* Parse local symbols first */
	  sym_ptr = ((char *) debug_info->external_sym
		     + fh->isymBase * external_sym_size);
	  sym_end = sym_ptr + fh->csym * external_sym_size;
	  while (sym_ptr < sym_end)
	    {
	      SYMR sh;
	      int c;

	      (*swap_sym_in) (cur_bfd, sym_ptr, &sh);
	      c = parse_symbol (&sh,
				debug_info->external_aux + fh->iauxBase,
				sym_ptr, fh->fBigendian, pst->section_offsets);
	      sym_ptr += c * external_sym_size;
	    }

	  /* Linenumbers.  At the end, check if we can save memory.
	     parse_lines has to look ahead an arbitrary number of PDR
	     structures, so we swap them all first.  */
	  if (fh->cpd > 0)
	    {
	      PDR *pr_block;
	      struct cleanup *old_chain;
	      char *pdr_ptr;
	      char *pdr_end;
	      PDR *pdr_in;
	      PDR *pdr_in_end;

	      pr_block = (PDR *) xmalloc (fh->cpd * sizeof (PDR));

	      old_chain = make_cleanup (free, pr_block);

	      pdr_ptr = ((char *) debug_info->external_pdr
			 + fh->ipdFirst * external_pdr_size);
	      pdr_end = pdr_ptr + fh->cpd * external_pdr_size;
	      pdr_in = pr_block;
	      for (;
		   pdr_ptr < pdr_end;
		   pdr_ptr += external_pdr_size, pdr_in++)
		(*swap_pdr_in) (cur_bfd, pdr_ptr, pdr_in);

	      parse_lines (fh, pr_block, lines, maxlines, pst);
	      if (lines->nitems < fh->cline)
		lines = shrink_linetable (lines);

	      /* Fill in procedure info next.  */
	      pdr_in = pr_block;
	      pdr_in_end = pdr_in + fh->cpd;
	      for (; pdr_in < pdr_in_end; pdr_in++)
		parse_procedure (pdr_in, 0, pr_block->adr, pst);

	      do_cleanups (old_chain);
	    }
	}

      LINETABLE (st) = lines;

      /* .. and our share of externals.
	 XXX use the global list to speed up things here. how?
	 FIXME, Maybe quit once we have found the right number of ext's? */
      top_stack->cur_st = st;
      top_stack->cur_block = BLOCKVECTOR_BLOCK (BLOCKVECTOR (top_stack->cur_st),
						GLOBAL_BLOCK);
      top_stack->blocktype = stFile;
      top_stack->maxsyms
	= (debug_info->symbolic_header.isymMax
	   + debug_info->symbolic_header.ipdMax
	   + debug_info->symbolic_header.iextMax);

      ext_ptr = PST_PRIVATE (pst)->extern_tab;
      for (i = PST_PRIVATE (pst)->extern_count; --i >= 0; ext_ptr++)
	parse_external (ext_ptr, fh->fBigendian, pst->section_offsets);

      /* If there are undefined symbols, tell the user.
	 The alpha has an undefined symbol for every symbol that is
	 from a shared library, so tell the user only if verbose is on.  */
      if (info_verbose && n_undef_symbols)
	{
	  printf_filtered ("File %s contains %d unresolved references:",
			   st->filename, n_undef_symbols);
	  printf_filtered ("\n\t%4d variables\n\t%4d procedures\n\t%4d labels\n",
			   n_undef_vars, n_undef_procs, n_undef_labels);
	  n_undef_symbols = n_undef_labels = n_undef_vars = n_undef_procs = 0;

	}
      pop_parse_stack ();

      st->primary = 1;

      /* Sort the symbol table now, we are done adding symbols to it.*/
      sort_symtab_syms (st);

      sort_blocks (st);
    }

  /* Now link the psymtab and the symtab.  */
  pst->symtab = st;

  current_objfile = NULL;
}

/* Ancillary parsing procedures. */

/* Return 1 if the symbol pointed to by SH has a cross reference
   to an opaque aggregate type, else 0.  */

static int
has_opaque_xref (fh, sh)
     FDR *fh;
     SYMR *sh;
{
  TIR tir;
  union aux_ext *ax;
  RNDXR rn[1];
  unsigned int rf;

  if (sh->index == indexNil)
    return 0;

  ax = debug_info->external_aux + fh->iauxBase + sh->index;
  (*debug_swap->swap_tir_in) (fh->fBigendian, &ax->a_ti, &tir);
  if (tir.bt != btStruct && tir.bt != btUnion && tir.bt != btEnum)
    return 0;

  ax++;
  (*debug_swap->swap_rndx_in) (fh->fBigendian, &ax->a_rndx, rn);
  if (rn->rfd == 0xfff)
    rf = AUX_GET_ISYM (fh->fBigendian, ax + 1);
  else
    rf = rn->rfd;
  if (rf != -1)
    return 0;
  return 1;
}

/* Lookup the type at relative index RN.  Return it in TPP
   if found and in any event come up with its name PNAME.
   BIGEND says whether aux symbols are big-endian or not (from fh->fBigendian).
   Return value says how many aux symbols we ate. */

static int
cross_ref (fd, ax, tpp, type_code, pname, bigend, sym_name)
     int fd;
     union aux_ext *ax;
     struct type **tpp;
     enum type_code type_code;	/* Use to alloc new type if none is found. */
     char **pname;
     int bigend;
     char *sym_name;
{
  RNDXR rn[1];
  unsigned int rf;
  int result = 1;
  FDR *fh;
  char *esh;
  SYMR sh;
  int xref_fd;
  struct mdebug_pending *pend;

  *tpp = (struct type *)NULL;

  (*debug_swap->swap_rndx_in) (bigend, &ax->a_rndx, rn);

  /* Escape index means 'the next one' */
  if (rn->rfd == 0xfff)
    {
      result++;
      rf = AUX_GET_ISYM (bigend, ax + 1);
    }
  else
    {
      rf = rn->rfd;
    }

  /* mips cc uses a rf of -1 for opaque struct definitions.
     Set TYPE_FLAG_STUB for these types so that check_stub_type will
     resolve them if the struct gets defined in another compilation unit.  */
  if (rf == -1)
    {
      *pname = "<undefined>";
      *tpp = init_type (type_code, 0, 0, (char *) NULL, current_objfile);
      TYPE_FLAGS (*tpp) |= TYPE_FLAG_STUB;
      return result;
    }

  /* mips cc uses an escaped rn->index of 0 for struct return types
     of procedures that were compiled without -g. These will always remain
     undefined.  */
  if (rn->rfd == 0xfff && rn->index == 0)
    {
      *pname = "<undefined>";
      return result;
    }

  /* Find the relative file descriptor and the symbol in it.  */
  fh = get_rfd (fd, rf);
  xref_fd = fh - debug_info->fdr;

  if (rn->index >= fh->csym)
    {
      /* File indirect entry is corrupt.  */
      *pname = "<illegal>";
      complain (&bad_rfd_entry_complaint,
		sym_name, xref_fd, rn->index);
      return result;
    }

  /* If we have processed this symbol then we left a forwarding
     pointer to the type in the pending list.  If not, we`ll put
     it in a list of pending types, to be processed later when
     the file will be.  In any event, we collect the name for the
     type here.  */

  esh = ((char *) debug_info->external_sym
	 + ((fh->isymBase + rn->index)
	    * debug_swap->external_sym_size));
  (*debug_swap->swap_sym_in) (cur_bfd, esh, &sh);

  /* Make sure that this type of cross reference can be handled.  */
  if ((sh.sc != scInfo
       || (sh.st != stBlock && sh.st != stTypedef && sh.st != stIndirect
	   && sh.st != stStruct && sh.st != stUnion
	   && sh.st != stEnum))
      && (sh.sc != scCommon || sh.st != stBlock))
    {
      /* File indirect entry is corrupt.  */
      *pname = "<illegal>";
      complain (&bad_rfd_entry_complaint,
		sym_name, xref_fd, rn->index);
      return result;
    }

  *pname = debug_info->ss + fh->issBase + sh.iss;

  pend = is_pending_symbol (fh, esh);
  if (pend)
    *tpp = pend->t;
  else
    {
      /* We have not yet seen this type.  */

      if ((sh.iss == 0 && sh.st == stTypedef) || sh.st == stIndirect)
	{
	  TIR tir;

	  /* alpha cc puts out a stTypedef with a sh.iss of zero for
	     two cases:
	     a) forward declarations of structs/unions/enums which are not
		defined in this compilation unit.
		For these the type will be void. This is a bad design decision
		as cross referencing across compilation units is impossible
		due to the missing name.
	     b) forward declarations of structs/unions/enums which are defined
		later in this file or in another file in the same compilation
		unit. Irix5 cc uses a stIndirect symbol for this.
		Simply cross reference those again to get the true type.
	     The forward references are not entered in the pending list and
	     in the symbol table.  */

	  (*debug_swap->swap_tir_in) (bigend,
				      &(debug_info->external_aux
					+ fh->iauxBase + sh.index)->a_ti,
				      &tir);
	  if (tir.tq0 != tqNil)
	    complain (&illegal_forward_tq0_complaint, sym_name);
	  switch (tir.bt)
	    {
	    case btVoid:
	      *tpp = init_type (type_code, 0, 0, (char *) NULL,
				current_objfile);
    	      *pname = "<undefined>";
	      break;

	    case btStruct:
	    case btUnion:
	    case btEnum:
	      cross_ref (xref_fd,
			 (debug_info->external_aux
			  + fh->iauxBase + sh.index + 1),
			 tpp, type_code, pname,
			 fh->fBigendian, sym_name);
	      break;

	    default:
	      complain (&illegal_forward_bt_complaint, tir.bt, sym_name);
	      *tpp = init_type (type_code, 0, 0, (char *) NULL,
				current_objfile);
	      break;
	    }
	  return result;
	}
      else if (sh.st == stTypedef)
	{
	  /* Parse the type for a normal typedef. This might recursively call
	     cross_ref till we get a non typedef'ed type.
	     FIXME: This is not correct behaviour, but gdb currently
	     cannot handle typedefs without type copying. But type copying is
	     impossible as we might have mutual forward references between
	     two files and the copied type would not get filled in when
	     we later parse its definition.   */
	  *tpp = parse_type (xref_fd,
			     debug_info->external_aux + fh->iauxBase,
			     sh.index,
			     (int *)NULL,
			     fh->fBigendian,
			     debug_info->ss + fh->issBase + sh.iss);
	}
      else
	{
	  /* Cross reference to a struct/union/enum which is defined
	     in another file in the same compilation unit but that file
	     has not been parsed yet.
	     Initialize the type only, it will be filled in when
	     it's definition is parsed.  */
	  *tpp = init_type (type_code, 0, 0, (char *) NULL, current_objfile);
	}
      add_pending (fh, esh, *tpp);
    }

  /* We used one auxent normally, two if we got a "next one" rf. */
  return result;
}


/* Quick&dirty lookup procedure, to avoid the MI ones that require
   keeping the symtab sorted */

static struct symbol *
mylookup_symbol (name, block, namespace, class)
     char *name;
     register struct block *block;
     enum namespace namespace;
     enum address_class class;
{
  register int bot, top, inc;
  register struct symbol *sym;

  bot = 0;
  top = BLOCK_NSYMS (block);
  inc = name[0];
  while (bot < top)
    {
      sym = BLOCK_SYM (block, bot);
      if (SYMBOL_NAME (sym)[0] == inc
	  && SYMBOL_NAMESPACE (sym) == namespace
	  && SYMBOL_CLASS (sym) == class
	  && strcmp (SYMBOL_NAME (sym), name) == 0)
	return sym;
      bot++;
    }
  block = BLOCK_SUPERBLOCK (block);
  if (block)
    return mylookup_symbol (name, block, namespace, class);
  return 0;
}


/* Add a new symbol S to a block B.
   Infrequently, we will need to reallocate the block to make it bigger.
   We only detect this case when adding to top_stack->cur_block, since
   that's the only time we know how big the block is.  FIXME.  */

static void
add_symbol (s, b)
     struct symbol *s;
     struct block *b;
{
  int nsyms = BLOCK_NSYMS (b)++;
  struct block *origb;
  struct parse_stack *stackp;

  if (b == top_stack->cur_block &&
      nsyms >= top_stack->maxsyms)
    {
      complain (&block_overflow_complaint, SYMBOL_NAME (s));
      /* In this case shrink_block is actually grow_block, since
		   BLOCK_NSYMS(b) is larger than its current size.  */
      origb = b;
      b = shrink_block (top_stack->cur_block, top_stack->cur_st);

      /* Now run through the stack replacing pointers to the
	 original block.  shrink_block has already done this
	 for the blockvector and BLOCK_FUNCTION.  */
      for (stackp = top_stack; stackp; stackp = stackp->next)
	{
	  if (stackp->cur_block == origb)
	    {
	      stackp->cur_block = b;
	      stackp->maxsyms = BLOCK_NSYMS (b);
	    }
	}
    }
  BLOCK_SYM (b, nsyms) = s;
}

/* Add a new block B to a symtab S */

static void
add_block (b, s)
     struct block *b;
     struct symtab *s;
{
  struct blockvector *bv = BLOCKVECTOR (s);

  bv = (struct blockvector *) xrealloc ((PTR) bv,
					(sizeof (struct blockvector)
					 + BLOCKVECTOR_NBLOCKS (bv)
					 * sizeof (bv->block)));
  if (bv != BLOCKVECTOR (s))
    BLOCKVECTOR (s) = bv;

  BLOCKVECTOR_BLOCK (bv, BLOCKVECTOR_NBLOCKS (bv)++) = b;
}

/* Add a new linenumber entry (LINENO,ADR) to a linevector LT.
   MIPS' linenumber encoding might need more than one byte
   to describe it, LAST is used to detect these continuation lines.

   Combining lines with the same line number seems like a bad idea.
   E.g: There could be a line number entry with the same line number after the
   prologue and GDB should not ignore it (this is a better way to find
   a prologue than mips_skip_prologue).
   But due to the compressed line table format there are line number entries
   for the same line which are needed to bridge the gap to the next
   line number entry. These entries have a bogus address info with them
   and we are unable to tell them from intended duplicate line number
   entries.
   This is another reason why -ggdb debugging format is preferable.  */

static int
add_line (lt, lineno, adr, last)
     struct linetable *lt;
     int lineno;
     CORE_ADDR adr;
     int last;
{
  /* DEC c89 sometimes produces zero linenos which confuse gdb.
     Change them to something sensible. */
  if (lineno == 0)
    lineno = 1;
  if (last == 0)
    last = -2;			/* make sure we record first line */

  if (last == lineno)		/* skip continuation lines */
    return lineno;

  lt->item[lt->nitems].line = lineno;
  lt->item[lt->nitems++].pc = adr << 2;
  return lineno;
}

/* Sorting and reordering procedures */

/* Blocks with a smaller low bound should come first */

static int
compare_blocks (arg1, arg2)
     const PTR arg1;
     const PTR arg2;
{
  register int addr_diff;
  struct block **b1 = (struct block **) arg1;
  struct block **b2 = (struct block **) arg2;

  addr_diff = (BLOCK_START ((*b1))) - (BLOCK_START ((*b2)));
  if (addr_diff == 0)
    return (BLOCK_END ((*b2))) - (BLOCK_END ((*b1)));
  return addr_diff;
}

/* Sort the blocks of a symtab S.
   Reorder the blocks in the blockvector by code-address,
   as required by some MI search routines */

static void
sort_blocks (s)
     struct symtab *s;
{
  struct blockvector *bv = BLOCKVECTOR (s);

  if (BLOCKVECTOR_NBLOCKS (bv) <= 2)
    {
      /* Cosmetic */
      if (BLOCK_END (BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK)) == 0)
	BLOCK_START (BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK)) = 0;
      if (BLOCK_END (BLOCKVECTOR_BLOCK (bv, STATIC_BLOCK)) == 0)
	BLOCK_START (BLOCKVECTOR_BLOCK (bv, STATIC_BLOCK)) = 0;
      return;
    }
  /*
   * This is very unfortunate: normally all functions are compiled in
   * the order they are found, but if the file is compiled -O3 things
   * are very different.  It would be nice to find a reliable test
   * to detect -O3 images in advance.
   */
  if (BLOCKVECTOR_NBLOCKS (bv) > 3)
    qsort (&BLOCKVECTOR_BLOCK (bv, FIRST_LOCAL_BLOCK),
	   BLOCKVECTOR_NBLOCKS (bv) - FIRST_LOCAL_BLOCK,
	   sizeof (struct block *),
	   compare_blocks);

  {
    register CORE_ADDR high = 0;
    register int i, j = BLOCKVECTOR_NBLOCKS (bv);

    for (i = FIRST_LOCAL_BLOCK; i < j; i++)
      if (high < BLOCK_END (BLOCKVECTOR_BLOCK (bv, i)))
	high = BLOCK_END (BLOCKVECTOR_BLOCK (bv, i));
    BLOCK_END (BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK)) = high;
  }

  BLOCK_START (BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK)) =
    BLOCK_START (BLOCKVECTOR_BLOCK (bv, FIRST_LOCAL_BLOCK));

  BLOCK_START (BLOCKVECTOR_BLOCK (bv, STATIC_BLOCK)) =
    BLOCK_START (BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK));
  BLOCK_END (BLOCKVECTOR_BLOCK (bv, STATIC_BLOCK)) =
    BLOCK_END (BLOCKVECTOR_BLOCK (bv, GLOBAL_BLOCK));
}


/* Constructor/restructor/destructor procedures */

/* Allocate a new symtab for NAME.  Needs an estimate of how many symbols
   MAXSYMS and linenumbers MAXLINES we'll put in it */

static struct symtab *
new_symtab (name, maxsyms, maxlines, objfile)
     char *name;
     int maxsyms;
     int maxlines;
     struct objfile *objfile;
{
  struct symtab *s = allocate_symtab (name, objfile);

  LINETABLE (s) = new_linetable (maxlines);

  /* All symtabs must have at least two blocks */
  BLOCKVECTOR (s) = new_bvect (2);
  BLOCKVECTOR_BLOCK (BLOCKVECTOR (s), GLOBAL_BLOCK) = new_block (maxsyms);
  BLOCKVECTOR_BLOCK (BLOCKVECTOR (s), STATIC_BLOCK) = new_block (maxsyms);
  BLOCK_SUPERBLOCK (BLOCKVECTOR_BLOCK (BLOCKVECTOR (s), STATIC_BLOCK)) =
    BLOCKVECTOR_BLOCK (BLOCKVECTOR (s), GLOBAL_BLOCK);

  s->free_code = free_linetable;

  return (s);
}

/* Allocate a new partial_symtab NAME */

static struct partial_symtab *
new_psymtab (name, objfile, section_offsets)
     char *name;
     struct objfile *objfile;
     struct section_offsets *section_offsets;
{
  struct partial_symtab *psymtab;

  psymtab = allocate_psymtab (name, objfile);
  psymtab->section_offsets = section_offsets;

  /* Keep a backpointer to the file's symbols */

  psymtab->read_symtab_private = ((char *)
				  obstack_alloc (&objfile->psymbol_obstack,
						 sizeof (struct symloc)));
  memset ((PTR) psymtab->read_symtab_private, 0, sizeof (struct symloc));
  CUR_BFD (psymtab) = cur_bfd;
  DEBUG_SWAP (psymtab) = debug_swap;
  DEBUG_INFO (psymtab) = debug_info;
  PENDING_LIST (psymtab) = pending_list;

  /* The way to turn this into a symtab is to call... */
  psymtab->read_symtab = mdebug_psymtab_to_symtab;
  return (psymtab);
}


/* Allocate a linetable array of the given SIZE.  Since the struct
   already includes one item, we subtract one when calculating the
   proper size to allocate.  */

static struct linetable *
new_linetable (size)
     int size;
{
  struct linetable *l;

  size = (size - 1) * sizeof (l->item) + sizeof (struct linetable);
  l = (struct linetable *) xmalloc (size);
  l->nitems = 0;
  return l;
}

/* Oops, too big. Shrink it.  This was important with the 2.4 linetables,
   I am not so sure about the 3.4 ones.

   Since the struct linetable already includes one item, we subtract one when
   calculating the proper size to allocate.  */

static struct linetable *
shrink_linetable (lt)
     struct linetable *lt;
{

  return (struct linetable *) xrealloc ((PTR) lt,
					(sizeof (struct linetable)
					 + ((lt->nitems - 1)
					    * sizeof (lt->item))));
}

/* Allocate and zero a new blockvector of NBLOCKS blocks. */

static struct blockvector *
new_bvect (nblocks)
     int nblocks;
{
  struct blockvector *bv;
  int size;

  size = sizeof (struct blockvector) + nblocks * sizeof (struct block *);
  bv = (struct blockvector *) xzalloc (size);

  BLOCKVECTOR_NBLOCKS (bv) = nblocks;

  return bv;
}

/* Allocate and zero a new block of MAXSYMS symbols */

static struct block *
new_block (maxsyms)
     int maxsyms;
{
  int size = sizeof (struct block) + (maxsyms - 1) * sizeof (struct symbol *);

  return (struct block *) xzalloc (size);
}

/* Ooops, too big. Shrink block B in symtab S to its minimal size.
   Shrink_block can also be used by add_symbol to grow a block.  */

static struct block *
shrink_block (b, s)
     struct block *b;
     struct symtab *s;
{
  struct block *new;
  struct blockvector *bv = BLOCKVECTOR (s);
  int i;

  /* Just reallocate it and fix references to the old one */

  new = (struct block *) xrealloc ((PTR) b,
				   (sizeof (struct block)
				    + ((BLOCK_NSYMS (b) - 1)
				       * sizeof (struct symbol *))));

  /* Should chase pointers to old one.  Fortunately, that`s just
	   the block`s function and inferior blocks */
  if (BLOCK_FUNCTION (new) && SYMBOL_BLOCK_VALUE (BLOCK_FUNCTION (new)) == b)
    SYMBOL_BLOCK_VALUE (BLOCK_FUNCTION (new)) = new;
  for (i = 0; i < BLOCKVECTOR_NBLOCKS (bv); i++)
    if (BLOCKVECTOR_BLOCK (bv, i) == b)
      BLOCKVECTOR_BLOCK (bv, i) = new;
    else if (BLOCK_SUPERBLOCK (BLOCKVECTOR_BLOCK (bv, i)) == b)
      BLOCK_SUPERBLOCK (BLOCKVECTOR_BLOCK (bv, i)) = new;
  return new;
}

/* Create a new symbol with printname NAME */

static struct symbol *
new_symbol (name)
     char *name;
{
  struct symbol *s = ((struct symbol *)
		      obstack_alloc (&current_objfile->symbol_obstack,
				     sizeof (struct symbol)));

  memset ((PTR) s, 0, sizeof (*s));
  SYMBOL_NAME (s) = name;
  SYMBOL_LANGUAGE (s) = psymtab_language;
  SYMBOL_INIT_DEMANGLED_NAME (s, &current_objfile->symbol_obstack);
  return s;
}

/* Create a new type with printname NAME */

static struct type *
new_type (name)
     char *name;
{
  struct type *t;

  t = alloc_type (current_objfile);
  TYPE_NAME (t) = name;
  TYPE_CPLUS_SPECIFIC (t) = (struct cplus_struct_type *) &cplus_struct_default;
  return t;
}

/* Read ECOFF debugging information from a BFD section.  This is
   called from elfread.c.  It parses the section into a
   ecoff_debug_info struct, and then lets the rest of the file handle
   it as normal.  */

void
elfmdebug_build_psymtabs (objfile, swap, sec, section_offsets)
     struct objfile *objfile;
     const struct ecoff_debug_swap *swap;
     asection *sec;
     struct section_offsets *section_offsets;
{
  bfd *abfd = objfile->obfd;
  struct ecoff_debug_info *info;

  info = ((struct ecoff_debug_info *)
	  obstack_alloc (&objfile->psymbol_obstack,
			 sizeof (struct ecoff_debug_info)));

  if (!(*swap->read_debug_info) (abfd, sec, info))
    error ("Error reading ECOFF debugging information: %s",
	   bfd_errmsg (bfd_get_error ()));

  mdebug_build_psymtabs (objfile, swap, info, section_offsets);
}


/* Things used for calling functions in the inferior.
   These functions are exported to our companion
   mips-tdep.c file and are here because they play
   with the symbol-table explicitly. */

/* Sigtramp: make sure we have all the necessary information
   about the signal trampoline code. Since the official code
   from MIPS does not do so, we make up that information ourselves.
   If they fix the library (unlikely) this code will neutralize itself. */

/* FIXME: This function is called only by mips-tdep.c.  It needs to be
   here because it calls functions defined in this file, but perhaps
   this could be handled in a better way.  */

void
fixup_sigtramp ()
{
  struct symbol *s;
  struct symtab *st;
  struct block *b, *b0 = NULL;

  sigtramp_address = -1;

  /* We have to handle the following cases here:
     a) The Mips library has a sigtramp label within sigvec.
     b) Irix has a _sigtramp which we want to use, but it also has sigvec.  */
  s = lookup_symbol ("sigvec", 0, VAR_NAMESPACE, 0, NULL);
  if (s != 0)
    {
      b0 = SYMBOL_BLOCK_VALUE (s);
      s = lookup_symbol ("sigtramp", b0, VAR_NAMESPACE, 0, NULL);
    }
  if (s == 0)
    {
      /* No sigvec or no sigtramp inside sigvec, try _sigtramp.  */
      s = lookup_symbol ("_sigtramp", 0, VAR_NAMESPACE, 0, NULL);
    }

  /* But maybe this program uses its own version of sigvec */
  if (s == 0)
    return;

  /* Did we or MIPSco fix the library ? */
  if (SYMBOL_CLASS (s) == LOC_BLOCK)
    {
      sigtramp_address = BLOCK_START (SYMBOL_BLOCK_VALUE (s));
      sigtramp_end = BLOCK_END (SYMBOL_BLOCK_VALUE (s));
      return;
    }

  sigtramp_address = SYMBOL_VALUE (s);
  sigtramp_end = sigtramp_address + 0x88;	/* black magic */

  /* But what symtab does it live in ? */
  st = find_pc_symtab (SYMBOL_VALUE (s));

  /*
   * Ok, there goes the fix: turn it into a procedure, with all the
   * needed info.  Note we make it a nested procedure of sigvec,
   * which is the way the (assembly) code is actually written.
   */
  SYMBOL_NAMESPACE (s) = VAR_NAMESPACE;
  SYMBOL_CLASS (s) = LOC_BLOCK;
  SYMBOL_TYPE (s) = init_type (TYPE_CODE_FUNC, 4, 0, (char *) NULL,
			       st->objfile);
  TYPE_TARGET_TYPE (SYMBOL_TYPE (s)) = builtin_type_void;

  /* Need a block to allocate MIPS_EFI_SYMBOL_NAME in */
  b = new_block (1);
  SYMBOL_BLOCK_VALUE (s) = b;
  BLOCK_START (b) = sigtramp_address;
  BLOCK_END (b) = sigtramp_end;
  BLOCK_FUNCTION (b) = s;
  BLOCK_SUPERBLOCK (b) = BLOCK_SUPERBLOCK (b0);
  add_block (b, st);
  sort_blocks (st);

  /* Make a MIPS_EFI_SYMBOL_NAME entry for it */
  {
    struct mips_extra_func_info *e =
      ((struct mips_extra_func_info *)
       xzalloc (sizeof (struct mips_extra_func_info)));

    e->numargs = 0;		/* the kernel thinks otherwise */
    e->pdr.frameoffset = 32;
    e->pdr.framereg = SP_REGNUM;
    /* Note that setting pcreg is no longer strictly necessary as
       mips_frame_saved_pc is now aware of signal handler frames.  */
    e->pdr.pcreg = PC_REGNUM;
    e->pdr.regmask = -2;
    /* Offset to saved r31, in the sigtramp case the saved registers
       are above the frame in the sigcontext.
       We have 4 alignment bytes, 12 bytes for onstack, mask and pc,
       32 * 4 bytes for the general registers, 12 bytes for mdhi, mdlo, ownedfp
       and 32 * 4 bytes for the floating point registers.  */
    e->pdr.regoffset = 4 + 12 + 31 * 4;
    e->pdr.fregmask = -1;
    /* Offset to saved f30 (first saved *double* register).  */
    e->pdr.fregoffset = 4 + 12 + 32 * 4 + 12 + 30 * 4;
    e->pdr.isym = (long) s;
    e->pdr.adr = sigtramp_address;

    current_objfile = st->objfile;	/* Keep new_symbol happy */
    s = new_symbol (MIPS_EFI_SYMBOL_NAME);
    SYMBOL_VALUE (s) = (long) e;
    SYMBOL_NAMESPACE (s) = LABEL_NAMESPACE;
    SYMBOL_CLASS (s) = LOC_CONST;
    SYMBOL_TYPE (s) = builtin_type_void;
    current_objfile = NULL;
  }

  BLOCK_SYM (b, BLOCK_NSYMS (b)++) = s;
}

void
_initialize_mdebugread ()
{
  /* Missing basic types */

  /* Is a "string" the way btString means it the same as TYPE_CODE_STRING?
     FIXME.  */
  mdebug_type_string =
    init_type (TYPE_CODE_STRING,
	       TARGET_CHAR_BIT / TARGET_CHAR_BIT,
	       0, "string",
	       (struct objfile *) NULL);

  mdebug_type_complex =
    init_type (TYPE_CODE_ERROR,
	       TARGET_COMPLEX_BIT / TARGET_CHAR_BIT,
	       0, "complex",
	       (struct objfile *) NULL);
  mdebug_type_double_complex =
    init_type (TYPE_CODE_ERROR,
	       TARGET_DOUBLE_COMPLEX_BIT / TARGET_CHAR_BIT,
	       0, "double complex",
	       (struct objfile *) NULL);

  /* We use TYPE_CODE_INT to print these as integers.  Does this do any
     good?  Would we be better off with TYPE_CODE_ERROR?  Should
     TYPE_CODE_ERROR print things in hex if it knows the size?  */
  mdebug_type_fixed_dec =
    init_type (TYPE_CODE_INT,
	       TARGET_INT_BIT / TARGET_CHAR_BIT,
	       0, "fixed decimal",
	       (struct objfile *) NULL);

  mdebug_type_float_dec =
    init_type (TYPE_CODE_ERROR,
	       TARGET_DOUBLE_BIT / TARGET_CHAR_BIT,
	       0, "floating decimal",
	       (struct objfile *) NULL);
}
