#linux.sh    Linux hints file for (Perl 4.036)
#Created by: Louis J. LaBash, Jr. {lou@minuet.siue.edu} 18 Jan 94-ljl-
#Modified: 14 Mar 94-ljl-
#Modified: removed signal routine, patching Configure instead 15 Jun 94-ljl-
#Modified: changed target directories 7 Jul 94-ljl-

nativegcc='define'
cc='gcc'
optimize='-O2'
ldflags='-s'
d_mymalloc=undef
yacc='bison -y'
mansrc='/usr/local/man/man1'
manext='1'
nroff='groff'
bin='/usr/local/bin'
installbin='/usr/local/bin'
scriptdir='/usr/local/bin'
installscr='/usr/local/bin'
package='perl(linux-36LA)'
privlib='/usr/local/lib/perl4'
installprivlib='/usr/local/lib/perl4'
models='none'

cat <<EOF




               -*-Congratulations, you're running Linux -*-
       This is a hints file for Linux, it suggest the defaults to use.

   If needed, change installation directories to conform with your system's.

                              --*--













EOF

#end of linux.sh
