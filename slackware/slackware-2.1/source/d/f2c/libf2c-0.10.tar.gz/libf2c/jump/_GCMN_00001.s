.globl _xargc
_xargc:
	.space 4
