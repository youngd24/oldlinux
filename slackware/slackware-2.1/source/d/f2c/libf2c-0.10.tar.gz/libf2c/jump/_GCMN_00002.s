.globl _xargv
_xargv:
	.space 4
