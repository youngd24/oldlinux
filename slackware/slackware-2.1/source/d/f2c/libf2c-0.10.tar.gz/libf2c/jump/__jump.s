	.text
	.long 1000

	.align	3
	.globl _f__cabs
_f__cabs:
	jmp	_f__cabs__LOCAL__

	.align	3
	.globl _abort_
_abort_:
	jmp	_abort___LOCAL__

	.align	3
	.globl _ap_end
_ap_end:
	jmp	_ap_end__LOCAL__

	.align	3
	.globl _b_char
_b_char:
	jmp	_b_char__LOCAL__

	.align	3
	.globl _c_abs
_c_abs:
	jmp	_c_abs__LOCAL__

	.align	3
	.globl _c_cos
_c_cos:
	jmp	_c_cos__LOCAL__

	.align	3
	.globl _c_dfe
_c_dfe:
	jmp	_c_dfe__LOCAL__

	.align	3
	.globl _c_div
_c_div:
	jmp	_c_div__LOCAL__

	.align	3
	.globl _c_due
_c_due:
	jmp	_c_due__LOCAL__

	.align	3
	.globl _c_exp
_c_exp:
	jmp	_c_exp__LOCAL__

	.align	3
	.globl _c_le
_c_le:
	jmp	_c_le__LOCAL__

	.align	3
	.globl _c_liw
_c_liw:
	jmp	_c_liw__LOCAL__

	.align	3
	.globl _c_log
_c_log:
	jmp	_c_log__LOCAL__

	.align	3
	.globl _c_sfe
_c_sfe:
	jmp	_c_sfe__LOCAL__

	.align	3
	.globl _c_si
_c_si:
	jmp	_c_si__LOCAL__

	.align	3
	.globl _c_sin
_c_sin:
	jmp	_c_sin__LOCAL__

	.align	3
	.globl _c_sqrt
_c_sqrt:
	jmp	_c_sqrt__LOCAL__

	.align	3
	.globl _c_sue
_c_sue:
	jmp	_c_sue__LOCAL__

	.align	3
	.globl _f__canseek
_f__canseek:
	jmp	_f__canseek__LOCAL__

	.align	3
	.globl _d_abs
_d_abs:
	jmp	_d_abs__LOCAL__

	.align	3
	.globl _d_acos
_d_acos:
	jmp	_d_acos__LOCAL__

	.align	3
	.globl _d_asin
_d_asin:
	jmp	_d_asin__LOCAL__

	.align	3
	.globl _d_atan
_d_atan:
	jmp	_d_atan__LOCAL__

	.align	3
	.globl _d_atn2
_d_atn2:
	jmp	_d_atn2__LOCAL__

	.align	3
	.globl _d_cnjg
_d_cnjg:
	jmp	_d_cnjg__LOCAL__

	.align	3
	.globl _d_cos
_d_cos:
	jmp	_d_cos__LOCAL__

	.align	3
	.globl _d_cosh
_d_cosh:
	jmp	_d_cosh__LOCAL__

	.align	3
	.globl _d_dim
_d_dim:
	jmp	_d_dim__LOCAL__

	.align	3
	.globl _d_exp
_d_exp:
	jmp	_d_exp__LOCAL__

	.align	3
	.globl _d_imag
_d_imag:
	jmp	_d_imag__LOCAL__

	.align	3
	.globl _d_int
_d_int:
	jmp	_d_int__LOCAL__

	.align	3
	.globl _d_lg10
_d_lg10:
	jmp	_d_lg10__LOCAL__

	.align	3
	.globl _d_log
_d_log:
	jmp	_d_log__LOCAL__

	.align	3
	.globl _d_mod
_d_mod:
	jmp	_d_mod__LOCAL__

	.align	3
	.globl _d_nint
_d_nint:
	jmp	_d_nint__LOCAL__

	.align	3
	.globl _d_prod
_d_prod:
	jmp	_d_prod__LOCAL__

	.align	3
	.globl _d_sign
_d_sign:
	jmp	_d_sign__LOCAL__

	.align	3
	.globl _d_sin
_d_sin:
	jmp	_d_sin__LOCAL__

	.align	3
	.globl _d_sinh
_d_sinh:
	jmp	_d_sinh__LOCAL__

	.align	3
	.globl _d_sqrt
_d_sqrt:
	jmp	_d_sqrt__LOCAL__

	.align	3
	.globl _d_tan
_d_tan:
	jmp	_d_tan__LOCAL__

	.align	3
	.globl _d_tanh
_d_tanh:
	jmp	_d_tanh__LOCAL__

	.align	3
	.globl _derf_
_derf_:
	jmp	_derf___LOCAL__

	.align	3
	.globl _derfc_
_derfc_:
	jmp	_derfc___LOCAL__

	.align	3
	.globl _do_fio
_do_fio:
	jmp	_do_fio__LOCAL__

	.align	3
	.globl _do_lio
_do_lio:
	jmp	_do_lio__LOCAL__

	.align	3
	.globl _do_ud
_do_ud:
	jmp	_do_ud__LOCAL__

	.align	3
	.globl _do_uio
_do_uio:
	jmp	_do_uio__LOCAL__

	.align	3
	.globl _do_us
_do_us:
	jmp	_do_us__LOCAL__

	.align	3
	.globl _e_d
_e_d:
	jmp	_e_d__LOCAL__

	.align	3
	.globl _e_rdfe
_e_rdfe:
	jmp	_e_rdfe__LOCAL__

	.align	3
	.globl _e_rdue
_e_rdue:
	jmp	_e_rdue__LOCAL__

	.align	3
	.globl _e_rsfe
_e_rsfe:
	jmp	_e_rsfe__LOCAL__

	.align	3
	.globl _e_rsfi
_e_rsfi:
	jmp	_e_rsfi__LOCAL__

	.align	3
	.globl _e_rsle
_e_rsle:
	jmp	_e_rsle__LOCAL__

	.align	3
	.globl _e_rsli
_e_rsli:
	jmp	_e_rsli__LOCAL__

	.align	3
	.globl _e_rsue
_e_rsue:
	jmp	_e_rsue__LOCAL__

	.align	3
	.globl _e_wdfe
_e_wdfe:
	jmp	_e_wdfe__LOCAL__

	.align	3
	.globl _e_wdue
_e_wdue:
	jmp	_e_wdue__LOCAL__

	.align	3
	.globl _e_wsfe
_e_wsfe:
	jmp	_e_wsfe__LOCAL__

	.align	3
	.globl _e_wsfi
_e_wsfi:
	jmp	_e_wsfi__LOCAL__

	.align	3
	.globl _e_wsle
_e_wsle:
	jmp	_e_wsle__LOCAL__

	.align	3
	.globl _e_wsli
_e_wsli:
	jmp	_e_wsli__LOCAL__

	.align	3
	.globl _e_wsue
_e_wsue:
	jmp	_e_wsue__LOCAL__

	.align	3
	.globl _ef1asc_
_ef1asc_:
	jmp	_ef1asc___LOCAL__

	.align	3
	.globl _ef1cmc_
_ef1cmc_:
	jmp	_ef1cmc___LOCAL__

	.align	3
	.globl _en_fio
_en_fio:
	jmp	_en_fio__LOCAL__

	.align	3
	.globl _erf_
_erf_:
	jmp	_erf___LOCAL__

	.align	3
	.globl _erfc_
_erfc_:
	jmp	_erfc___LOCAL__

	.align	3
	.globl _f_back
_f_back:
	jmp	_f_back__LOCAL__

	.align	3
	.globl _f_clos
_f_clos:
	jmp	_f_clos__LOCAL__

	.align	3
	.globl _f_end
_f_end:
	jmp	_f_end__LOCAL__

	.align	3
	.globl _f_exit
_f_exit:
	jmp	_f_exit__LOCAL__

	.align	3
	.globl _f_init
_f_init:
	jmp	_f_init__LOCAL__

	.align	3
	.globl _f_inqu
_f_inqu:
	jmp	_f_inqu__LOCAL__

	.align	3
	.globl _f_list
_f_list:
	jmp	_f_list__LOCAL__

	.align	3
	.globl _f_open
_f_open:
	jmp	_f_open__LOCAL__

	.align	3
	.globl _f_rew
_f_rew:
	jmp	_f_rew__LOCAL__

	.align	3
	.globl _f_s
_f_s:
	jmp	_f_s__LOCAL__

	.align	3
	.globl _f__fatal
_f__fatal:
	jmp	_f__fatal__LOCAL__

	.align	3
	.globl _fk_open
_fk_open:
	jmp	_fk_open__LOCAL__

	.align	3
	.globl _flush_
_flush_:
	jmp	_flush___LOCAL__

	.align	3
	.globl _fmt_bg
_fmt_bg:
	jmp	_fmt_bg__LOCAL__

	.align	3
	.globl _g_char
_g_char:
	jmp	_g_char__LOCAL__

	.align	3
	.globl _getarg_
_getarg_:
	jmp	_getarg___LOCAL__

	.align	3
	.globl _getenv_
_getenv_:
	jmp	_getenv___LOCAL__

	.align	3
	.globl _gt_num
_gt_num:
	jmp	_gt_num__LOCAL__

	.align	3
	.globl _h_abs
_h_abs:
	jmp	_h_abs__LOCAL__

	.align	3
	.globl _h_dim
_h_dim:
	jmp	_h_dim__LOCAL__

	.align	3
	.globl _h_dnnt
_h_dnnt:
	jmp	_h_dnnt__LOCAL__

	.align	3
	.globl _h_indx
_h_indx:
	jmp	_h_indx__LOCAL__

	.align	3
	.globl _h_len
_h_len:
	jmp	_h_len__LOCAL__

	.align	3
	.globl _h_mod
_h_mod:
	jmp	_h_mod__LOCAL__

	.align	3
	.globl _h_nint
_h_nint:
	jmp	_h_nint__LOCAL__

	.align	3
	.globl _h_sign
_h_sign:
	jmp	_h_sign__LOCAL__

	.align	3
	.globl _hl_ge
_hl_ge:
	jmp	_hl_ge__LOCAL__

	.align	3
	.globl _hl_gt
_hl_gt:
	jmp	_hl_gt__LOCAL__

	.align	3
	.globl _hl_le
_hl_le:
	jmp	_hl_le__LOCAL__

	.align	3
	.globl _hl_lt
_hl_lt:
	jmp	_hl_lt__LOCAL__

	.align	3
	.globl _i_abs
_i_abs:
	jmp	_i_abs__LOCAL__

	.align	3
	.globl _i_dim
_i_dim:
	jmp	_i_dim__LOCAL__

	.align	3
	.globl _i_dnnt
_i_dnnt:
	jmp	_i_dnnt__LOCAL__

	.align	3
	.space 8
	.align	3
	.globl _i_indx
_i_indx:
	jmp	_i_indx__LOCAL__

	.align	3
	.globl _i_len
_i_len:
	jmp	_i_len__LOCAL__

	.align	3
	.globl _i_mod
_i_mod:
	jmp	_i_mod__LOCAL__

	.align	3
	.globl _i_nint
_i_nint:
	jmp	_i_nint__LOCAL__

	.align	3
	.globl _i_sign
_i_sign:
	jmp	_i_sign__LOCAL__

	.align	3
	.globl _i_tem
_i_tem:
	jmp	_i_tem__LOCAL__

	.align	3
	.space 8
	.align	3
	.globl _iargc_
_iargc_:
	jmp	_iargc___LOCAL__

	.align	3
	.globl _f__icvt
_f__icvt:
	jmp	_f__icvt__LOCAL__

	.align	3
	.space 8
	.align	3
	.globl _f__isdev
_f__isdev:
	jmp	_f__isdev__LOCAL__

	.align	3
	.globl _l_C
_l_C:
	jmp	_l_C__LOCAL__

	.align	3
	.globl _l_CHAR
_l_CHAR:
	jmp	_l_CHAR__LOCAL__

	.align	3
	.globl _l_L
_l_L:
	jmp	_l_L__LOCAL__

	.align	3
	.globl _l_R
_l_R:
	jmp	_l_R__LOCAL__

	.align	3
	.globl _l_ge
_l_ge:
	jmp	_l_ge__LOCAL__

	.align	3
	.globl _l_gt
_l_gt:
	jmp	_l_gt__LOCAL__

	.align	3
	.globl _l_le
_l_le:
	jmp	_l_le__LOCAL__

	.align	3
	.globl _l_lt
_l_lt:
	jmp	_l_lt__LOCAL__

	.align	3
	.globl _l_read
_l_read:
	jmp	_l_read__LOCAL__

	.align	3
	.globl _l_write
_l_write:
	jmp	_l_write__LOCAL__

	.align	3
	.globl _mk_hashtab
_mk_hashtab:
	jmp	_mk_hashtab__LOCAL__

	.align	3
	.globl _mv_cur
_mv_cur:
	jmp	_mv_cur__LOCAL__

	.align	3
	.globl _f__mvgbt
_f__mvgbt:
	jmp	_f__mvgbt__LOCAL__

	.align	3
	.globl _ne_d
_ne_d:
	jmp	_ne_d__LOCAL__

	.align	3
	.globl _f__nowreading
_f__nowreading:
	jmp	_f__nowreading__LOCAL__

	.align	3
	.globl _f__nowwriting
_f__nowwriting:
	jmp	_f__nowwriting__LOCAL__

	.align	3
	.globl _op_gen
_op_gen:
	jmp	_op_gen__LOCAL__

	.align	3
	.globl _pars_f
_pars_f:
	jmp	_pars_f__LOCAL__

	.align	3
	.globl _pow_ci
_pow_ci:
	jmp	_pow_ci__LOCAL__

	.align	3
	.globl _pow_dd
_pow_dd:
	jmp	_pow_dd__LOCAL__

	.align	3
	.globl _pow_di
_pow_di:
	jmp	_pow_di__LOCAL__

	.align	3
	.globl _pow_hh
_pow_hh:
	jmp	_pow_hh__LOCAL__

	.align	3
	.globl _pow_ii
_pow_ii:
	jmp	_pow_ii__LOCAL__

	.align	3
	.globl _pow_ri
_pow_ri:
	jmp	_pow_ri__LOCAL__

	.align	3
	.globl _pow_zi
_pow_zi:
	jmp	_pow_zi__LOCAL__

	.align	3
	.globl _pow_zz
_pow_zz:
	jmp	_pow_zz__LOCAL__

	.align	3
	.globl _r_abs
_r_abs:
	jmp	_r_abs__LOCAL__

	.align	3
	.globl _r_acos
_r_acos:
	jmp	_r_acos__LOCAL__

	.align	3
	.globl _r_asin
_r_asin:
	jmp	_r_asin__LOCAL__

	.align	3
	.globl _r_atan
_r_atan:
	jmp	_r_atan__LOCAL__

	.align	3
	.globl _r_atn2
_r_atn2:
	jmp	_r_atn2__LOCAL__

	.align	3
	.globl _r_cnjg
_r_cnjg:
	jmp	_r_cnjg__LOCAL__

	.align	3
	.globl _r_cos
_r_cos:
	jmp	_r_cos__LOCAL__

	.align	3
	.globl _r_cosh
_r_cosh:
	jmp	_r_cosh__LOCAL__

	.align	3
	.globl _r_dim
_r_dim:
	jmp	_r_dim__LOCAL__

	.align	3
	.globl _r_exp
_r_exp:
	jmp	_r_exp__LOCAL__

	.align	3
	.globl _r_imag
_r_imag:
	jmp	_r_imag__LOCAL__

	.align	3
	.globl _r_int
_r_int:
	jmp	_r_int__LOCAL__

	.align	3
	.globl _r_lg10
_r_lg10:
	jmp	_r_lg10__LOCAL__

	.align	3
	.globl _r_log
_r_log:
	jmp	_r_log__LOCAL__

	.align	3
	.globl _r_mod
_r_mod:
	jmp	_r_mod__LOCAL__

	.align	3
	.globl _r_nint
_r_nint:
	jmp	_r_nint__LOCAL__

	.align	3
	.globl _r_sign
_r_sign:
	jmp	_r_sign__LOCAL__

	.align	3
	.globl _r_sin
_r_sin:
	jmp	_r_sin__LOCAL__

	.align	3
	.globl _r_sinh
_r_sinh:
	jmp	_r_sinh__LOCAL__

	.align	3
	.globl _r_sqrt
_r_sqrt:
	jmp	_r_sqrt__LOCAL__

	.align	3
	.globl _r_tan
_r_tan:
	jmp	_r_tan__LOCAL__

	.align	3
	.globl _r_tanh
_r_tanh:
	jmp	_r_tanh__LOCAL__

	.align	3
	.globl _rd_ed
_rd_ed:
	jmp	_rd_ed__LOCAL__

	.align	3
	.globl _rd_ned
_rd_ned:
	jmp	_rd_ned__LOCAL__

	.align	3
	.globl _s_cat
_s_cat:
	jmp	_s_cat__LOCAL__

	.align	3
	.globl _s_cmp
_s_cmp:
	jmp	_s_cmp__LOCAL__

	.align	3
	.globl _s_copy
_s_copy:
	jmp	_s_copy__LOCAL__

	.align	3
	.globl _s_paus
_s_paus:
	jmp	_s_paus__LOCAL__

	.align	3
	.globl _s_rdfe
_s_rdfe:
	jmp	_s_rdfe__LOCAL__

	.align	3
	.globl _s_rdue
_s_rdue:
	jmp	_s_rdue__LOCAL__

	.align	3
	.globl _s_rnge
_s_rnge:
	jmp	_s_rnge__LOCAL__

	.align	3
	.globl _s_rsfe
_s_rsfe:
	jmp	_s_rsfe__LOCAL__

	.align	3
	.globl _s_rsfi
_s_rsfi:
	jmp	_s_rsfi__LOCAL__

	.align	3
	.globl _s_rsle
_s_rsle:
	jmp	_s_rsle__LOCAL__

	.align	3
	.globl _s_rsli
_s_rsli:
	jmp	_s_rsli__LOCAL__

	.align	3
	.globl _s_rsne
_s_rsne:
	jmp	_s_rsne__LOCAL__

	.align	3
	.globl _s_rsni
_s_rsni:
	jmp	_s_rsni__LOCAL__

	.align	3
	.globl _s_rsue
_s_rsue:
	jmp	_s_rsue__LOCAL__

	.align	3
	.globl _s_stop
_s_stop:
	jmp	_s_stop__LOCAL__

	.align	3
	.globl _s_wdfe
_s_wdfe:
	jmp	_s_wdfe__LOCAL__

	.align	3
	.globl _s_wdue
_s_wdue:
	jmp	_s_wdue__LOCAL__

	.align	3
	.globl _s_wsfe
_s_wsfe:
	jmp	_s_wsfe__LOCAL__

	.align	3
	.globl _s_wsfi
_s_wsfi:
	jmp	_s_wsfi__LOCAL__

	.align	3
	.globl _s_wsle
_s_wsle:
	jmp	_s_wsle__LOCAL__

	.align	3
	.globl _s_wsli
_s_wsli:
	jmp	_s_wsli__LOCAL__

	.align	3
	.globl _s_wsne
_s_wsne:
	jmp	_s_wsne__LOCAL__

	.align	3
	.globl _s_wsni
_s_wsni:
	jmp	_s_wsni__LOCAL__

	.align	3
	.globl _s_wsue
_s_wsue:
	jmp	_s_wsue__LOCAL__

	.align	3
	.globl _sig_die
_sig_die:
	jmp	_sig_die__LOCAL__

	.align	3
	.globl _signal_
_signal_:
	jmp	_signal___LOCAL__

	.align	3
	.globl _system_
_system_:
	jmp	_system___LOCAL__

	.align	3
	.globl _t_getc
_t_getc:
	jmp	_t_getc__LOCAL__

	.align	3
	.globl _t_putc
_t_putc:
	jmp	_t_putc__LOCAL__

	.align	3
	.globl _t_runc
_t_runc:
	jmp	_t_runc__LOCAL__

	.align	3
	.globl _type_f
_type_f:
	jmp	_type_f__LOCAL__

	.align	3
	.globl _w_ed
_w_ed:
	jmp	_w_ed__LOCAL__

	.align	3
	.globl _w_ned
_w_ned:
	jmp	_w_ned__LOCAL__

	.align	3
	.globl _wrt_E
_wrt_E:
	jmp	_wrt_E__LOCAL__

	.align	3
	.globl _wrt_F
_wrt_F:
	jmp	_wrt_F__LOCAL__

	.align	3
	.globl _wrt_L
_wrt_L:
	jmp	_wrt_L__LOCAL__

	.align	3
	.globl _x_endp
_x_endp:
	jmp	_x_endp__LOCAL__

	.align	3
	.globl _x_getc
_x_getc:
	jmp	_x_getc__LOCAL__

	.align	3
	.globl _x_putc
_x_putc:
	jmp	_x_putc__LOCAL__

	.align	3
	.globl _x_rev
_x_rev:
	jmp	_x_rev__LOCAL__

	.align	3
	.globl _x_rsne
_x_rsne:
	jmp	_x_rsne__LOCAL__

	.align	3
	.globl _x_wSL
_x_wSL:
	jmp	_x_wSL__LOCAL__

	.align	3
	.globl _x_wsne
_x_wsne:
	jmp	_x_wsne__LOCAL__

	.align	3
	.globl _xrd_SL
_xrd_SL:
	jmp	_xrd_SL__LOCAL__

	.align	3
	.globl _xw_end
_xw_end:
	jmp	_xw_end__LOCAL__

	.align	3
	.globl _xw_rev
_xw_rev:
	jmp	_xw_rev__LOCAL__

	.align	3
	.globl _y_err
_y_err:
	jmp	_y_err__LOCAL__

	.align	3
	.globl _y_getc
_y_getc:
	jmp	_y_getc__LOCAL__

	.align	3
	.space 8
	.align	3
	.globl _y_newrec
_y_newrec:
	jmp	_y_newrec__LOCAL__

	.align	3
	.globl _y_putc
_y_putc:
	jmp	_y_putc__LOCAL__

	.align	3
	.globl _y_rev
_y_rev:
	jmp	_y_rev__LOCAL__

	.align	3
	.globl _y_rsk
_y_rsk:
	jmp	_y_rsk__LOCAL__

	.align	3
	.globl _z_abs
_z_abs:
	jmp	_z_abs__LOCAL__

	.align	3
	.globl _z_cos
_z_cos:
	jmp	_z_cos__LOCAL__

	.align	3
	.globl _z_div
_z_div:
	jmp	_z_div__LOCAL__

	.align	3
	.globl _z_exp
_z_exp:
	jmp	_z_exp__LOCAL__

	.align	3
	.globl _z_getc
_z_getc:
	jmp	_z_getc__LOCAL__

	.align	3
	.globl _z_log
_z_log:
	jmp	_z_log__LOCAL__

	.align	3
	.globl _z_putc
_z_putc:
	jmp	_z_putc__LOCAL__

	.align	3
	.globl _z_rnew
_z_rnew:
	jmp	_z_rnew__LOCAL__

	.align	3
	.globl _z_sin
_z_sin:
	jmp	_z_sin__LOCAL__

	.align	3
	.globl _z_sqrt
_z_sqrt:
	jmp	_z_sqrt__LOCAL__

	.align	3
	.globl _z_wnew
_z_wnew:
	jmp	_z_wnew__LOCAL__

	.align	3
	.globl _err__fl
_err__fl:
	jmp	_err__fl__LOCAL__

	.align	3
	.globl _iw_rev
_iw_rev:
	jmp	_iw_rev__LOCAL__

	.org 0x00003ff8
	jmp	___main

	.data
	.org 0
	.long __SHARABLE_CONFLICTS__
_GLOBAL_OFFSET_TABLE_:
	.long 0xfeeb1ed3
.globl __GOT__xargc
__GOT__xargc:
	.long _xargc
.globl __GOT__xargv
__GOT__xargv:
	.long _xargv
	.text
	.data
	.org 0x00001000
.globl _xargc
_xargc:
	.space 4

	.data
	.org 0x00001004
.globl _xargv
_xargv:
	.space 4

	.align	12
	.stabs "__SHARABLE_CONFLICTS__",25,0,0,_GLOBAL_OFFSET_TABLE_
