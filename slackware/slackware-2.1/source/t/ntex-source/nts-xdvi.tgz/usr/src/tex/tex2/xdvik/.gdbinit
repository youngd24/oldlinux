directory /w/xdvik:/w/kpathsea

define redo
symbol-file xdvi
exec-file xdvi
end

#set args -fg white -bg white $tdvi/test/story

#set env TEXFONTS .:/w/norm/deep1/mac.archive.um//:/w/norm/deep2/fonts//
#set args /w/norm/deep1/mac.archive.um/testfonts.dvi

#set args $tdvi/test/story
#set args +maketexpk $tdvi/test/maketex
#set args $tdvi/test/long
#set args $tdvi/test/nosize
#set args $tdvi/test/tixflier
#set args $tdvi/test/mag11
#set args -d 64 $tdvi/test/psfile # does path searching
set args -d 64 $tdvi/test/dynafig
#set args $tdvi/test/testps

