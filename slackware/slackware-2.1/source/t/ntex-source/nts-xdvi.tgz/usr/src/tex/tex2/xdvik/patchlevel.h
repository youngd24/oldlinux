char *version = "xdvik version 18b";

