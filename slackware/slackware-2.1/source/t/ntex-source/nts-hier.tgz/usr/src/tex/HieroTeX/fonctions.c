#include "hache.h"
#include <stdio.h>

TABLE signes;
TABLE definitions;
TABLE phonetiques;
char tempor [1000]= "";
int numligne;
extern char * genere();

struct donne {
  char * entree;
  char * phon;
  struct caractere {char *sym; unsigned  char numero;} symbole;
};


char *g(x, sens) 
     char *x; int sens;
{
  struct caractere* txt;
  if ((txt=(struct caractere*)trouve(x,signes)))
    {
      static char tmp[6];
      int nombre= sens*128 + txt->numero;
      sprintf(tmp,"%u",nombre);
      /* phonetique(trouve(x,phonetiques));*/
      return  (genere("\\Aca ", 
		    txt->sym,
		    "/",
		    tmp,		    
		    "/", 0));
    }
  else
    return NULL;
}



void resetmot()
{
  tempor[0]=0;
}

void phonetique(s)
     char * s;
{
  strcat(tempor,"-");
  strcat(tempor,s);
}

char *simplifie()
{
  /* X-XY-Y => XY */
  /* X-Y-XY => XY */
  /* XY-X-Y => XY */
  /* XYZ-X-Y-Z=> XYZ */
  /* XYZ-Y-Z=>XYZ */
}

void representation()
{
/*  fprintf(indexmots, "%s\n", tempor);
  resetmot();*/
}


void stocke(nom, valeur)
     char *nom, *valeur;
{
  insere(nom,valeur,definitions);
}

 struct donne les_donnees[]=
{
#include "seshSource.h"
    {0,0,{0,0}}
}
;

void initialise_lex()
{
  struct donne *i;
  signes= creer_table();
  definitions= creer_table();
  phonetiques= creer_table();
  /* indexmots= fopen("index.mot", "w");*/
  /* fflush(indexmots); */
  
  for (i= les_donnees; i->entree; i++)
    {
      insere(i->entree,&(i->symbole), signes);
      insere(i->entree,i->phon, phonetiques);
    }
}

#include <varargs.h>  
/* #include <malloc.h> */
  
char * genere(va_alist)
     va_dcl
{
  char * chaine;
  char * curr[10];
  int i, j, w, longueur;
  va_list pvar;
  va_start(pvar);

  i=0;
  longueur=0;
  
  while ((curr[i]= (va_arg(pvar, char *))))
    longueur+= strlen(curr[i++]);
  
  va_end(pvar);
  
  chaine= (char *)malloc(sizeof(char)* (longueur +1));
  for (j=0, w=0; j< i; j++)
    {
      int k;
      for (k=0; curr[j][k]; k++)
	chaine[w++]= curr[j][k];
    }
  chaine[w]=0;
  return chaine;
}
 

void yyerror(s)
     char *s;
{
  extern int yytext;
  fprintf(stderr, "\n\n%s, pres de %s ligne %d\n",s,yytext, numligne);
	exit(-1);
}

void main()
{
  /* extern */ int yydebug;
  initialise_lex();  
  yydebug= 1;
  (void)yyparse();
	exit(0);
}
