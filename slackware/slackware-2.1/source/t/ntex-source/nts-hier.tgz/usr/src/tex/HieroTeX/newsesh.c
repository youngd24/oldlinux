
/*  A Bison parser, made from newsesh.y  */

#define YYBISON 1  /* Identify Bison output.  */

#define	TEXTE	258
#define	DEBUTHIEROGS	259
#define	FINHIEROGS	260
#define	HIEROGLYPHE	261
#define	LIGAD	262
#define	POINT	263
#define	POINTPOINT	264
#define	KERNING	265
#define	ESPACE	266
#define	CARTO	267
#define	CARTF	268
#define	DEBCARTO	269
#define	MILCARTO	270
#define	FINCARTO	271
#define	DIEZE0	272
#define	DIEZE1	273
#define	ROMAIN	274
#define	GAUCHEDROITE	275
#define	DROITEGAUCHE	276
#define	INTERNALSPACE	277
#define	HACHUREGA	278
#define	HACHUREVA	279
#define	HACHUREHA	280
#define	HACHURETA	281
#define	HACHUREG	282
#define	HACHUREV	283
#define	HACHUREH	284
#define	HACHURET	285
#define	FINLIGNE	286
#define	FINPAGE	287
#define	TEXTESUPER	288
#define	POINTROUGE	289
#define	POINTNOIR	290
#define	COULEUR0	291
#define	COULEUR1	292
#define	HAPLOGRAPHIE	293
#define	LACUNE	294
#define	LIGNELACUNE	295
#define	DSTSUPERFETATOIRE	296
#define	FSTSUPERFETATOIRE	297
#define	DSTEFFACE	298
#define	FSTEFFACE	299
#define	DSTDISPARU	300
#define	FSTDISPARU	301
#define	DSTRAJOUTSCRIBE	302
#define	FSTRAJOUTSCRIBE	303
#define	DSTRAJOUTAUTEUR	304
#define	FSTRAJOUTAUTEUR	305
#define	SEREKH	306
#define	ENCEINTE	307
#define	CHATEAU	308
#define	DEBSEREKH	309
#define	MILSEREKH	310
#define	FINSEREKH	311
#define	DEBENCEINTE	312
#define	MILENCEINTE	313
#define	FINENCEINTE	314
#define	DEBCHATEAU	315
#define	MILCHATEAU	316
#define	FINCHATEAU	317

#line 7 "newsesh.y"

/* #include <malloc.h> */
typedef char * YYSTYPE;
char* genere();
extern void initialise_lex();
#include <stdio.h>
#ifndef NULL
#define NULL (char *)0
#endif

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __STDC__
#define const
#endif



#define	YYFINAL		87
#define	YYFLAG		-32768
#define	YYNTBASE	68

#define YYTRANSLATE(x) ((unsigned)(x) <= 317 ? yytranslate[x] : 82)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    66,
    67,    65,     2,     2,    63,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    64,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    60,    61,    62
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     3,     6,     7,    11,    13,    16,    18,    20,    22,
    24,    27,    32,    34,    36,    38,    40,    42,    44,    46,
    48,    50,    54,    58,    60,    62,    64,    66,    68,    70,
    72,    76,    80,    84,    88,    90,    94,    95,    98,   100,
   103,   106,   109,   112,   114,   116,   118,   120,   122,   124,
   126,   128,   130,   132,   134,   136,   138,   140,   142,   144,
   146,   148,   150,   152,   154,   156,   158,   160,   162
};

#endif

static const short yyrhs[] = {    68,
     3,     0,    68,    69,     0,     0,     4,    70,     5,     0,
    71,     0,    70,    71,     0,    72,     0,    11,     0,    31,
     0,    32,     0,    77,    73,     0,    72,    63,    77,    73,
     0,    74,     0,    19,     0,    38,     0,    20,     0,    21,
     0,    39,     0,    40,     0,    33,     0,    75,     0,    74,
    64,    75,     0,    75,    65,    76,     0,    76,     0,    78,
     0,     8,     0,    27,     0,    29,     0,    28,     0,    30,
     0,    79,    70,    13,     0,    80,    70,    81,     0,    17,
    70,    18,     0,    36,    70,    37,     0,     9,     0,    66,
    72,    67,     0,     0,    77,    10,     0,     6,     0,     6,
    23,     0,     6,    25,     0,     6,    24,     0,     6,    26,
     0,    12,     0,    14,     0,    15,     0,    16,     0,    51,
     0,    52,     0,    53,     0,    54,     0,    55,     0,    56,
     0,    57,     0,    58,     0,    59,     0,    60,     0,    61,
     0,    62,     0,    41,     0,    43,     0,    45,     0,    47,
     0,    49,     0,    42,     0,    44,     0,    46,     0,    48,
     0,    50,     0
};

#if YYDEBUG != 0
static const short yyrline[] = { 0,
    49,    50,    51,    54,    57,    58,    61,    62,    63,    64,
    68,    69,    72,    73,    74,    75,    76,    77,    78,    79,
    82,    83,    86,    87,    90,    91,    92,    93,    94,    95,
    96,    97,    98,    99,   100,   101,   105,   106,   109,   110,
   111,   112,   113,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,   130,   131,   134,
   135,   136,   137,   138,   141,   142,   143,   144,   145
};

static const char * const yytname[] = {   "$","error","$illegal.","TEXTE","DEBUTHIEROGS",
"FINHIEROGS","HIEROGLYPHE","LIGAD","POINT","POINTPOINT","KERNING","ESPACE","CARTO",
"CARTF","DEBCARTO","MILCARTO","FINCARTO","DIEZE0","DIEZE1","ROMAIN","GAUCHEDROITE",
"DROITEGAUCHE","INTERNALSPACE","HACHUREGA","HACHUREVA","HACHUREHA","HACHURETA",
"HACHUREG","HACHUREV","HACHUREH","HACHURET","FINLIGNE","FINPAGE","TEXTESUPER",
"POINTROUGE","POINTNOIR","COULEUR0","COULEUR1","HAPLOGRAPHIE","LACUNE","LIGNELACUNE",
"DSTSUPERFETATOIRE","FSTSUPERFETATOIRE","DSTEFFACE","FSTEFFACE","DSTDISPARU",
"FSTDISPARU","DSTRAJOUTSCRIBE","FSTRAJOUTSCRIBE","DSTRAJOUTAUTEUR","FSTRAJOUTAUTEUR",
"SEREKH","ENCEINTE","CHATEAU","DEBSEREKH","MILSEREKH","FINSEREKH","DEBENCEINTE",
"MILENCEINTE","FINENCEINTE","DEBCHATEAU","MILCHATEAU","FINCHATEAU","'-'","':'",
"'*'","'('","')'","tout","hierogs","exprs","express","quadras","quadra","sousquadras",
"sousquadra","inhierliste","kerning","hieroglyphe","DebutConstruction","parentheseD",
"parentheseF",""
};
#endif

static const short yyr1[] = {     0,
    68,    68,    68,    69,    70,    70,    71,    71,    71,    71,
    72,    72,    73,    73,    73,    73,    73,    73,    73,    73,
    74,    74,    75,    75,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76,    76,    76,    77,    77,    78,    78,
    78,    78,    78,    79,    79,    79,    79,    79,    79,    79,
    79,    79,    79,    79,    79,    79,    79,    79,    79,    80,
    80,    80,    80,    80,    81,    81,    81,    81,    81
};

static const short yyr2[] = {     0,
     2,     2,     0,     3,     1,     2,     1,     1,     1,     1,
     2,     4,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     3,     3,     1,     1,     1,     1,     1,     1,     1,
     3,     3,     3,     3,     1,     3,     0,     2,     1,     2,
     2,     2,     2,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1
};

static const short yydefact[] = {     3,
     0,     1,    37,     2,     8,     9,    10,    37,     5,     7,
     0,     4,     6,    37,    39,    26,    35,    38,    44,    45,
    46,    47,    37,    14,    16,    17,    27,    29,    28,    30,
    20,    37,    15,    18,    19,    60,    61,    62,    63,    64,
    48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
    58,    59,    37,    11,    13,    21,    24,    25,    37,    37,
     0,    40,    42,    41,    43,    37,    37,     0,     0,     0,
    37,    37,    12,    33,    34,    36,    22,    23,    31,    65,
    66,    67,    68,    69,    32,     0,     0
};

static const short yydefgoto[] = {     1,
     4,     8,     9,    10,    54,    55,    56,    57,    11,    58,
    59,    60,    85
};

static const short yypact[] = {-32768,
    17,-32768,    51,-32768,-32768,-32768,-32768,    61,-32768,   -55,
    -5,-32768,-32768,-32768,   120,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,    51,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,    51,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,   -51,   -47,-32768,-32768,    51,    51,
    -5,-32768,-32768,-32768,-32768,    67,    96,   -61,    59,    59,
   118,    92,-32768,-32768,-32768,-32768,   -47,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,    19,-32768
};

static const short yypgoto[] = {-32768,
-32768,    37,    -8,   -27,   -34,-32768,   -40,   -38,    16,-32768,
-32768,-32768,-32768
};


#define	YYLAST		150


static const short yytable[] = {    13,
    15,    14,    16,    17,    18,    76,    19,    14,    20,    21,
    22,    23,    69,    24,    25,    26,    86,    70,    87,     2,
     3,    27,    28,    29,    30,    68,    73,    31,    77,    61,
    32,    78,    33,    34,    35,    36,     0,    37,     0,    38,
     0,    39,     0,    40,     0,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    13,    13,    66,
    53,     5,    13,    13,    15,    12,    16,    17,    67,     0,
    19,     5,    20,    21,    22,    23,     0,     5,     0,     0,
     0,     6,     7,     0,    74,    27,    28,    29,    30,     0,
     0,     6,     7,     0,    32,    71,    72,     6,     7,    36,
     0,    37,     5,    38,     0,    39,     5,    40,     0,    41,
    42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
    52,     0,     6,     7,    53,     0,     6,     7,     5,     0,
    79,     0,    75,    80,     0,    81,     0,    82,     0,    83,
     0,    84,    62,    63,    64,    65,     0,     0,     6,     7
};

static const short yycheck[] = {     8,
     6,    63,     8,     9,    10,    67,    12,    63,    14,    15,
    16,    17,    64,    19,    20,    21,     0,    65,     0,     3,
     4,    27,    28,    29,    30,    53,    61,    33,    69,    14,
    36,    70,    38,    39,    40,    41,    -1,    43,    -1,    45,
    -1,    47,    -1,    49,    -1,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    60,    61,    62,    66,    67,    23,
    66,    11,    71,    72,     6,     5,     8,     9,    32,    -1,
    12,    11,    14,    15,    16,    17,    -1,    11,    -1,    -1,
    -1,    31,    32,    -1,    18,    27,    28,    29,    30,    -1,
    -1,    31,    32,    -1,    36,    59,    60,    31,    32,    41,
    -1,    43,    11,    45,    -1,    47,    11,    49,    -1,    51,
    52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
    62,    -1,    31,    32,    66,    -1,    31,    32,    11,    -1,
    13,    -1,    37,    42,    -1,    44,    -1,    46,    -1,    48,
    -1,    50,    23,    24,    25,    26,    -1,    -1,    31,    32
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/local/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 169 "/usr/local/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
#ifdef YYLSP_NEEDED
		 &yyls1, size * sizeof (*yylsp),
#endif
		 &yystacksize);

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symboles being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 37:
#line 105 "newsesh.y"
{yyval= (YYSTYPE)genere("",NULL);;
    break;}
case 38:
#line 106 "newsesh.y"
{yyval= (YYSTYPE)genere(yyvsp[-1], "\\negAROBspace", NULL);
		   free(yyvsp[-1]);;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 440 "/usr/local/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 151 "newsesh.y"

