\initial {!}
\entry {\code {!! \r {in path specifications}}}{12}
\initial {$}
\entry {\code {$}}{11}
\entry {\samp {$HOME} searching caveat}{4}
\initial {-}
\entry {\code {-L \r {option to \code {ls}}}}{12}
\entry {\code {-static}}{6}
\initial {.}
\entry {\code {.base}}{14}
\entry {\code {.bib}}{14}
\entry {\code {.bst}}{14}
\entry {\code {.cnf}}{14}
\entry {\code {.eps}}{14}
\entry {\code {.fmt}}{14}
\entry {\code {.gf}}{14}
\entry {\code {.mf}}{14}
\entry {\code {.pict}}{14}
\entry {\code {.pk}}{14}
\entry {\code {.pool}}{14}
\entry {\code {.tex}}{14}
\entry {\code {.tfm}}{14}
\entry {\code {.vf}}{14}
\initial {/}
\entry {\code {/ \r {may not be /}}}{9}
\entry {\code {//}}{11}
\initial {:}
\entry {\code {: \r {may not be :}}}{9}
\entry {\code {::}}{10}
\initial {{\tt\char'176}}
\entry {\code {{\tt\char'176}}}{11}
\entry {\samp {{\tt\char'176}} searching caveat}{4}
\initial {A}
\entry {absolute filenames}{9}
\entry {aliases for fonts}{15}
\entry {Alpha OSF/1 loader bug and \code {XtInherit}}{4}
\entry {arguments to \file {MakeTeX}\dots {}}{17}
\entry {\code {argv[0]}}{19}
\initial {B}
\entry {base dpi}{17}
\entry {basic glyph lookup}{15}
\entry {\code {BIBINPUTS}}{14}
\entry {\code {BSTINPUTS}}{14}
\entry {bug address}{6}
\entry {bugs, reporting}{6}
\initial {C}
\entry {\code {c-*.h}}{20}
\entry {calling sequence}{19}
\entry {\code {cc \r {warnings}}}{6}
\entry {\code {CFLAGS}}{2}
\entry {circle fonts}{15}
\entry {\code {client{\_}path \r {in \code {kpse{\_}format{\_}info}}}}{19}
\entry {\code {cmr10}}{17}
\entry {\code {cnf.h}}{20}
\entry {common features in glyph lookup}{15}
\entry {\code {comp.sys.sun.admin \r {FAQ}}}{5}
\entry {compilation}{2}
\entry {compilation value, source for path}{9}
\entry {conditions for use}{1}
\entry {\code {CONFIG}}{2}
\entry {config files}{10}
\entry {config files, for kpathsea-using program}{19}
\entry {config files, programming with}{20}
\entry {configuration}{2}
\entry {configuration file, source for path}{9}
\entry {configuration files as shell scripts.}{10}
\entry {\code {configure\r {, running}}}{2}
\entry {\code {cron \r {and \file {ls-R}}}}{12}
\initial {D}
\entry {database for filename searches}{12}
\entry {database search}{9}
\entry {database, format of}{13}
\entry {\code {debug.h}}{7}
\entry {debugging}{7}
\entry {debugging flags, in kpathsea-using program}{19}
\entry {default expansion}{10}
\entry {default paths, changing}{2}
\entry {default paths, how they're made}{2}
\entry {\code {default{\_}texsizes}}{17}
\entry {destination directory for \file {MakeTeXPK}}{17}
\entry {directories, changing default installation}{2}
\entry {disk search}{9}
\entry {doubled colons}{10}
\entry {\code {DVILJMAKEPK}}{16}
\entry {\code {DVILJSIZES}}{17}
\entry {\code {DVIPSFONTS}}{15}
\entry {\code {DVIPSMAKEPK}}{16}
\entry {\code {DVIPSSIZES}}{17}
\entry {dynamic linking problems with openwin libraries}{5}
\initial {E}
\entry {\code {elt-dirs.c}}{12}
\entry {environment variable, source for path}{9}
\entry {environment variables for \TeX{}}{14}
\entry {environment variables in paths}{11}
\entry {epoch}{8}
\entry {excessive startup time}{4}
\entry {\code {exec{\_}prefix\r {, changing}}}{3}
\entry {expansion of path elements}{9}
\entry {expansion, default}{10}
\entry {expansion, subdirectory}{11}
\entry {expansion, tilde}{11}
\entry {expansion, variable}{11}
\entry {explicitly relative filenames}{9}
\entry {externally-built filename database}{12}
\entry {extra colons}{10}
\initial {F}
\entry {failed \code {MakeTeX\dots {}}}{16}
\entry {fallback font}{17}
\entry {fallback resolutions}{17}
\entry {FAQ, \samp {comp.sys.sun.admin}}{5}
\entry {filename database}{12}
\entry {filenames, absolute or explicitly relative}{9}
\entry {files, unable to find}{3}
\entry {filesystem search}{9}
\entry {floating directories}{9}
\entry {\code {FOIL{\_}X{\_}WCHAR{\_}T}}{5}
\entry {font alias files}{15}
\entry {font of last resort}{17}
\entry {fontmap files}{15}
\entry {fontnames, unlimited length}{15}
\entry {format of external database}{13}
\entry {freedom, programming}{27}
\entry {fundamental purpose}{1}
\initial {G}
\entry {\code {get{\_}applicationShellWidgetClass}}{5}
\entry {\code {get{\_}wmShellWidgetClass}}{5}
\entry {\code {GFFONTS}}{14}
\entry {glyph lookup}{15}
\entry {glyph lookup bitmap tolerance}{15}
\entry {\code {GLYPHFONTS}}{14}
\entry {GNU C library}{19}
\entry {GNU General Public License}{1}
\entry {GNU Library General Public License}{1}
\initial {H}
\entry {hash table routines}{20}
\entry {\code {HIER}}{3}
\entry {home directories in paths}{11}
\initial {I}
\entry {illegal pointer combination warnings}{6}
\entry {input lines, reading}{20}
\entry {installation}{2}
\entry {installation directories, changing}{2}
\entry {installation directories, changing default}{2}
\entry {interface copyright}{28}
\entry {interface, not frozen}{1}
\entry {introduction}{1}
\initial {K}
\entry {\samp {kdebug:}}{7}
\entry {Kpathsea config file, source for path}{9}
\entry {\code {kpathsea/CONFIG}}{2}
\entry {\code {kpathsea/HIER}}{3}
\entry {\code {kpathsea{\_}debug}}{7, 19}
\entry {\code {KPATHSEA{\_}DPI}}{17}
\entry {\code {KPSE{\_}BITMAP{\_}TOLERANCE}}{15}
\entry {\code {kpse{\_}cnf{\_}get}}{20}
\entry {\code {KPSE{\_}DEBUG{\_}EXPAND}}{7}
\entry {\code {KPSE{\_}DEBUG{\_}FOPEN}}{7}
\entry {\code {KPSE{\_}DEBUG{\_}HASH}}{7}
\entry {\code {KPSE{\_}DEBUG{\_}PATHS}}{7}
\entry {\code {KPSE{\_}DEBUG{\_}SEARCH}}{7}
\entry {\code {KPSE{\_}DEBUG{\_}STAT}}{7}
\entry {\code {kpse{\_}fallback{\_}font}}{17}
\entry {\code {kpse{\_}find{\_}*}}{20}
\entry {\code {kpse{\_}find{\_}glyph{\_}format}}{15}
\entry {\code {kpse{\_}format{\_}info}}{19}
\entry {\code {kpse{\_}init{\_}prog}}{20}
\entry {\code {kpse{\_}make{\_}specs}}{16}
\entry {\code {kpse{\_}set{\_}progname}}{19}
\entry {\code {kpse{\_}var{\_}expand}}{20}
\initial {L}
\entry {last-resort font}{17}
\entry {\code {lcircle10}}{15}
\entry {leading colons}{10}
\entry {leaf directories wrongly guessed}{3}
\entry {leaf directory trick}{11}
\entry {license for using the library}{1}
\entry {lines, reading unlimited-length}{20}
\entry {log file}{8}
\entry {\code {ls-R \r {database file}}}{12}
\initial {M}
\entry {\code {mag \r {Metafont variable}}}{17}
\entry {magic characters}{9}
\entry {magstep for \file {MakeTeXPK}}{17}
\entry {\file {MakeTeX}\dots {} script names}{16}
\entry {\file {MakeTeX}\dots {} scripts}{16}
\entry {\code {MAKETEX{\_}BASE{\_}DPI}}{17}
\entry {\code {MAKETEX{\_}MAG}}{17}
\entry {\code {MAKETEX{\_}MODE}}{17, 18}
\entry {\code {MakeTeXMF}}{16}
\entry {\code {MakeTeXPK}}{16}
\entry {\code {MAKETEXPK \r {environment variable}}}{17}
\entry {\code {MakeTeXTeX}}{16}
\entry {\code {MakeTeXTFM}}{16}
\entry {memory allocation routines}{20}
\entry {Metafont mode name for \file {MakeTeXPK}}{17}
\entry {\code {MFBASES}}{14}
\entry {\code {MFINPUTS}}{14}
\entry {\code {MFPOOL}}{14}
\entry {\code {missfont.log}}{16}
\entry {\code {mode \r {Metafont variable}}}{17}
\entry {\code {mtp{\_}destdir}}{17}
\initial {N}
\entry {names for \file {MakeTeX}\dots {} scripts}{16}
\initial {O}
\entry {openwin libraries, dynamic linking problems}{5}
\entry {options for debugging}{7}
\entry {OSF/1 loader bug and \code {XtInherit}}{4}
\entry {overview of path searching}{9}
\entry {overview of programming with Kpathsea}{19}
\initial {P}
\entry {patents, software}{27}
\entry {path searching}{9}
\entry {path searching, overview}{9}
\entry {path sources}{9}
\entry {paths, changing default}{2}
\entry {paths, device name included in}{18}
\entry {\code {paths.h}}{3}
\entry {\code {pathsearch.h}}{19}
\entry {\code {PKFONTS}}{14}
\entry {pointer combination warnings}{6}
\entry {\code {prefix\r {, changing}}}{3}
\entry {\code {proginit.h}}{20}
\entry {\code {program{\_}invocation{\_}name}}{19}
\entry {\code {program{\_}invocation{\_}short{\_}name}}{19}
\entry {programming overview}{19}
\entry {programming with config files}{20}
\entry {programming with Kpathsea}{19}
\entry {programs using the library}{1}
\initial {Q}
\entry {quoting variable values}{11}
\initial {R}
\entry {reading unlimited-length lines}{20}
\entry {recording successful searches}{8}
\entry {recursion from \file {/}}{4}
\entry {relative filenames}{9}
\entry {reporting bugs}{6}
\entry {\code {resident.c}}{19}
\entry {resolutions, last-resort}{17}
\entry {rms}{28}
\entry {\samp {root} searching peculiarities}{4}
\entry {runtime configuration files}{10}
\entry {runtime debugging}{7}
\initial {S}
\entry {scripts for file creation}{16}
\entry {search path, defined}{9}
\entry {searching for glyphs}{15}
\entry {searching overview}{9}
\entry {searching the database}{9}
\entry {searching the disk}{9}
\entry {shell scripts as configuration files}{10}
\entry {shell variables}{11}
\entry {slow startup time}{4}
\entry {software patents}{27}
\entry {sources for search paths}{9}
\entry {specification for \file {MakeTeXPK}}{17}
\entry {\code {st{\_}nlink}}{12}
\entry {startup time, excessive}{4}
\entry {static linking}{6}
\entry {string routines}{20}
\entry {subdirectory searching}{11}
\entry {Sun openwin patches}{6}
\entry {symbolic links not found}{3}
\entry {symbolic links, and \file {ls-R}}{12}
\initial {T}
\entry {\code {tex-file.h}}{14, 19}
\entry {\code {tex-glyph.c}}{15}
\entry {\code {tex-glyph.h}}{19}
\entry {\code {tex-k{\tt\char'100}cs.umb.edu \r {(bug address)}}}{6}
\entry {\code {tex-make.c}}{16}
\entry {\TeX{} environment variables}{14}
\entry {\TeX{} glyph lookup}{15}
\entry {\TeX{} searching}{14}
\entry {\TeX{} Users Group}{1}
\entry {\code {TEXFONTS}}{14}
\entry {\code {texfonts.map}}{15}
\entry {\code {TEXFORMATS}}{14}
\entry {\code {TEXINPUTS}}{14}
\entry {\code {TEXMF}}{18}
\entry {\code {texmf.cnf \r {definition}}}{10}
\entry {\code {texmf.cnf\r {, and variable expansion}}}{11}
\entry {\code {texmf.cnf\r {, generated}}}{2}
\entry {\code {texmf.cnf\r {, source for path}}}{9}
\entry {\code {texmf.cnf.in}}{2}
\entry {\code {texmf.sed}}{2}
\entry {\code {TEXMFCNF}}{10, 14}
\entry {\code {TEXMFLOG}}{8}
\entry {\code {TEXMFOUTPUT}}{16}
\entry {\code {TEXPICTS}}{14}
\entry {\code {TEXPKS}}{14}
\entry {\code {TEXPOOL}}{14}
\entry {\code {TEXSIZES}}{17}
\entry {\code {TFMFONTS}}{14}
\entry {tilde expansion}{11}
\entry {\code {time}}{8}
\entry {tolerance for glyph lookup}{15}
\entry {trailing colons}{10}
\entry {trick for detecting leaf directories}{11}
\entry {\code {tug{\tt\char'100}tug.org}}{1}
\initial {U}
\entry {unable to find files}{3}
\entry {\code {UNIX{\_}ST{\_}LINK}}{12}
\entry {user interface copyright}{28}
\initial {V}
\entry {variable expansion}{11}
\entry {\code {variable.h}}{20}
\entry {\code {VFFONTS}}{14}
\initial {W}
\entry {warnings, pointer combinations}{6}
\entry {\code {wchar{\_}t}}{5}
\initial {X}
\entry {\code {XDVIFONTS}}{15}
\entry {\code {XDVIMAKEPK}}{16}
\entry {\code {XDVISIZES}}{17}
\entry {\code {Xlib.h}}{5}
\entry {\code {Xmu \r {library problems}}}{5}
\entry {\code {XtInherit \r {bug on OSF/1}}}{4}
