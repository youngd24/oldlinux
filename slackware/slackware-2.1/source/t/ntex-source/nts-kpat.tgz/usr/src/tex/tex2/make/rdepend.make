# rdepend.make -- rules for remaking the depdencies.

# Have to use -M, not -MM, since we use <kpathsea/...> instead of
# "kpathsea/..." in the sources.  But that means we have to remove the
# directory prefixes and all the system include files.
depend depend.make:: c-auto.h
	$(CC) -M $(CPPFLAGS) *.c \
	  | sed -e 's,\.\./kpathsea/,$$(kpathsea_dir)/,g' \
	        -e 's,/usr[^ ]* ,,g' \
	        -e 's,dvi2xx.o,dvilj.o dvilj2p.o dvilj4.o dvilj4l.o,' \
	  | grep -v '^ *\\$$' \
	  >depend.make
