/* c-dir.h: directory headers.

Copyright (C) 1992, 93, 94 Free Software Foundation, Inc.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#ifndef KPATHSEA_C_DIR_H
#define KPATHSEA_C_DIR_H

/* Use struct dirent instead of struct direct.  */
#ifdef DIRENT
#include <dirent.h>
#define NLENGTH(dirent) strlen ((dirent)->d_name)
#else /* not DIRENT */
#define dirent direct
#define NLENGTH(dirent) ((dirent)->d_namlen)

#ifdef SYSNDIR
#include <sys/ndir.h>
#endif

#ifdef NDIR
#include <ndir.h>
#endif

#ifdef SYSDIR
#include <sys/dir.h>
#endif

#endif /* not DIRENT */

#endif /* not KPATHSEA_C_DIR_H */
