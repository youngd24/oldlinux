# programs.make -- used by Makefiles for executables only.

# Linking. Don't include $(CFLAGS), since ld -g under Linux forces
# static libraries, including libc.a and libX*.a
LDFLAGS = $(XLDFLAGS)
LIBS = @LIBS@
LOADLIBES = $(kpathsea) $(x_libs) $(LIBS) -lm $(XLOADLIBES)
