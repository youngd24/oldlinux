directory /w/dvipsk:/w/kpathsea

define redo
symbol-file dvips
exec-file dvips
end

define aredo
symbol-file afm2tfm
exec-file afm2tfm
end

#set env TEXCONFIG /tmp
#set env PKFONTS /envvar/pk:
#set env TEXFONTS /envvar/tex:
#set env DVIPSHEADERS /envvar/headers:
#set env TEXCONFIG /usr/local/lib/tex/dvips
#unset env TEXINPUTS
#set env TEXFONTS $cm/tfm

#set env TEXFONTS .:/w/norm/deep1/mac.archive.um//:/w/norm/deep2/fonts//
#set args -M /w/norm/deep1/mac.archive.um/testfonts.dvi

set env DVIPSSIZES ""
set args /w/dvitest/maketex -M -o /dev/null

#set args -d 2048 /w/dvitest/story -o /dev/null
#set args /w/dvitest/story -o /dev/null
#set args /w/dvitest/accenttest -o /dev/null
#set args table -o /dev/null
#set args -M1 -D 300 /w/dvitest/magstep -o /dev/null
