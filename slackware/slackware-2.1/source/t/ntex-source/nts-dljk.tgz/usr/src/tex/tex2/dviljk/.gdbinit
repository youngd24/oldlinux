directory /w/kpathsea:/w/dviljk

define redo
file dvilj4
end

#set env TFMFONTS $tdvi/test/fonts//tfm
#set env PKFONTS $tdvi/test/fonts//pk
#set args --255 $tdvi/test/story
#set args --24 $tdvi/test/story
#set args -M0 $tdvi/test/maketex
#set args -- unr8 >unr8.lj 
#set args table >table.lj
#set args hwir >hwir.lj
set env TEXFONTS $cm/tfm
set args -M1 $tdvi/test/magstep -e/dev/null
