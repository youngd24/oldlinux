#ifndef _FC_10_H
#define _FC_10_H

/*
 * Copyright (C) 1994 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 $Source: /usr/src/distr/ftape-1.13a/RCS/fc-10.h,v $
 $Author: bas $
 *
 $Revision: 1.1 $
 $Date: 1994/06/26 14:10:38 $
 $State: Beta $
 *
 *      This file contains definitions for the FC-10 code
 *      of the QIC-40/80 floppy-tape driver for Linux.
 */

/*
 *      fc-10.c defined global vars.
 */

/*
 *      fc-10.c defined global functions.
 */
extern int fc10_enable( void);

#endif
