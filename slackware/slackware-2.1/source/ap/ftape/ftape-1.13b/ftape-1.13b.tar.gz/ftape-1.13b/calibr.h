#ifndef _CALIBRATE_H
#define _CALIBRATE_H

/*
 *      Copyright (C) 1993,1994 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 $Source: /usr/src/distr/ftape-1.13/RCS/calibr.h,v $
 $Author: bas $
 *
 $Revision: 1.14 $
 $Date: 1994/06/12 16:07:53 $
 $State: Beta $
 *
 *      This file contains a gp calibration routine for
 *      hardware dependent timeout functions.
 */

#include <linux/timex.h>

extern int calibrate( char* name, void(*fun)(int), int* calibr_count, int* calibr_time);
extern void do_gettimeofday( struct timeval *tv);
extern int timestamp( void);

#endif



