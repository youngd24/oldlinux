#include <stdio.h>
#include <unistd.h>

typedef struct seq_entry {
    char              value;	/* Character value */
    struct seq_entry  *sibling;	/* The sibling */
    struct seq_entry  *child;	/* Childs */
} seq_entry;

seq_entry *head;

int xgetch ()
{
    
}


void define_key_sequence (seq_entry **base, int value, char *sequence)
{
    seq_entry *this = malloc (sizeof (seq_entry));
}

main ()
{
    int c;
    
    define_key_sequence (1, "\eOp");
    define_key_sequence (2, "\eOn");
    while (1){
	c = xgetch ();
	printf ("Devuelve: %d\n", c);
    }
}
