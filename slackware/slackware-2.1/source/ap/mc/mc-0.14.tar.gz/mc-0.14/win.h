void wclr (WINDOW *w);
void define_label (WINDOW *fkeys, int index, char *text, void (*)());
void define_label_quit (WINDOW *fkeys, int index, char *text, int (*cback)());
WINDOW *new_fkey ();
