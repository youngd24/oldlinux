/* Use this file only under System V */
#ifndef __svr4__
#error The ncurses.h file should only be included under SystemV
#error BSD systems and Linux require the ncurses package
#endif
#include <curses.h>
