void toggle_clean_exec ();
void toggle_show_backup ();
void toggle_show_hidden ();
void toggle_verbose ();
void toggle_mark_move_down ();
void toggle_pause_after_run ();
void toggle_show_mini_status ();
void toggle_easy_patterns ();
void toggle_align_extensions ();
void toggle_auto_save ();
void toggle_auto_menu ();
void toggle_internal ();
void toggle_mix_all_files ();
void toggle_fast_reload ();
void toggle_confirm_delete ();

void do_mark_file (int do_move);

#define RP_CLEAR 1
#define RP_NOCLEAR 0

#define UP_OPTIMIZE 0
#define UP_RELOAD   1

#define UP_KEEPSEL (char *) -1
extern int quote;
extern int quit;
void execute (char *command);

void untouch_bar ();
void touch_bar ();

/* See main.c for details on this variables */
extern int mark_moves_down;
extern int auto_menu;
extern int pause_after_run;
extern int auto_save_setup;
extern int use_internal_view;
extern int fast_reload_w;
extern int clear_before_exec;
extern int confirm_delete;
extern int mou_auto_repeat;
extern char *other_dir;

/* Usefull macros to avoid too much typing */
#define cpanel current_panel
#define opanel other_panel

typedef struct {
    int   key_code;
    void  (*fn)(int);
} key_map;
