void wclrn (WINDOW *w, int i);
void define_label (WINDOW *fkeys, int index, char *text, void (*)());
void set_label_text (WINDOW *fkeys, int index, char *text);
void define_label_quit (WINDOW *fkeys, int index, char *text, int (*cback)());
int check_fkeys (int c);
WINDOW *push_fkey ();
void pop_fkey (WINDOW *w);
typedef void (*movefn)(int);
int check_movement_keys (int c, int additional, int page_size,
			 movefn backfn, movefn forfn, movefn topfn, movefn bottomfn);

#define wclr(w) wclrn(w, 0)
