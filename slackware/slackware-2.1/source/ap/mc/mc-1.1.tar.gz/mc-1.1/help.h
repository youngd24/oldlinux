/* This file is included by help.c and man2hlp.c */

/* Some usefull constants */
#define CHAR_NODE_END		'\04'
#define CHAR_LINK_START		'\01'
#define CHAR_LINK_POINTER	'\02'
#define CHAR_LINK_END		'\03'
#define STRING_LINK_START	"\01"
#define STRING_LINK_POINTER	"\02"
#define STRING_LINK_END		"\03"

