void *gc_alloc (int size);
void *gc_use (void *);
void garbage_collect ();
void gc_free (void *p);
