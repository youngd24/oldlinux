/* Prototypes for the profile management functions */

short GetPrivateProfileString (char * AppName, char * KeyName,
			       char * Default, char * ReturnedString,
			       short Size, char * FileName);

int GetProfileString (char * AppName, char * KeyName, char * Default, 
		      char * ReturnedString, int Size);

int GetPrivateProfileInt (char * AppName, char * KeyName, short Default,
			   char * File);

int GetProfileInt (char * AppName, char * KeyName, int Default);

int WritePrivateProfileString (char * AppName, char * KeyName, char * String,
				char * FileName);

int WriteProfileString (char * AppName, char * KeyName, char * String);

void sync_profiles ();
