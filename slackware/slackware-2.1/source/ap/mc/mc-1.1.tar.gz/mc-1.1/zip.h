long int is_gunzipable (int fd);
