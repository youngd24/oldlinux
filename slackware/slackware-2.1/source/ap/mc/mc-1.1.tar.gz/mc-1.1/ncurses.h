/* Use this file only under System V */
#if defined(__svr4__) || defined (_SYSTYPE_SVR4)
    #include <curses.h>
    #include <term.h>
    /* Ugly hack to avoid name space pollution */
    #undef cols
    #undef lines
    #undef buttons
    #define TERM_INCLUDED 1
    #if defined(sparc) || defined(__sgi) || defined(_SGI_SOURCE)
        /* We are dealing with Solaris or SGI buggy curses :-) */
        #define BUGGY_CURSES 1
    #endif

    #if defined(mips) && defined(sgi)
        /* GNU C compiler, buggy sgi */
        #define BUGGY_CURSES 1
    #endif
				 
#else
    #error The ncurses.h file should only be included under SystemV.
    #error BSD systems and Linux require the ncurses package
#endif

