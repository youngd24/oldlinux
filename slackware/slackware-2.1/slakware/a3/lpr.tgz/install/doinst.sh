( cd usr/bin ; rm -rf lpc )
( cd usr/bin ; ln -sf  /usr/sbin/lpc lpc )
