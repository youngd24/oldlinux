( cd usr/lib/jed ; rm -rf info )
( cd usr/lib/jed ; ln -sf  /usr/info info )
