#!/bin/sh
./make-cyr
./make-latex-mf
cd src
for i in $(cat fonts)
do
../../../../tools/make1mffont $i 0
done

