( chmod 751 root )
if [ ! -r etc/passwd ]; then
 mv etc/npasswd etc/passwd
else
 rm etc/npasswd
fi
if [ ! -r etc/group ]; then
 mv etc/ngroup etc/group
else
 rm etc/ngroup
fi
( cd etc/lilo ; rm -rf install )
( cd etc/lilo ; ln -sf  /sbin/lilo install )
( cd etc ; rm -rf inet )
( cd etc ; ln -sf  . inet )
( cd etc ; rm -rf wtmp )
( cd etc ; ln -sf  /var/adm/wtmp wtmp )
( cd usr ; rm -rf Info )
( cd usr ; ln -sf  info Info )
( cd usr/etc ; rm -rf printcap )
( cd usr/etc ; ln -sf  /etc/printcap printcap )
( cd root ; rm -rf linux )
( cd root ; ln -sf  /usr/src/linux linux )
( cd root ; rm -rf INSTALL )
( cd root ; ln -sf  /var/adm INSTALL )
( cd etc ; rm -rf utmp )
( cd etc ; ln -sf /var/adm/utmp utmp )
