if ($?prompt) then
	umask 022
	set cdpath = ( /usr/spool )
	set notify
	set history = 100
	setenv OPENWINHOME /usr/openwin
        setenv MANPATH /usr/local/man:/usr/man/preformat:/usr/man:/usr/X11/man:/usr/openwin/man
	setenv MINICOM "-c on"
	setenv HOSTNAME "`cat /etc/HOSTNAME`"
	set path = ( $path /usr/X11/bin /usr/andrew/bin $OPENWINHOME/bin /usr/games . )
endif
# I had problems with the backspace key installed by 'tset', but you might want
# to try it anyway, instead to the 'setenv term.....' below it.
# eval `tset -sQ "$term"`
# setenv term  console
if ! $?TERM setenv TERM console
set prompt = "%m:%~%# "
alias ls 'ls -F'
