( cd usr/src/linux-1.1.59/include ; rm -rf asm )
( cd usr/src/linux-1.1.59/include ; ln -sf asm-i386 asm )
( cd usr/src ; rm -rf linux )
( cd usr/src ; ln -sf linux-1.1.59 linux )
