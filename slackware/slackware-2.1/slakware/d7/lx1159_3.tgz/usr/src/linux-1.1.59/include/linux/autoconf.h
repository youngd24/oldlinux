/*
 * Automatically generated C config: don't edit
 */

/*
 * General setup
 */
#undef  CONFIG_MATH_EMULATION
#define CONFIG_BLK_DEV_HD 1
#undef  CONFIG_BLK_DEV_XD
#define CONFIG_NET 1
#undef  CONFIG_MAX_16M
#define CONFIG_SYSVIPC 1
#define CONFIG_M486 1
#define CONFIG_BINFMT_ELF 1
#undef  ALPHA_SLACK

/*
 * Networking options
 */
#define CONFIG_INET 1
#undef  CONFIG_IP_FORWARD

/*
 * (it is safe to leave these untouched)
 */
#undef  CONFIG_INET_PCTCP
#undef  CONFIG_INET_RARP
#define CONFIG_INET_SNARL 1
#undef  CONFIG_TCP_NAGLE_OFF
#undef  CONFIG_IPX

/*
 * SCSI support
 */
#define CONFIG_SCSI 1

/*
 * SCSI support type (disk, tape, CDrom)
 */
#define CONFIG_BLK_DEV_SD 1
#define CONFIG_CHR_DEV_ST 1
#undef  CONFIG_BLK_DEV_SR
#undef  CONFIG_CHR_DEV_SG

/*
 * SCSI low-level drivers
 */
#undef  CONFIG_SCSI_AHA152X
#undef  CONFIG_SCSI_AHA1542
#undef  CONFIG_SCSI_AHA1740
#undef  CONFIG_SCSI_BUSLOGIC
#define CONFIG_SCSI_FUTURE_DOMAIN 1
#undef  CONFIG_SCSI_GENERIC_NCR5380
#undef  CONFIG_SCSI_NCR53C7xx
#undef  CONFIG_SCSI_PAS16
#undef  CONFIG_SCSI_SEAGATE
#undef  CONFIG_SCSI_T128
#undef  CONFIG_SCSI_ULTRASTOR
#undef  CONFIG_SCSI_7000FASST

/*
 * Network device support
 */
#define CONFIG_NETDEVICES 1
#undef  CONFIG_DUMMY
#define CONFIG_SLIP 1
#define SL_COMPRESSED 1
#define CONFIG_PPP 1
#undef  CONFIG_PLIP
#undef  CONFIG_SLAVE_BALANCING
#undef  CONFIG_NET_ALPHA
#define CONFIG_NET_VENDOR_SMC 1
#define CONFIG_WD80x3 1
#undef  CONFIG_ULTRA
#undef  CONFIG_NET_VENDOR_3COM
#undef  CONFIG_NET_ISA
#undef  CONFIG_NET_EISA
#undef  CONFIG_APRICOT
#undef  CONFIG_NET_POCKET

/*
 * CD-ROM drivers
 */
#undef  CONFIG_CDU31A
#define CONFIG_MCD 1
#undef  CONFIG_SBPCD

/*
 * Filesystems
 */
#define CONFIG_MINIX_FS 1
#undef  CONFIG_EXT_FS
#define CONFIG_EXT2_FS 1
#define CONFIG_XIA_FS 1
#define CONFIG_MSDOS_FS 1
#define CONFIG_UMSDOS_FS 1
#define CONFIG_PROC_FS 1
#define CONFIG_NFS_FS 1
#define CONFIG_ISO9660_FS 1
#define CONFIG_HPFS_FS 1
#undef  CONFIG_SYSV_FS

/*
 * character devices
 */
#define CONFIG_PRINTER 1
#undef  CONFIG_BUSMOUSE
#undef  CONFIG_PSMOUSE
#undef  CONFIG_MS_BUSMOUSE
#undef  CONFIG_ATIXL_BUSMOUSE
#define CONFIG_SELECTION 1
#undef  CONFIG_QIC02_TAPE
#undef  CONFIG_FTAPE

/*
 * Sound
 */
#define CONFIG_SOUND 1

/*
 * Kernel hacking
 */
#undef  CONFIG_PROFILE
#undef  CONFIG_SCSI_CONSTANTS
