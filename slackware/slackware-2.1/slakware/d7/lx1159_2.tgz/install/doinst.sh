( cd usr/src ; rm -rf linux )
( cd usr/src ; ln -sf linux-1.1.59 linux )
