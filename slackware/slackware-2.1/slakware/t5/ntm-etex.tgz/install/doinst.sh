( cd usr/bin ; rm -rf etex )
( cd usr/bin ; ln -sf virtex etex )
