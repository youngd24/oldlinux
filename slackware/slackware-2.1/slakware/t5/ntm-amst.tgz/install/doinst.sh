( cd usr/bin ; rm -rf amstex )
( cd usr/bin ; ln -sf virtex amstex )
