if fgrep fortune etc/profile ; then
	BOGUS_FLAG="bogus_value"
else
	echo "echo" >> etc/profile
	echo "fortune" >> etc/profile
	echo "echo" >> etc/profile
fi
if [ -r etc/csh.login ]; then 
	if fgrep fortune etc/csh.login ; then
		BOGUS_FLAG="bogus_value"
	else
		echo 'if ( { tty --silent } ) then >& /dev/null' >> etc/csh.login
		echo '  echo "";fortune;echo ""' >> etc/csh.login
		echo 'endif' >> etc/csh.login
	fi
fi
( cd usr/man/preformat/cat6 ; ln -sf  bcd.6.gz ppt.6.gz )
( cd usr/man/preformat/cat6 ; ln -sf  factor.6.gz primes.6.gz )
