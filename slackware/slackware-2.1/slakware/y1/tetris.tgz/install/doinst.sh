( cd usr/games ; ln -sf  tt tetris )
( cd usr/games ; ln -sf  /var/games/tetrislib tetrislib )
