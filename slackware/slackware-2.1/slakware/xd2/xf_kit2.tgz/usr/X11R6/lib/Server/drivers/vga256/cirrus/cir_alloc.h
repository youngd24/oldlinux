/* $XFree86: xc/programs/Xserver/hw/xfree86/vga256/drivers/cirrus/cir_alloc.h,v 3.1 1994/08/20 08:48:30 dawes Exp $ */

/*
 * Definitions for video memory allocator in cir_alloc.c.
 */

#include <X11/Xfuncproto.h>

_XFUNCPROTOBEGIN

#if NeedFunctionPrototypes

void CirrusInitializeAllocator(int base);
int CirrusAllocate(int size);
void CirrusFree(int vidaddr);
void CirrusUploadPattern(unsigned char *pattern, int w, int h, int vidaddr,
	int srcpitch);

#else

void CirrusInitializeAllocator();
void CirrusAllocate();
void CirrusFree();
void CirrusUploadPattern();

#endif

_XFUNCPROTOEND
