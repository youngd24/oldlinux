( cd usr/lib ; rm -f libgcc.a )
( cd usr/lib ; rm -f libgcc.sa )
