#include <stdio.h>

main(int argc, char **argv)
{
int i;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s [123]\n", argv[0]);
		exit(0);
	}
	switch(argv[1][0]) {
	case '1':
		break;
	case '2':
		printf("\033(B\033)0\016");
		break;
	case '3':
		printf("\033(B\033)U\016");
		break;
	default:
		fprintf(stderr, "illegal option. try 1, 2, or 3!");
		exit(1);
	}
	for ( i = 1; i < 255; i++) {
		if (i == 033 || i == 012 || i == 016 || i == 016)
			continue;
		else
			printf("%-3x = %c  ", i, i);
	}
	switch(argv[1][0]) {
	case '1':
		break;
	case '2':
		printf("\033(B\033)B\017");
		break;
	case '3':
		printf("\033(B\033)B\017");
		break;
	}
}

