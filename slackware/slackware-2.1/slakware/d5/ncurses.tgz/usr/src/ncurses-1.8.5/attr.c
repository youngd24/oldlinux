
#include <ncurses.h>
void main()
{
	initscr();
	meta(stdscr, TRUE);
	attron(A_STANDOUT);
	mvaddstr(2,8,"this is STANDOUT mode");
	attroff(A_STANDOUT);
	attron(A_REVERSE);
	mvaddstr(4,8,"this is REVERSE mode");
	attroff(A_REVERSE);
	attron(A_BOLD);
	mvaddstr(6,8,"this is BOLD mode");
	attroff(A_BOLD);
	attron(A_UNDERLINE);
	mvaddstr(8,8,"this is UNDERLINE mode");
	attroff(A_UNDERLINE);
	attron(A_DIM);
	mvaddstr(10,8,"this is DIM mode");
	attroff(A_DIM);
	mvaddstr(12,8,"this is NORMAL mode");
	attron(A_BLINK);
	mvaddstr(14,8,"this is BLINK mode");
	attroff(A_BLINK);
	attron(A_BOLD|A_BLINK|A_UNDERLINE);
	mvaddstr(16,8,"this is BOLD UNDERLINE BLINK mode");
	attrset(A_NORMAL);
	mvaddstr(18,8,"this is NORMAL mode");
	refresh();
	getch();
	endwin();
}

