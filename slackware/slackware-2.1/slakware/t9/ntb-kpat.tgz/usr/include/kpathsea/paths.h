/* paths.h: Generated from paths.h.in (Wed Jul 27 15:45:28  1994).  */
/* paths.h.in: fallback paths for TeX file searching.  Kpathsea doesn't
   provide format-specific routines for all these, but it still
   seems best to centralize the definitions.
   
   The meanings of all these paths are described in the various
   programs' documentation.  Various environment variables override these.

   By the way, // means to search subdirectories (recursively). A
   leading %% means to look only in the ls-R db, not on the disk. See the
   Kpathsea manual for full details.
   
   See kpathsea/INSTALL for a description of how the various
   path-related files are used and created, and how to change the
   default paths.  */

/* TeX and MF inputs, and the default for eps figures.  */
#ifndef DEFAULT_TEX_PATH
#define DEFAULT_TEX_PATH ".:/usr/lib/texmf/tex//"
#endif
#ifndef DEFAULT_MF_PATH
/* It's pointless to search the adobe, bitstream, etc. directories for
   Metafont sources, but we want at least ams/ and public/, and who
   knows if there might be others.  */
#define DEFAULT_MF_PATH ".:/usr/lib/texmf/mf//:/usr/lib/texmf/fonts//src//"
#endif

/* Dumped formats.  */
#ifndef DEFAULT_FMT_PATH
#define DEFAULT_FMT_PATH ".:/usr/lib/texmf/ini"
#endif
#ifndef DEFAULT_BASE_PATH
#define DEFAULT_BASE_PATH ".:/usr/lib/texmf/ini"
#endif

/* INI* string pool files.  */
#ifndef DEFAULT_TEXPOOL_PATH
#define DEFAULT_TEXPOOL_PATH "/usr/lib/texmf/ini"
#endif
#ifndef DEFAULT_MFPOOL_PATH
#define DEFAULT_MFPOOL_PATH "/usr/lib/texmf/ini"
#endif

#ifndef DEFAULT_TFM_PATH /* TeX font metric files.  */
#define DEFAULT_TFM_PATH ".:/usr/lib/texmf/fonts//tfm"
#endif

#ifndef DEFAULT_VF_PATH /* Virtual font metrics.  */
#define DEFAULT_VF_PATH ".:/usr/lib/texmf/fonts//vf"
#endif

/* The TeX bitmap formats.  */
#ifndef DEFAULT_GLYPH_PATH /* This is for texfonts.map. */
#define DEFAULT_GLYPH_PATH ".:/usr/lib/texmf/fonts//"
#endif
#ifndef DEFAULT_GF_PATH
#define DEFAULT_GF_PATH ".:/usr/lib/texmf/fonts//gf"
#endif
#ifndef DEFAULT_PK_PATH
#define DEFAULT_PK_PATH ".:/usr/lib/texmf/fonts//pk//"
#endif

/* BibTeX bibliographies and styles.  */
#ifndef DEFAULT_BIB_PATH
#define DEFAULT_BIB_PATH ".:/usr/lib/texmf/bibtex/bib"
#endif
#ifndef DEFAULT_BST_PATH
#define DEFAULT_BST_PATH ".:/usr/lib/texmf/bibtex/bst"
#endif

/* Dvips' configuration files.  */
#ifndef DEFAULT_CONFIG_PATH
#define DEFAULT_CONFIG_PATH ".:~:/usr/lib/texmf/dvips"
#endif

/* Dvips' PostScript prologues, and downloadable fonts (.pf[ab] files).  */
#ifndef DEFAULT_HEADER_PATH
#define DEFAULT_HEADER_PATH ".:/usr/lib/texmf/dvips:/usr/lib/texmf/fonts//type1"
#endif

/* Dvips' and xdvi's epsf and ps figures.  It is probably a mistake to
   make this more restrictive than the DEFAULT_TEX_PATH, because TeX
   needs to be able to read the .eps files also. */
#ifndef DEFAULT_FIG_PATH
#define DEFAULT_FIG_PATH DEFAULT_TEX_PATH
#endif

/* Dvips' TIFF files, etc.  */
#ifndef DEFAULT_PICT_PATH
#define DEFAULT_PICT_PATH DEFAULT_FIG_PATH
#endif
