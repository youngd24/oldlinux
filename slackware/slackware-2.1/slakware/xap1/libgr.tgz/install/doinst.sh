crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.?.*
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
( cd usr/lib ; ln -sf  libgr.so.1.3 libgr.so.1 )
#echo "Compacting shared libraries to decrease disk space utilization..."
crunch usr/lib libgr;
#echo "Shared libraries compacted."
