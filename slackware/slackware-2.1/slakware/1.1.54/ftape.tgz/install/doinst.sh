( cd boot ; rm -rf ftape.o )
( cd boot ; ln -sf ftape.o-1.13b-patched ftape.o )
