( cd usr/bin ; rm -rf tex )
( cd usr/bin ; ln -sf virtex tex )
