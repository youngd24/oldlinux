                       LaTeX Distribution Guide
                      
                            11 June 1994


WELCOME TO LaTeX!

This file contains a brief distribution guide for the new standard
version of the LaTeX document preparation system.

This system is maintained by The LaTeX3 Project Team.


The LaTeX system is described in:

 * LaTeX: A Document Preparation System; Leslie Lamport, Addison-Wesley

 * The LaTeX Companion, Goossens; Mittelbach and Samarin, Addison-Wesley


This distribution is described in the files ending with .txt.  You
should read install.txt before starting to install LaTeX.


 * 00readme.txt is this file.

 * install.txt describes how to install LaTeX.

 * manifest.txt lists all the files in the LaTeX distribution.

 * unpacked.txt lists all the files in the unpacked LaTeX distribution.

 * legal.txt describes the LaTeX copyright, warranty and copying
   restrictions.

 * bugs.txt describes how to submit a bug report for LaTeX.

 * patches.txt describes the update policy and how important changes
   will be distributed between release dates.


 Other documentation files include files with names of the form:

   <xxx>guide.tex  you will probably need to update your system
   before you can typeset these files.  Each file needs three 
   LaTeX runs.

 * manual.err lists errata in:
   LaTeX: A Document Preparation System; Leslie Lamport, Addison-Wesley

 * compan.err lists errata in:
   The LaTeX Companion, Goossens; Mittelbach and Samarin, Addison-Wesley


You are not allowed to change the files in this distribution, *except*
for the configuration files, ending with .cfg.  These are described in
install.txt.


Please do not request updates from us.  Distribution is done only
through mail servers and TeX organisations.


--- Copyright 1994 the LaTeX3 project.  All rights reserved ---
