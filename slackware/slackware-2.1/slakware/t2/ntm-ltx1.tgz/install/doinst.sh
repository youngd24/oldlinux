( cd usr/bin ; rm -rf latex )
( cd usr/bin ; ln -sf virtex latex )
