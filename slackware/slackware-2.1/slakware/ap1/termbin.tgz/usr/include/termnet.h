/* Replace normal networking commands */

#define accept          term_accept
#define bind            term_bind
#define chroot          term_chroot
#define close           term_close
#define connect         term_connect
#define dup             term_dup
#define dup2            term_dup2
#define fcntl           term_fcntl
#define fork            term_fork
#define gethostbyname   term_gethostbyname
#define gethostbyaddr   term_gethostbyaddr
#define gethostname     term_gethostname
#define getpeername     term_getpeername
#define getsockname     term_getsockname
#define listen          term_listen
#define perror  	term_perror
#define rcmd            term_rcmd
#define recv            term_recv
#define recvfrom        term_recvfrom
#define send            term_send
#define sendto          term_sendto
#define shutdown        term_shutdown
#define socket          term_socket
#define strerror	term_strerror
#define vfork           term_vfork

