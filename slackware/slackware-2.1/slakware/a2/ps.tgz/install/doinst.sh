( cd usr/bin ; rm -rf w )
( cd usr/bin ; ln -sf w.procps w )
