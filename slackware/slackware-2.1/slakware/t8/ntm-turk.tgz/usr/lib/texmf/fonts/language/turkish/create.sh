#! /bin/sh
cd src
for i in 0 1 2 4
do
../../../../tools/make1cmfont wtkr10 $i
../../../../tools/make1cmfont wtkti10 $i
done
cd ..
