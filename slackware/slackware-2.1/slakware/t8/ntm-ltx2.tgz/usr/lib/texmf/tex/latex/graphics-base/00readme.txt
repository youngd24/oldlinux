The LaTeX2e Colour and Graphics Packages
========================================

This is a pre-release of LaTeX2e packages for:
 * producing colour
 * including graphics (eg PostScript) files 
 * rotation and scaling of text
in LaTeX2e documents.


This is still a test release.

* The documentation is far from being complete.
* The interfaces are *not* finalised, and so the format of internal
  commands, and names of options, may change in future releases.
* In particular, the format of the `driver dependant files' which
  implement the low level commands required to access the syntax of
  each individual driver (dvips, emtex, oztex, etc) is *very* likely
  to change. If you have a driver which is not currently supported, it
  may be best to send us a description of the \special syntax so we
  can produce the required file, rather than trying to produce one
  yourself.

1994/05/30

David Carlisle   carlisle@cs.man.ac.uk
Sebastian Rahtz  spqr@ftp.tex.ac.uk


THIS DIRECTORY CONTAINS
======================
======================

README          This File
ChangeLog       Log of changes to the packages.
graphics.ins    Install file for docstrip.

Standard packages
=================
color.dtx       Source for color package
graphics.dtx    Source for graphics package
trig.dtx        Source for trig package (required by graphics)

Non Standard Packages
=====================
graphicx.dtx    Source for graphicx package (extension of graphics)
epsfig.dtx      Source for epsfig package (extension of graphicx)
keyval.dtx      Source for keyval pacakge (required by both the above)

Driver Files
============
refcol.dtx      Source for reference colour driver files
drivers.dtx     Source for driver files for supported drivers.

TeX files
=========

thoughts.tex    Some uncoordinated thoughts about colours in TeX.
testcol.tex     A small colour test file, it will stop and ask you which
                  option you want.
test.tex        Test file for graphics package
testx.tex       Test file for graphicx package


PostScript files
================
a.ps            Example used in test.tex and testx.tex
b.xyz           Example used in testx.tex

=============================================

TO UNPACK THE PACKAGES
======================

latex graphics.ins

This will produce the 

.sty package files
.col reference color files
.def driver files.

=============================================

USING THE PACKAGES
==================

Move files ending in .sty .def .col to a standard TeX input directory.
You may then LaTeX the example .tex files eg
  latex test.tex
Also the documented sources (dtx files) may be processed with LaTeX, eg
  latex color.dtx
==============================================

