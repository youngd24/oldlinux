include(`../m4/cf.m4')
Cwlocalhost
VERSIONID(`linux for smtp-only setup')dnl
OSTYPE(linux)
FEATURE(nodns)dnl
FEATURE(nouucp)dnl
FEATURE(always_add_domain)dnl
MAILER(local)dnl
MAILER(smtp)dnl
