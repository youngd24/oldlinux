( cd usr/lib ; rm -rf deliver )
( cd usr/lib ; ln -sf  /var/deliver deliver )
