( cd sbin ; rm -rf dip )
( cd sbin ; ln -sf dip-3.3.7i dip )
( cd sbin ; rm -rf diplogin )
( cd sbin ; ln -sf dip-3.3.7i diplogin )
