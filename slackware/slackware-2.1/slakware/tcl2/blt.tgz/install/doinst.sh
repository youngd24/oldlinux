crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.?.*.*
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
#echo "Compacting BLT shared library to decrease disk space utilization..."
crunch usr/lib libBLT;
#echo "BLT shared library compacted."
( cd usr/lib ; rm -rf libBLT.so.3 )
( cd usr/lib ; ln -sf libBLT.so.3.5.0 libBLT.so.3 )
