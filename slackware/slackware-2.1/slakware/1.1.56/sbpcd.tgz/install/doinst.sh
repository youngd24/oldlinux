# echo "Configuring the kernel to mount the root partition read-write..."
# I'm doing this because you should be able to use LILO or Loadlin to 
# control things like this.  Having the -R flag as 1 is just a newbie
# accident waiting to happen, IMHO. :^)
rdev -R vmlinuz 0
rdev -v vmlinuz -1
rdev -r vmlinuz 0
if [ -r zImage ]; then
# echo "Moving your old kernel into /tmp..."
 mv zImage tmp
fi
