/*
 * Automatically generated C config: don't edit
 */

/*
 * General setup
 */
#define CONFIG_MATH_EMULATION 1
#define CONFIG_BLK_DEV_HD 1
#undef  CONFIG_BLK_DEV_XD
#define CONFIG_NET 1
#undef  CONFIG_QUOTA
#undef  CONFIG_MAX_16M
#define CONFIG_SYSVIPC 1
#define CONFIG_M486 1
#define CONFIG_BINFMT_ELF 1
#define ALPHA_SLACK 1

/*
 * Networking options
 */
#define CONFIG_INET 1
#undef  CONFIG_IP_FORWARD

/*
 * (it is safe to leave these untouched)
 */
#undef  CONFIG_INET_PCTCP
#undef  CONFIG_INET_RARP
#define CONFIG_INET_SNARL 1
#undef  CONFIG_TCP_NAGLE_OFF
#undef  CONFIG_IPX

/*
 * SCSI support
 */
#define CONFIG_SCSI 1

/*
 * SCSI support type (disk, tape, CDrom)
 */
#define CONFIG_BLK_DEV_SD 1
#define CONFIG_CHR_DEV_ST 1
#define CONFIG_BLK_DEV_SR 1
#undef  CONFIG_CHR_DEV_SG

/*
 * SCSI low-level drivers
 */
#define CONFIG_SCSI_AHA152X 1
#define CONFIG_SCSI_AHA1542 1
#define CONFIG_SCSI_AHA1740 1
#define CONFIG_SCSI_AHA274X 1
#undef  CONFIG_SCSI_IN2000
#undef  CONFIG_SCSI_EATA
#define CONFIG_SCSI_BUSLOGIC 1
#define CONFIG_SCSI_FUTURE_DOMAIN 1
#define CONFIG_SCSI_GENERIC_NCR5380 1
#define CONFIG_SCSI_NCR53C7xx 1
#define CONFIG_SCSI_PAS16 1
#define CONFIG_SCSI_SEAGATE 1
#define CONFIG_SCSI_T128 1
#define CONFIG_SCSI_ULTRASTOR 1
#define CONFIG_SCSI_7000FASST 1

/*
 * Network device support
 */
#define CONFIG_NETDEVICES 1
#undef  CONFIG_DUMMY
#define CONFIG_SLIP 1
#define SL_COMPRESSED 1
#define CONFIG_PPP 1
#undef  CONFIG_PLIP
#undef  CONFIG_SLAVE_BALANCING
#define CONFIG_NET_ALPHA 1
#define CONFIG_NET_VENDOR_SMC 1
#define CONFIG_WD80x3 1
#define CONFIG_ULTRA 1
#define CONFIG_NET_VENDOR_3COM 1
#define CONFIG_EL1 1
#define CONFIG_EL2 1
#define CONFIG_ELPLUS 1
#define CONFIG_EL16 1
#define CONFIG_EL3 1
#define CONFIG_NET_ISA 1
#define CONFIG_LANCE 1
#define CONFIG_E2100 1
#define CONFIG_DEPCA 1
#define CONFIG_EEXPRESS 1
#define CONFIG_AT1700 1
#define CONFIG_NI52 1
#define CONFIG_NI65 1
#define CONFIG_HPLAN 1
#define CONFIG_NE2000 1
#define CONFIG_SK_G16 1
#define CONFIG_NET_EISA 1
#define CONFIG_AC3200 1
#define CONFIG_APRICOT 1
#define CONFIG_NET_POCKET 1
#define CONFIG_DE600 1
#define CONFIG_DE620 1
#define CONFIG_ATP 1
#define CONFIG_ZNET 1

/*
 * CD-ROM drivers
 */
#undef  CONFIG_CDU31A
#undef  CONFIG_CDU535
#undef  CONFIG_NEC260
#undef  CONFIG_MCD
#undef  CONFIG_SBPCD

/*
 * Filesystems
 */
#define CONFIG_MINIX_FS 1
#undef  CONFIG_EXT_FS
#define CONFIG_EXT2_FS 1
#define CONFIG_XIA_FS 1
#define CONFIG_MSDOS_FS 1
#define CONFIG_UMSDOS_FS 1
#define CONFIG_PROC_FS 1
#define CONFIG_NFS_FS 1
#define CONFIG_ISO9660_FS 1
#define CONFIG_HPFS_FS 1
#undef  CONFIG_SYSV_FS

/*
 * character devices
 */
#define CONFIG_PRINTER 1
#undef  CONFIG_BUSMOUSE
#define CONFIG_PSMOUSE 1
#define CONFIG_82C710_MOUSE 1
#undef  CONFIG_MS_BUSMOUSE
#undef  CONFIG_ATIXL_BUSMOUSE
#define CONFIG_SELECTION 1
#undef  CONFIG_QIC02_TAPE
#define CONFIG_FTAPE 1
#define NR_FTAPE_BUFFERS (3)

/*
 * Sound
 */
#undef  CONFIG_SOUND

/*
 * Kernel hacking
 */
#undef  CONFIG_PROFILE
#undef  CONFIG_SCSI_CONSTANTS
