( cd sbin ; rm -rf netconfig )
( cd sbin ; ln -sf  netconfig.color netconfig )
