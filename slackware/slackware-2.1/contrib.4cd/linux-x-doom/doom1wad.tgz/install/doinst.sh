( cd usr/games/doom ; rm -rf doom1.wad )
( cd usr/games/doom ; ln -sf /cdrom/usr/games/doom/doom1.wad doom1.wad )
