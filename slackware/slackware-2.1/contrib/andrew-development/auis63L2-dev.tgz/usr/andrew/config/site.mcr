/**/#
/**/# Site file for TPG
/**/#

BASEDIR = /usr/andrew
/* CDEBUGFLAGS = -g */
