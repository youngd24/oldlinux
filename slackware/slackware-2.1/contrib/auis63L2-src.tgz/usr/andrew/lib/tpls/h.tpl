\begindata{text,724096}
\textdsversion{12}
\define{comment

attr:[FontFace Italic Int Set]
attr:[FontFamily AndySans Int 0]
attr:['color' 'lightskyblue']}
\define{cmmnt2NL

attr:[FontFace Bold Int Set]
attr:[FontFamily AndyType Int 0]
attr:['color' 'cyan']}
\define{keyword

attr:[FontFamily AndySans Int 0]
attr:['color' 'Green']}
\define{function

attr:[FontFace Bold Int Set]
attr:[FontFamily AndySans Int 0]
attr:[FontSize PreviousFontSize Point 2]
attr:['color' 'Red']}
\define{userdef

attr:[FontFamily AndySans Int 0]
attr:['color' 'Yellow']}
\define{global

attr:[LeftMargin LeftEdge Int 16]
attr:[Indent LeftMargin Int -16]
attr:[Justification LeftJustified Point 0]
attr:[Flags ContinueIndent Int Set]
attr:[Flags TabsCharacters Int Set]
attr:[FontFamily AndyType Int 0]}
/*


Purpose:    whatever



	Created by <@programmer@> on <@date@>

	Copyright (c) <@programmer@>, <@year@>

*/

#ifndef _<@NAME@>_H

#define _<@NAME@>_H



#endif /* _<@NAME@>_H */

/* \


Change Log:

  $Log$


*/

\enddata{text,724096}
