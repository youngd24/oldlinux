\begindata{text,789016}
\textdsversion{12}
\define{comment

attr:[FontFace Italic Int Set]
attr:[FontFamily AndySans Int 0]
attr:['color' 'orange']}
\define{cmmnt2NL

attr:[FontFace Bold Int Set]
attr:[FontFamily AndyType Int 0]
attr:['color' 'cyan']}
\define{keyword

attr:[FontFamily AndySans Int 0]
attr:['color' 'Green']}
\define{function

attr:[FontFace Bold Int Set]
attr:[FontFamily AndySans Int 0]
attr:[FontSize PreviousFontSize Point 2]
attr:['color' 'Red']}
\define{userdef

attr:[FontFamily AndySans Int 0]
attr:['color' 'Yellow']}
\define{global

attr:[LeftMargin LeftEdge Int 16]
attr:[Indent LeftMargin Int -16]
attr:[Justification LeftJustified Point 0]
attr:[Flags ContinueIndent Int Set]
attr:[Flags TabsCharacters Int Set]
attr:[FontFamily AndyType Int 0]}
#include <stdio.h>

\userdef{
\userdef{char} *MeName = "<@name@>";		\comment{/* Used in msgs etc */}

int} Debug = 0;			\comment{/* Global debugging or not */}


/*

<@name@>


Function:    whatever


Syntax:

	<@name@> [-options] parms


Options:

 	z	    Enable Debug


Change Log:

  <@programmer@>	<@date@>	Initial coding


Copyright (c) <@programmer@>, <@year@>

*/


int main (int argc, char *argv[]) \{



	\comment{/*  Scan the input parms and sort out the options.*/}

	\userdef{while} (argv[1][0] == '-') \{

	\userdef{switch} (argv[1][1]) \{

	\userdef{case} 'z' :

	Debug++; \userdef{break};

	\userdef{default} :

	fprintf(stderr,"%s: Ignoring option '%c'\\n", MeName, argv[1][1] );

	\}

	argc--;  argv++;

	\}

	if (argc < 1) \{

	Usage();

	return(1);

	\}



	return(0);

\}

\enddata{text,789016}
