# NOTE: Derived from lib/POSIX.pm.  Changes made here will be lost.
package POSIX;

sub ungetc {
    redef "$filehandle->ungetc(char)";
}

1;
