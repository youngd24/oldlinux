# NOTE: Derived from lib/POSIX.pm.  Changes made here will be lost.
package POSIX;

sub times {
    usage "times()" if @_ != 0;
    times();
}

1;
