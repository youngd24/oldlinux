# NOTE: Derived from lib/POSIX.pm.  Changes made here will be lost.
package POSIX;

sub bsearch {
    unimpl "bsearch(xxx)" if @_ != 123;
    bsearch($_[0]);
}

1;
