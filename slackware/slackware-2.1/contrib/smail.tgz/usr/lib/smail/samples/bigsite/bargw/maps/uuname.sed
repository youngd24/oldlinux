#@(#)/usr/src/amdahl/cmd/smail/samples/bigsite/bargw/maps/uuname.sed	5.1
/^cu_line$/d
/^nohost$/d
