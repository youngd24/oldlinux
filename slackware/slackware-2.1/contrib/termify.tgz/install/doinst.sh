LIBVER=4.5.26-2.2.0
crunch() {
        LIBDIR=$1
        LIBPREFIX=$2
        for f in $LIBDIR/$LIBPREFIX.so.$LIBVER
        do
                bname=`basename $f`
                cp $f $LIBDIR/t$bname || exit 1
                rm -f $f
                mv $LIBDIR/t$bname $f
        done
}
crunch lib libt;
( cd lib ; rm -rf libt.so.4 )
( cd lib ; ln -sf libt.so.4.5.26-2.2.0 libt.so.4 )
