main()
{
     return lseek(0,0L,0) < 0;
}
