#!/bin/sh
cd usr/X11/lib/fonts/misc
if [ -r /usr/X11/bin/mkfontdir ]; then
#  echo "Running mkfontdir..."
  /usr/X11/bin/mkfontdir
elif [ -r /mnt/usr/X11/bin/mkfontdir ]; then
#  echo "Running mkfontdir..."
  /mnt/usr/X11/bin/mkfontdir
else
  cat << EOF

WARNING: mkfontdir could not be found at this time. You'll have to run it
yourself in /usr/X11/lib/fonts/misc for the new x3270 fonts to be properly
recongnized.

EOF
 sleep 10
fi
