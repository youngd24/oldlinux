#!/bin/sh
if [ -r /tmp/SeTcolor -o "$COLOR" = "on" ]; then
 dialog --title "SETTING DEFAULT X SERVER" --infobox \
"Making XF86_Mono the default X server." 3 50
else
 echo "Making XF86_Mono the default X server..."
 echo "  --> cd /var/X11/bin"
 echo "  --> ln -sf /usr/X11/bin/XF86_Mono X"
fi
( cd usr/X11/bin ; rm -rf X )
( cd usr/X11/bin ; ln -sf  /var/X11/bin/X X )
( cd var/X11/bin ; rm -rf X )
( cd var/X11/bin ; ln -sf  /usr/X11/bin/XF86_Mono X )
