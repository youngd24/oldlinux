/*
 * BDM2: Banked dumb monochrome driver
 * Pascal Haible 8/93, haible@izfm.uni-stuttgart.de
 *
 * bdm2/driver/apollo/apolloHW.h
 * Hamish Coleman 11/93 hamish@zot.apana.org.au 
 *
 * derived from:
 * hgc1280/*
 * Pascal Haible 8/93, haible@izfm.uni-stuttgart.de
 *
 * see bdm2/COPYRIGHT for copyright and disclaimers.
 */

/* $XFree86: mit/server/ddx/x386/bdm2/drivers/apollo/apolloHW.h,v 2.0 1994/04/10 05:54:07 dawes Exp $ */

#include "compiler.h"	/*	void outb(port,val);
				void outw(port,val);
				unsigned int inb(port);
				unsigned int inw(port);
				void intr_disable();
				void intr_enable();
				short port;
				short val;
			*/

#define C_STYLE_HEX_CONSTANTS
#include "apolloPorts.h"

#define AP_NUM_REGS		(0x10)

#define AP_MEM_BASE		(0xFA0000L)
#define AP_MEM_ALTERNATE	(0xA0000L)

#define AP_BANK_SIZE		(0x40000L)

#define	AP_MEM_BASE_BANK	(0L)

#define AP_BANK_BOTTOM		(AP_MEM_BASE_BANK)
#define AP_BANK_TOP		(AP_BANK_BOTTOM+AP_BANK_SIZE)

#define AP_MAP_BASE		(AP_MEM_BASE)
#define AP_MAP_ALTERNATE	(AP_MEM_ALTERNATE)

#define AP_MAP_SIZE		(AP_BANK_SIZE)

#define AP_SEGMENT_SIZE		(AP_BANK_SIZE)
#define AP_SEGMENT_SHIFT	(18)
#define AP_SEGMENT_MASK		(0x3FFFFL)

#define AP_HDISPLAY		(1280)
#define AP_VDISPLAY		(1024)
#define AP_MAX_VIRTUAL_X	(1280)
#define AP_MAX_VIRTUAL_Y	(1024)
#define AP_SCAN_LINE_WIDTH	(2048)

#define apollo_Textmode		(1411)
#define apollo_Graphmode	(1412)

#define Word_Width		128
/* Kludge alert! - only for monochrome adaptors */
