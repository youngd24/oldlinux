/*
 * BDM2: Banked dumb monochrome driver
 * Pascal Haible 8/93, haible@izfm.uni-stuttgart.de
 *
 * bdm2/driver/apollo/apolloBank.s
 * Hamish Coleman 11/93 hamish@zot.apana.org.au
 *
 * derived from:
 * hgc1280/*
 * Pascal Haible 8/93, haible@izfm.uni-stuttgart.de
 * hga2/*
 * Author:  Davor Matic, dmatic@athena.mit.edu
 * and
 * vga256/*
 * Copyright 1990,91 by Thomas Roell, Dinkelscherben, Germany.
 *
 * see bdm2/COPYRIGHT for copyright and disclaimers.
 */

/* $XFree86: mit/server/ddx/x386/bdm2/drivers/apollo/apolloBank.s,v 2.0 1994/04/10 05:54:05 dawes Exp $ */

/*
 * These are here the very lowlevel bankswitching routines.
 * The segment to switch to is passed via %eax. Only %eax and %edx my be used
 * without saving the original contents.
 *
 * WHY ASSEMBLY LANGUAGE ???
 *
 * These routines must be callable by other assembly routines. But I don't
 * want to have the overhead of pushing and poping the normal stack-frame.
 */

#include "assyntax.h"

#include "apolloPorts.h"

        FILE("apolloBank.s")

        AS_BEGIN

        SEG_DATA

        SEG_TEXT

        ALIGNTEXT4
        GLOBL   GLNAME(ApolloSetRead)
        GLOBL   GLNAME(ApolloSetWrite)
        GLOBL   GLNAME(ApolloSetReadWrite)
GLNAME(ApolloSetRead):
GLNAME(ApolloSetWrite):
GLNAME(ApolloSetReadWrite):
/*
 * Do nothing
 * -- This should never be called anyway as this card does not bank
 */
	RET
