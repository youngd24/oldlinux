/* backward compatibility */
#include <InterViews/telltale.h>
#ifdef __GNUG__
#pragma interface
#endif

