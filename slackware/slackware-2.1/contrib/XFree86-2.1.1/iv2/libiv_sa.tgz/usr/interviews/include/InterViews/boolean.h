/* backward compatibility */

#ifdef __GNUG__
#pragma interface
#endif

#include <InterViews/enter-scope.h>
