( cd usr/X11/bin ; rm -rf seyon-emu )
( cd usr/X11/bin ; ln -sf  /usr/X11/bin/xterm seyon-emu )
