#! /bin/sh
for i in ams ancient cm dc language misc phantasy symbol
do
if test -d $i; then
cd $i
./create.sh
cd ..
fi
done
