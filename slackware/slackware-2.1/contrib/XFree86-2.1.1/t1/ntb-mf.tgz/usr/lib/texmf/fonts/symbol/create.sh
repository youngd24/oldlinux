#! /bin/sh
for i in astro concrete dingbat hands logic logo phonetic recycle rsfs stmaryrd wsuipa
do
if test -d $i; then
cd $i
./create.sh
cd ..
fi
done
