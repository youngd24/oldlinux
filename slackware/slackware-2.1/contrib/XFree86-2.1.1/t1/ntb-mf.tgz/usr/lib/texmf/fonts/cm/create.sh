#! /bin/sh
for i in bbm cmastro cmb cmcyr cmoe cmpica cmttss latex ocm sauter wasy2 utilityfonts xcmr cmcyralt
do
if test -d $i; then
cd $i
./create.sh
cd ..
fi
done

