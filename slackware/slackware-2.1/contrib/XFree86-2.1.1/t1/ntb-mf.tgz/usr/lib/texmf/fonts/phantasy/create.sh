#! /bin/sh
for i in elvish engwar futhark klinz okuda tengwar
do
if test -d $i; then
cd $i
./create.sh
cd ..
fi
done
