#! /bin/sh
for i in blackletter calligra duerer go hge karta la ocr-a pandora punk twcal cherokee cypriote
do
if test -d $i; then
cd $i
./create.sh
cd ..
fi
done
