#! /bin/sh
for i in bard hieroglyph ogham rune gothic ugaritic
do
if test -d $i; then
cd $i
./create.sh
cd ..
fi
done
