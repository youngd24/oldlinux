#! /bin/sh
for i in devanagari fc georgian osmanian hebrew tamil turkish thai arabtex greek
do
if test -d $i; then
cd $i
./create.sh
cd ..
fi
done
