crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.?.*.*
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
#echo "Compacting Tcl shared library to decrease disk space utilization..."
crunch usr/lib libtcl;
#echo "Tcl shared library compacted."
( cd usr/lib ; rm -rf libtcl.so.3 )
( cd usr/lib ; ln -sf libtcl.so.3.1.0 libtcl.so.3 )
