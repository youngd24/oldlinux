( cd usr/openwin/include/uit ; ln -sf  ./ListChoice.h ScrollChoice.h )
