crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.?.*.*
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
#echo "Compacting TclX/TkX shared libraries to decrease disk space utilization..."
crunch usr/lib libtclx;
crunch usr/lib libtkx;
#echo "TclX/TkX shared libraries compacted."
( cd usr/lib ; rm -rf libtclx.so.3 )
( cd usr/lib ; ln -sf libtclx.so.3.2.0 libtclx.so.3 )
( cd usr/lib ; rm -rf libtkx.so.3 )
( cd usr/lib ; ln -sf libtkx.so.3.2.0 libtkx.so.3 )
