dialog --title "SETTING DEFAULT X SERVER" --infobox \
"Making XF86_S3 the default X server." 3 50
#echo "Making XF86_S3 the default X server..."
#echo "  --> cd /var/X11/bin"
#echo "  --> ln -sf ../../../usr/X11/bin/XF86_S3 X"
( cd usr/X11/bin ; ln -sf  ../../../var/X11/bin/X X )
( cd var/X11/bin ; ln -sf  ../../../usr/X11/bin/XF86_S3 X )
