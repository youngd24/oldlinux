if [ -r ./usr/X386/lib/X11/xinit/xinitrc ]; then
#	echo "Moving your old xinitrc to /usr/X386/lib/X11/xinit/xinitrc.backup..."
	mv usr/X386/lib/X11/xinit/xinitrc usr/X386/lib/X11/xinit/xinitrc.backup
fi
#echo "  Installing FVWM as your default window manager (start with 'startx')"
#echo "  --> cd /usr/X386/lib/X11/xinit"
#echo "  --> ln -sf xinitfc.fvwm xinitrc"
( cd usr/X386/lib/X11/xinit ; ln -sf  xinitrc.fvwm xinitrc )
