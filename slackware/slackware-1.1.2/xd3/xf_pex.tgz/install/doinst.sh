( cd usr/X386/lib ; ln -sf  /usr/X386/lib/libPEX5.so.1.1.0 libPEX5.so.1 )
( cd lib ; ln -sf  /usr/X386/lib/libPEX5.so.1.1.0 libPEX5.so.1 )
crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.?.?.?
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
#echo "Compacting shared library to decrease disk space utilization..."
crunch usr/X386/lib libPEX5;
#echo "Shared library compacted."
