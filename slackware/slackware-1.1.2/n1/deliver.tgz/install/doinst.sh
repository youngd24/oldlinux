( cd usr/lib ; ln -sf  ../../var/deliver deliver )
