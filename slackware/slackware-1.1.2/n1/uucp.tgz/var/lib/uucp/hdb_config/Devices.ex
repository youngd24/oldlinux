#
# Devices 
ACU ttyS1 - 19200 scout
ACU ttyS1 - 9600 tbfast
ACU ttyS1 - 1200 tbslow
ACU ttyS1 - 2400 tbmed
#
#ident	"@(#)uucp:Devices	2.5"
#
# Some sample entries:
# NOTE - all lines must have at least 5 fields 
#    use '-' for unused fields
# The Devices file is used in conjuction with the Dialers file.
# Types that appear in the 5th field must be either built-in
#  functions (801, Sytek, TCP, Unetserver, DK)
#  or standard functions whose name appears in the first
#  field in the Dialers file.
# Two escape characters may appear in this file:
# - \D which means don't translate the phone #/token
# - \T translate the phone #/token using the Dialcodes file
# Both refer to the phone number field in the Systems file (field 5)
# \D should always be used with entries in the Dialers file, since the
# Dialers file can contain a \T to expand the number if necessary.
# \T should only be used with builtin functions that require expansion
# NOTE: - if a phone number is expected and a \D or \T is not present
#	a \T is used for a builtin, and \D is used for an entry
#	referencing the Dialers file. (see examples below)
#
#
# ---Standard modem line
# ACU cul02 cua02 1200 801
# ACU contty - 1200 penril
# or
# ACU contty - 1200 penril \D
#
# ---A direct line so 'cu -lculd0' will work
# Direct culd0 - 4800 direct
#
# ---A ventel modem on a develcon switch (vent is the token given to
#	the develcon to reach the ventel modem)
# ACU culd0 - 1200 develcon vent ventel
# ACU culd0 - 1200 develcon vent ventel \D
#
# ---To reach a system on the local develcon switch
# Develcon culd0 - Any develcon \D
#
# ---Access a direct connection to a system
# systemx tty00 - Any direct
#
# where the Systems file looks like
# systemx Any systemx 1200 unused  "" in:-\r\d-in: nuucp word: nuucp
#	(The third field in Systems matches the first field in Devices)
#
# ---To connect to any system on the DATAKIT VCS network
# DK DK 0 Any DK \D
#
# ---To connect to a system on a Datakit in nj/ho
# DKho - uucp Any DK nj/ho/\D
#
# ---To use an ACU that is connected to Datakit that DK does not understand
#	how to talk to directly
# ACU - 0 Any DK vent ventel \D
#
# ---To use a dialer that the Datakit understands how to chat with
#	This is a special case where the translation must be done by the
#	Devices file processing.
# ACU DKacu 0 Any DK py/garage/door.\T
#

########	AT&T Transport Interface
#
# ---To use a STREAMS network that conforms to the AT&T Transport Interface
#	with a direct connection to login service (i.e., without
#	explicitly using the Network Listener Service dial script):
#
# networkx,eg devicex - - TLIS \D
#
#	The Systems file entry looks like:
#
# systemx Any networkx - addressx in:--in: nuucp word: nuucp
#
#	You must replace systemx, networkx, addressx, and devicex with system
#	name, network name, network address and network device, respectively.
#	For example, entries for machine "sffoo" on a STARLAN NETWORK might
#	look like:
#		sffoo Any STARLAN - sffoo in:--in: nuucp word: nuucp
#	and:
#		STARLAN,eg starlan - - TLIS \D
#
# ---To use a STREAMS network that conforms to the AT&T Transport Interface
#	and that uses the Network Listener Service dial script to negotiate
#	for a server:
#
# networkx,eg devicex - - TLIS \D nls
#
#
# ---To use a non-STREAMS network that conforms to the AT&T Transport 
#	Interface and that uses the Network Listener Service dial script
#	to negotiate for a server:
#
# networkx,eg devicex - - TLI \D nls
#
########
#
#
# NOTE: blank lines and lines that begin with a <space>, <tab>, or # are 
#		ignored.
#	protocols can be specified as a comma-subfield of the device type
#		either in the Devices file (where device type is field 1)
#		or in the Systems file (where it is field 3).
#Direct tty01 - 9600 direct
