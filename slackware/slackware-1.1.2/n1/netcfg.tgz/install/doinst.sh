( cd usr/adm/setup ; ln -sf  ../../../sbin/netconfig.color netconfig )
