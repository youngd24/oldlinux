( cd usr/bin ; ln -sf  flex lex )
