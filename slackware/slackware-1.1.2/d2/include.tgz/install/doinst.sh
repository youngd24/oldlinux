( cd usr/include ; ln -sf /usr/src/linux/include/asm . ; ln -sf /usr/src/linux/include/linux . )
( cd usr/include/netinet ; ln -sf ip_tcp.h tcp.h ; ln -sf ip_udp.h udp.h )
