( cd usr/bin ; ln -sf  ../local/lib/news/inews inews )
( cd usr/bin ; ln -sf  ../local/lib/news/bin/rnews rnews )
