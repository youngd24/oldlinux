defsub	general
mustsub	general
