( cd usr/man/preformat/cat1 ; ln -sf  XF86_Accel.1x.gz XF86_8514.1x.gz )
( cd usr/man/preformat/cat1 ; ln -sf  XF86_Accel.1x.gz XF86_Mach32.1x.gz )
( cd usr/man/preformat/cat1 ; ln -sf  XF86_Accel.1x.gz XF86_Mach8.1x.gz )
( cd usr/man/preformat/cat1 ; ln -sf  XF86_Accel.1x.gz XF86_S3.1x.gz )
