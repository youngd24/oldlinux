crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX*.so.3.1.0
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
#echo "Compacting shared libraries to decrease disk space utilization..."
crunch usr/X386/lib libX;
#echo "Shared libraries compacted."
( cd usr/X386/lib ; ln -sf  /usr/X386/lib/libX11.so.3.1.0 libX11.so.3 )
( cd usr/X386/lib ; ln -sf  /usr/X386/lib/libXaw.so.3.1.0 libXaw.so.3 )
( cd usr/X386/lib ; ln -sf  /usr/X386/lib/libXt.so.3.1.0 libXt.so.3 )
( cd lib ; ln -sf  /usr/X386/lib/libX11.so.3.1.0 libX11.so.3 )
( cd lib ; ln -sf  /usr/X386/lib/libXaw.so.3.1.0 libXaw.so.3 )
( cd lib ; ln -sf  /usr/X386/lib/libXt.so.3.1.0 libXt.so.3 )
