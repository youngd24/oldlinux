#echo "  --> cd /usr/bin ; ln -sf ../X11/bin X11"
( cd usr/bin ; ln -sf  /usr/X386/bin X11 )
#echo "  --> cd /usr/lib ; ln -sf  ../X11/lib/X11 X11"
( cd usr/lib ; ln -sf  /usr/X386/lib/X11 X11 )
#echo "  --> cd /usr/include ; ln -sf  ../X11/include/X11 X11"
( cd usr/include ; ln -sf  /usr/X386/include/X11 X11 )
