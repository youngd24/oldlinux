( cd usr/bin ; ln -sf  emacs-19.22 emacs )
( cd usr/lib/emacs ; ln -sf  ../../../var/lock/emacs lock )
