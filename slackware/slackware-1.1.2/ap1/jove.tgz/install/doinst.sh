( cd usr/bin ; ln -sf  xjove jove )
