( cd usr/bin ; ln -sf  gcc cc )
