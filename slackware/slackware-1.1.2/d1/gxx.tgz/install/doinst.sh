( cd usr/bin ; ln -sf  g++ c++ )
