( cd usr/include/ncurses ; ln -sf ncurses.h curses.h )
