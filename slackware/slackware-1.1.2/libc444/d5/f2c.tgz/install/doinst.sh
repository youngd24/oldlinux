crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.?.?
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
( cd lib ; ln -sf libf2c.so.0.9 libf2c.so.0 )
#echo "Compacting shared library to decrease disk space utilization..."
crunch lib libf2c;
#echo "Shared library compacted."
