( cd bin ; ln -sf  gzip gunzip )
( cd bin ; ln -sf  gzip zcat )
( cd usr/bin ; ln -sf  ../../bin/gzip gunzip )
( cd usr/bin ; ln -sf  ../../bin/gzip zcat )
