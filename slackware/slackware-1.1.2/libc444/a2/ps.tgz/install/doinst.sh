( cd usr/bin ; ln -sf  w.procps w )
