( cd usr/lib/setup ; ln -sf  cpkgtool pkgtool )
( cd usr/lib/setup ; ln -sf  hdsetup setup )
( cd sbin ; ln -sf  ../usr/lib/setup/hdsetup setup )
( cd sbin ; ln -sf  ../usr/lib/setup/cpkgtool pkgtool )
