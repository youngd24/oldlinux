( cd sbin ; ln -sf  init telinit )
( cd sbin ; ln -sf  halt reboot )
