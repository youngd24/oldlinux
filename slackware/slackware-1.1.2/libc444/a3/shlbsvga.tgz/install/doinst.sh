crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.?.*.*
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
#echo "Compacting SVGAlib shared library to decrease disk space utilization..."
crunch lib libvga;
#echo "SVGAlib shared library compacted."
( cd lib ; ln -sf  libvga.so.1.*.* libvga.so.1 )
