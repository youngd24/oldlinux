( cd usr/lib/zoneinfo ; ln -sf  localtime posixrules )
( cd usr/lib/zoneinfo ; ln -sf  ../../adm/setup/setup.timeconfig timeconfig )
