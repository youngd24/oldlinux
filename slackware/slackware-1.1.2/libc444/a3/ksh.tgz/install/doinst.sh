( cd bin ; ln -sf  pdksh ksh )
( cd usr/man/preformat/cat1 ; ln -sf ksh.1.gz pdksh.1.gz )
if fgrep KSH_VERSION etc/profile 1> /dev/null 2> /dev/null; then
 GOOD=y
else
 echo 'if [ ! "$KSH_VERSION" = "" ]; then' >> etc/profile
 cat << EOF >> etc/profile
 . /etc/ksh.kshrc
 if [ -r $HOME/.kshrc ]; then
  . $HOME/.kshrc
 fi
fi
EOF
fi
