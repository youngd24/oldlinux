( cd usr/bin ; ln -sf  grep fgrep )
( cd usr/bin ; ln -sf  grep egrep )
