( cd usr/bin ; ln -sf  perl4.036 perl )
( cd usr/bin ; ln -sf  tperl4.036 taintperl )
