( cd interviews/lib/all ; ln -sf  ../../../usr/X386/lib/X11/app-defaults app-defaults )
