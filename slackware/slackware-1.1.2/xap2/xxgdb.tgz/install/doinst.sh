( cd usr/man/preformat/cat1 ; ln -sf  xdbx.1.gz xxgdb.1.gz )
