crunch() {
	LIBDIR=$1
	LIBPREFIX=$2
	for f in $LIBDIR/$LIBPREFIX.so.*.*.*
	do
		bname=`basename $f`
#		echo "   - compacting $bname."
		cp $f $LIBDIR/t$bname || exit 1
		rm -f $f
		mv $LIBDIR/t$bname $f
	done
}
(cd lib ; ln -sf libc.so.4.*.* libc.so.4 ; ln -sf libm.so.4.*.* libm.so.4 )
#echo "Compacting shared libraries to decrease disk space utilization..."
crunch lib libc;
crunch lib libm;
#echo "Shared libraries compacted."
