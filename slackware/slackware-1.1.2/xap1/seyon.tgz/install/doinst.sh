( cd usr/X386/bin ; ln -sf  /usr/X386/bin/xterm seyon-emu )
