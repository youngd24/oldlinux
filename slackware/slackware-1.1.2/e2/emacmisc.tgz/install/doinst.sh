( cd usr/lib/emacs/19.22/etc ; ln -sf  DOC-19.22.1 DOC )
