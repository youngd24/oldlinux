( cd usr/bin ; ln -sf  emacs-19.22 emacs )
