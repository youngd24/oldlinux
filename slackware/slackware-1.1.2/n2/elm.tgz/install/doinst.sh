( cd usr/man/preformat/catn ; ln -sf  newmail.n.gz wnewmail.n.gz )
