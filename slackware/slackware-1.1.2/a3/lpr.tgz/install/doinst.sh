( cd usr/bin ; ln -sf  ../sbin/lpc lpc )
