( cd bin ; ln -sf  tcsh csh )
