( cd usr/bin ; ln -sf  rz rx )
( cd usr/bin ; ln -sf  rz rb )
( cd usr/bin ; ln -sf  sz sb )
( cd usr/bin ; ln -sf  sz sx )
