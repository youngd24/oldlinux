( cd usr/bin ; ln -sf  test [ )
