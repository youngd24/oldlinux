( cd etc/lilo ; ln -sf  ../../sbin/lilo install )
( cd usr/doc/lilo ; ln -sf  ../../src/lilo/README README )
