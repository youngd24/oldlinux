( cd dev ; ln -sf  tty0 console )
( cd dev ; ln -sf  cua1 modem )
( cd dev ; ln -sf  cua0 mouse )
if [ ! -L dev/cdrom ]; then # provide a reasonable default
 ( cd dev ; ln -sf /dev/scd0 cdrom )
fi
if [ -r dev/printer ]; then
  rm -f dev/printer
fi
# ( cd dev ; ln -sf  /tmp/.printer printer )
