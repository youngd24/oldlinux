( cd etc ; ln -sf  . inet )
( cd etc ; ln -sf  /usr/adm/wtmp wtmp )
( cd usr/etc ; ln -sf  /etc/printcap printcap )
( cd usr ; ln -sf info Info )
( cd root ; ln -sf /usr/src/linux linux )
( cd root ; ln -sf /usr/adm INSTALL )
( chmod 751 root )
( cd etc/lilo ; ln -sf  ../../sbin/lilo install )
if [ ! -r etc/passwd ]; then
 mv etc/npasswd etc/passwd
fi
if [ ! -r etc/group ]; then
 mv etc/ngroup etc/group
fi
